import React, { useState, useEffect } from 'react';
import { Award, Filter, X, MapPin, Calendar, Users, TrendingUp, ChevronRight, ArrowRight, Send, CheckCircle, Loader2, AlertCircle } from 'lucide-react';

// ─────────────────────────────────────────────────────────────────
// HONOREES DATA
// ─────────────────────────────────────────────────────────────────
// TO ADD A NEW HONOREE:
//   1. Add a new object to this array following the same shape
//   2. Drop their photo in public/top30/filename.jpg
//   3. Set img: '/top30/filename.jpg'
//   4. Push to GitHub — card + popup render automatically
//
// TO GENERATE STORY CONTENT:
//   Prompt any AI: "Write a founder story for [Name] of [Company].
//   Cover: how they started (origin), how they scaled (growth),
//   key achievement (milestone), and future vision (vision).
//   Keep each paragraph to 3-4 sentences."
// ─────────────────────────────────────────────────────────────────

const honorees = [
  {
    id: 1,
    name: 'Chidera Okoro',
    company: 'NeoBank Africa',
    category: 'Finance',
    age: 28,
    position: 'Founder & CEO',
    founded: '2021',
    location: 'Lagos, Nigeria',
    // Drop custom image in public/top30/ and update path below
    img: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=600&h=800&fit=crop',
    // One-line shown on the card
    bio: 'Redefining digital payments for the unbanked across West Africa.',
    // 3 key stats shown in the popup header
    stats: [
      { label: 'Users',       value: '340K+'  },
      { label: 'Raised',      value: '$4.2M'  },
      { label: 'Countries',   value: '6'      },
    ],
    // Full story — 4 sections shown in the popup body
    story: {
      origin:
        'Chidera grew up watching her mother travel three hours to the nearest bank branch in Anambra State, only to be turned away for lacking the right documentation. That experience planted a question she would spend her twenties answering: why does financial access remain a privilege in a continent of over a billion people? She studied computer science at University of Lagos, graduated top of her class, and immediately turned down a Goldman Sachs offer to begin building what would become NeoBank Africa from a two-room apartment in Yaba.',
      growth:
        'The early months were brutal. Her first product — a USSD-based savings wallet — launched to 200 users, most of them friends. A partnership with three market associations in Onitsha changed everything. By routing payroll through NeoBank for 1,400 traders, she gained her first meaningful transaction data, which she used to build a micro-credit scoring model that banks called impossible. By the end of 2022, NeoBank had processed over ₦2 billion in transactions without a single physical branch.',
      milestone:
        'In January 2024, NeoBank Africa crossed 340,000 active users — a milestone that attracted a $4.2 million seed round led by Partech Africa. The round made Chidera one of the youngest female founders on the continent to close a Series Seed above $4 million. Her credit model now has a 91% repayment rate across loans issued to traders, farmers and artisans who had never previously accessed formal credit.',
      vision:
        'Chidera is building toward a Pan-African banking licence that would allow NeoBank to operate across borders without local banking partnerships — a structure she believes is the only way to serve the 400 million Africans still excluded from formal financial systems. "We are not building a fintech," she says. "We are building the infrastructure layer that makes the next generation of African businesses possible."',
    },
  },
  {
    id: 2,
    name: 'Tobi Adeyemi',
    company: 'GreenLogistics',
    category: 'Tech',
    age: 26,
    position: 'Co-Founder & CTO',
    founded: '2022',
    location: 'Ibadan, Nigeria',
    img: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=600&h=800&fit=crop',
    bio: 'Solving the last-mile delivery crisis with AI-optimized routing.',
    stats: [
      { label: 'Deliveries/Day', value: '8,200'  },
      { label: 'Cities',         value: '11'     },
      { label: 'CO₂ Saved',      value: '14T/mo' },
    ],
    story: {
      origin:
        'Tobi spent two years as a dispatch rider in Ibadan during his undergraduate studies, watching thousands of naira in fuel and hours of daylight disappear into Lagos traffic. He began mapping inefficiencies on a notebook — wrong routes, idle riders, missed windows — and by his final year had built a basic routing algorithm in Python that he tested on his own deliveries. His final year project became the founding document of GreenLogistics.',
      growth:
        'GreenLogistics launched with 12 riders and one corporate client: a mid-sized e-commerce brand in Ibadan. Within six months, Tobi had signed five more clients by showing each of them a data-backed proof that his routing system cut average delivery time by 34% and fuel costs by 28%. The algorithm learned with every delivery, improving daily. By 2023 the platform had expanded to three cities and was handling over 3,000 deliveries per day.',
      milestone:
        'In 2024 GreenLogistics became the logistics backbone for two of Nigeria\'s top five e-commerce platforms, processing over 8,200 deliveries daily across 11 cities. The company\'s proprietary electric bike leasing programme — which allows riders to own their bikes through earnings deductions — has put 340 electric bikes on Nigerian roads, making it one of the largest electric mobility fleets in West Africa.',
      vision:
        'Tobi is developing the next version of his routing engine to incorporate real-time traffic data from municipal sources, weather patterns and social event calendars — a system he believes will reduce failed deliveries by 60%. His longer-term ambition is to licence the technology to logistics companies across East and Southern Africa, building a continental last-mile intelligence layer.',
    },
  },
  {
    id: 3,
    name: 'Aisha Bello',
    company: 'Bello Couture',
    category: 'Art & Style',
    age: 24,
    position: 'Creative Director & Founder',
    founded: '2020',
    location: 'Abuja, Nigeria',
    img: 'https://images.unsplash.com/photo-1531123897727-8f129e1688ce?q=80&w=600&h=800&fit=crop',
    bio: 'Blending traditional Nigerian textiles with modern high-fashion silhouettes.',
    stats: [
      { label: 'Pieces Sold',  value: '4,100+' },
      { label: 'Markets',      value: '18'     },
      { label: 'Revenue',      value: '₦280M'  },
    ],
    story: {
      origin:
        'Aisha learned to sew from her grandmother in Kaduna at age nine, sitting beside her on a wooden stool as she worked through bolts of adire and aso-oke. Fashion school in London taught her structure, proportion and the Western silhouette. It was coming home — watching her grandmother sell fabric for a fraction of its worth at a local market — that gave her the business idea. She launched Bello Couture from her bedroom in Abuja at 20, with ₦180,000 in savings and a secondhand industrial sewing machine.',
      growth:
        'Her first collection — seven pieces blending Ankara with tailored blazer cuts — sold out in 11 days through Instagram. She reinvested every naira into fabric and production. What separated Bello Couture from competing brands was her insistence on ethical sourcing: every fabric came directly from weavers and dyers she knew personally, and she published their names and locations with every collection. The transparency became her most powerful marketing asset.',
      milestone:
        'By 2024 Bello Couture had sold over 4,100 pieces across 18 international markets, including stockists in London, Paris and New York. A collaboration with a major European fashion house brought her to Paris Fashion Week, where she became the first Nigerian designer under 25 to present at a major group show. Annual revenue crossed ₦280 million — entirely bootstrapped, zero external investment.',
      vision:
        'Aisha is building a textile heritage programme that will train 500 young weavers in traditional techniques by 2027, creating a sustainable supply chain that keeps value inside Nigerian communities. She is also developing a ready-to-wear diffusion line priced for the Nigerian middle class — her belief being that luxury African fashion should first be accessible to Africans.',
    },
  },
  {
    id: 4,
    name: 'David Mensah',
    company: 'FarmBase',
    category: 'Social Impact',
    age: 29,
    position: 'Founder & CEO',
    founded: '2020',
    location: 'Accra, Ghana',
    img: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=600&h=800&fit=crop',
    bio: 'Connecting smallholder farmers directly to global export markets.',
    stats: [
      { label: 'Farmers',    value: '22,000' },
      { label: 'Countries',  value: '9'      },
      { label: 'GMV',        value: '$12M'   },
    ],
    story: {
      origin:
        'David watched his father — a cocoa farmer in the Ashanti Region — sell an entire season\'s harvest to a middleman for a price set that morning with no negotiation, no transparency and no alternative. The middleman resold it to an export broker for three times the price within the week. David studied agricultural economics at the University of Ghana, spent a year working with the FAO in Geneva understanding global commodity chains, and returned to Accra with a plan to eliminate the middleman entirely.',
      growth:
        'FarmBase began as a WhatsApp group connecting 40 cassava farmers in the Eastern Region to three restaurant buyers in Accra. David handled logistics personally for the first three months, driving produce in a rented pickup. He built a simple web platform as demand outgrew the group chat, then added an SMS layer for farmers without smartphones. By the end of its first year, FarmBase had processed over $400,000 in transactions and expanded to cocoa, shea and palm oil.',
      milestone:
        'FarmBase now connects 22,000 smallholder farmers across nine African countries to buyers in Europe, Asia and North America, with a gross merchandise value exceeding $12 million annually. David\'s price transparency model — which shows farmers the global commodity price in real time — has increased average farmer income on the platform by 67% compared to traditional market channels. The company won the 2024 African Development Bank Innovation Prize.',
      vision:
        'David is building FarmBase\'s own export certification programme, which would allow farmers on the platform to access premium organic and fair-trade markets currently closed to smallholders. He is also developing a crop insurance product embedded directly into the platform — using satellite imagery and weather data to assess risk and pay out claims without paperwork.',
    },
  },
  {
    id: 5,
    name: 'Kemi Silva',
    company: 'LuxeStay',
    category: 'Retail',
    age: 27,
    position: 'Founder & CEO',
    founded: '2021',
    location: 'Lagos, Nigeria',
    img: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=600&h=800&fit=crop',
    bio: 'The premier marketplace for luxury short-let apartments in Lagos.',
    stats: [
      { label: 'Properties',   value: '1,200+' },
      { label: 'Bookings/mo',  value: '3,400'  },
      { label: 'Revenue',      value: '₦1.8B'  },
    ],
    story: {
      origin:
        'Kemi arrived in Lagos from London for a cousin\'s wedding in 2019 and spent 45 minutes on the phone trying to find a short-let apartment that matched what the photos had advertised. What she eventually booked looked nothing like the listing. Back in London, she spent a year researching the Lagos short-let market, identifying the core problem: no verification, no standards, no accountability. She quit her job at a property consultancy and moved back to Lagos in 2021 with a laptop and a methodology for physically vetting every property before it could list.',
      growth:
        'LuxeStay launched with 18 verified properties in Victoria Island and Lekki Phase 1. The verification badge — which required Kemi or a member of her team to visit, photograph and score every property — became the product. Within three months, corporate clients booking accommodation for expatriate staff and visiting executives became her primary market. She raised ₦60 million in angel funding from two Lagos-based real estate investors to build the booking platform and hire a verification team.',
      milestone:
        'LuxeStay now lists over 1,200 verified properties across Lagos, Abuja and Port Harcourt, processing 3,400 bookings per month with an average booking value of ₦180,000 per night. Annual revenue crossed ₦1.8 billion in 2024. The platform\'s 4.8-star average guest rating — maintained through a strict host accountability system — has made it the preferred booking platform for 14 multinational companies operating in Nigeria.',
      vision:
        'Kemi is expanding LuxeStay into five new African cities by the end of 2026, beginning with Nairobi and Accra. She is also building a property management arm that will take on day-to-day operations for property owners — transforming LuxeStay from a marketplace into a full-service hospitality business.',
    },
  },
  {
    id: 6,
    name: 'Samuel Okafor',
    company: 'Vantage AI',
    category: 'Tech',
    age: 25,
    position: 'Co-Founder & CEO',
    founded: '2022',
    location: 'Lagos, Nigeria',
    img: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=600&h=800&fit=crop',
    bio: 'Democratizing enterprise-level analytics for SMEs across Africa.',
    stats: [
      { label: 'Businesses',  value: '6,800'  },
      { label: 'Data Points', value: '2B+/mo' },
      { label: 'Raised',      value: '$2.8M'  },
    ],
    story: {
      origin:
        'Samuel was 22 and working as a data analyst at a Lagos consulting firm when he noticed that every insight he was producing for large corporate clients — churn prediction, demand forecasting, pricing optimisation — was technically within reach of small businesses, but priced at a level that made it inaccessible. He spent his evenings building a simplified dashboard that could process sales data from a small retailer and surface the same class of insights, without requiring any technical knowledge from the user.',
      growth:
        'The first version of Vantage AI was built in six months and tested with five retailers in the Ikeja market. The feedback was direct: the insights were useful but the onboarding was too complex. Samuel rebuilt the interface from scratch, designing for a user who had never seen a data product before. The second version required no training — a retailer could connect their point-of-sale records and receive actionable inventory recommendations within minutes. Word spread through business associations faster than any advertising.',
      milestone:
        'Vantage AI now serves 6,800 businesses across Nigeria, Kenya and Ghana, processing over 2 billion data points per month. A $2.8 million pre-Series A round in 2024 — led by a pan-African venture fund — validated the platform\'s commercial model. One client, a Lagos-based FMCG distributor, reported a 23% reduction in stockouts and a 19% improvement in working capital efficiency within four months of adopting Vantage.',
      vision:
        'Samuel is building a predictive financing module that will allow Vantage AI to connect businesses with lenders based on real-time performance data — removing the need for banks to rely on credit history alone. His goal is to make Vantage AI the operating intelligence layer for one million African SMEs by 2030.',
    },
  },
  {
    id: 7,
    name: 'Ngozi Eze',
    company: 'HealthBridge',
    category: 'Social Impact',
    age: 27,
    position: 'Founder & Medical Director',
    founded: '2021',
    location: 'Port Harcourt, Nigeria',
    img: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=600&h=800&fit=crop',
    bio: 'Bringing telemedicine to rural communities across the Niger Delta.',
    stats: [
      { label: 'Consultations', value: '180K+' },
      { label: 'Communities',   value: '340'   },
      { label: 'Doctors',       value: '820'   },
    ],
    story: {
      origin:
        'Ngozi graduated from the University of Port Harcourt Medical School and completed her housemanship in a general hospital in Bayelsa State, where she encountered patients who had travelled six hours by boat to reach her for conditions that a five-minute video call could have diagnosed and treated weeks earlier. She completed her medical degree, spent a year studying digital health systems at Johns Hopkins, and returned to Nigeria with a plan to rebuild the primary healthcare access model for the Niger Delta.',
      growth:
        'HealthBridge launched with 12 doctors volunteering two hours per week on a basic telehealth platform built by a friend. Community health workers in partner villages used feature phones to schedule consultations and relay prescriptions to local pharmacies. In the first six months, the system handled 4,200 consultations — 78% of patients reporting it was their first interaction with a doctor in over a year. A grant from the Gates Foundation funded the development of a proper mobile platform and the hiring of the first paid staff.',
      milestone:
        'HealthBridge has now delivered over 180,000 consultations across 340 communities in the Niger Delta, with a network of 820 registered doctors contributing to the platform. A state government partnership in Rivers State has made HealthBridge the official telemedicine provider for 200 primary health centres — the first government adoption of a telemedicine platform in the South-South region.',
      vision:
        'Ngozi is building a diagnostic AI layer that will allow community health workers without medical training to conduct basic triage and refer appropriately — extending HealthBridge\'s reach to communities too remote even for internet connectivity, using offline-capable tools and satellite data sync.',
    },
  },
  {
    id: 8,
    name: 'Emeka Nwosu',
    company: 'TradeStack',
    category: 'Finance',
    age: 29,
    position: 'Founder & CEO',
    founded: '2021',
    location: 'Lagos, Nigeria',
    img: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?q=80&w=600&h=800&fit=crop',
    bio: "Building Africa's first retail stock trading platform with zero commission.",
    stats: [
      { label: 'Investors',  value: '91K+'  },
      { label: 'AUM',        value: '$38M'  },
      { label: 'Raised',     value: '$6.1M' },
    ],
    story: {
      origin:
        'Emeka started trading Nigerian equities at 19 using a legacy broker platform that charged ₦500 per trade, required a minimum deposit of ₦50,000 and took up to three days to execute an order. He was convinced that every barrier — the fees, the complexity, the minimum balances — was a design choice, not a technical necessity. After two years as a derivatives analyst at a Lagos investment bank, he resigned and spent eight months building TradeStack\'s trading engine before writing a single line of the consumer interface.',
      growth:
        'TradeStack launched in April 2022 with zero commission trading on the Nigerian Stock Exchange — the first platform to do so. The waitlist hit 12,000 people in the first 48 hours, crashing the onboarding system. Emeka and his team rebuilt the infrastructure in seven days without taking the platform down. A fractional shares feature — allowing users to buy ₦500 worth of any listed stock — opened the market to an entirely new class of investor who had previously been priced out entirely.',
      milestone:
        'TradeStack crossed 91,000 registered investors in 2024, with assets under management exceeding $38 million — a compound monthly growth rate of 14% since launch. A $6.1 million Series A round in early 2025 was co-led by two pan-African venture funds. TradeStack is now the most downloaded investment app in Nigeria, with a median user age of 26 — reshaping who participates in the Nigerian capital market.',
      vision:
        'Emeka is expanding TradeStack to enable trading of US equities, pan-African bonds and commodities from a single account — building the infrastructure for what he describes as "the first truly continental retail investment platform." A crypto integration is planned for late 2025, subject to SEC Nigeria approval.',
    },
  },
  {
    id: 9,
    name: 'Fatima Suleiman',
    company: 'CraftHouse',
    category: 'Art & Style',
    age: 23,
    position: 'Founder & Creative Lead',
    founded: '2021',
    location: 'Kano, Nigeria',
    img: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?q=80&w=600&h=800&fit=crop',
    bio: 'A digital marketplace scaling artisan crafts from Kano to the world.',
    stats: [
      { label: 'Artisans',  value: '2,400' },
      { label: 'Countries', value: '28'    },
      { label: 'GMV',       value: '$1.9M' },
    ],
    story: {
      origin:
        'Fatima grew up in the old city of Kano, surrounded by leather workers, embroiderers and metal craftsmen whose families had practised their trades for generations. At 19 she began photographing their work and posting it on Instagram, watching pieces that sold for ₦3,000 in the Kurmi Market generate dozens of enquiries from international buyers willing to pay ten times that amount. The gap was not quality — it was visibility and logistics. She deferred her second year of university to build a solution.',
      growth:
        'CraftHouse launched as an Instagram shop and a WhatsApp coordination system, with Fatima personally managing international shipping for the first 200 orders. She built a proper e-commerce platform 18 months later, funded by profits. The platform\'s authentication system — which gives each piece a digital certificate of origin linking it to the specific artisan who made it — became the primary differentiator for international buyers looking for verified authentic African craft.',
      milestone:
        'CraftHouse now represents 2,400 artisans across 14 Nigerian states, shipping to 28 countries with a gross merchandise value of $1.9 million in 2024. A partnership with a major European home goods retailer brought CraftHouse products into 180 physical stores in six countries — the first time many of Kano\'s traditional craft families have had their work in European retail. Average artisan income on the platform has increased by 340% compared to local market sales.',
      vision:
        'Fatima is building a craft school integrated with the CraftHouse platform that will teach traditional techniques to the next generation of artisans while simultaneously training them in digital marketing, pricing and international trade. She believes the future of African craft is not in museums — it is in the living rooms, offices and wardrobes of people across the world.',
    },
  },
];

const categories = ['All', 'Finance', 'Tech', 'Art & Style', 'Social Impact', 'Retail'];

// ─────────────────────────────────────────────────────────────────
// StoryModal — full-screen popup for each honoree
// ─────────────────────────────────────────────────────────────────
function StoryModal({ person, onClose }) {
  // Lock body scroll while open
  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = ''; };
  }, []);

  // Close on Escape
  useEffect(() => {
    function onKey(e) { if (e.key === 'Escape') onClose(); }
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-[200] flex items-end sm:items-center justify-center p-0 sm:p-4"
      style={{ backgroundColor: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(8px)' }}
      onClick={onClose}
    >
      <div
        className="bg-zinc-950 border border-zinc-800 w-full sm:rounded-[2rem] max-w-4xl max-h-[95vh] overflow-y-auto shadow-2xl"
        onClick={e => e.stopPropagation()}
      >
        {/* ── Modal header ─────────────────────────────────────── */}
        <div className="sticky top-0 z-10 bg-zinc-950/95 backdrop-blur-md border-b border-zinc-900 px-6 py-4 flex items-center justify-between">
          <span className="text-[9px] font-black uppercase tracking-widest text-amber-500 bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20">
            {person.category}
          </span>
          <button
            onClick={onClose}
            className="w-8 h-8 bg-zinc-800 hover:bg-zinc-700 rounded-full flex items-center justify-center text-zinc-400 hover:text-white transition-all"
          >
            <X size={16} />
          </button>
        </div>

        {/* ── Hero block ───────────────────────────────────────── */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-0">

          {/* Photo */}
          <div className="relative aspect-[3/4] sm:aspect-auto sm:min-h-[420px] overflow-hidden">
            <img
              src={person.img}
              alt={person.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/20 to-transparent" />
          </div>

          {/* Identity + stats */}
          <div className="p-8 flex flex-col justify-center bg-zinc-900">
            <p className="text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">
              {person.position}
            </p>
            <h2 className="text-3xl font-black uppercase tracking-tight text-white leading-tight mb-1">
              {person.name}
            </h2>
            <p className="text-amber-500 font-black text-sm uppercase tracking-widest mb-6">
              {person.company}
            </p>

            {/* Meta row */}
            <div className="flex flex-wrap gap-4 mb-8 text-xs text-zinc-500">
              <span className="flex items-center gap-1.5">
                <MapPin size={12} className="text-zinc-600" />
                {person.location}
              </span>
              <span className="flex items-center gap-1.5">
                <Calendar size={12} className="text-zinc-600" />
                Founded {person.founded}
              </span>
              <span className="flex items-center gap-1.5">
                <Users size={12} className="text-zinc-600" />
                Age {person.age}
              </span>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-3">
              {person.stats.map(stat => (
                <div key={stat.label} className="bg-zinc-800 rounded-xl p-3 text-center border border-zinc-700">
                  <p className="text-lg font-black text-amber-400 leading-none mb-1">{stat.value}</p>
                  <p className="text-[9px] font-black uppercase tracking-widest text-zinc-500">{stat.label}</p>
                </div>
              ))}
            </div>

            {/* Bio */}
            <p className="text-zinc-400 text-sm leading-relaxed mt-6 italic">
              "{person.bio}"
            </p>
          </div>
        </div>

        {/* ── Story sections ───────────────────────────────────── */}
        <div className="px-6 sm:px-10 py-10 space-y-10">

          {[
            { label: 'The Beginning',   icon: <Calendar size={14} />,   text: person.story.origin    },
            { label: 'Building Up',     icon: <TrendingUp size={14} />, text: person.story.growth    },
            { label: 'The Milestone',   icon: <Award size={14} />,      text: person.story.milestone },
            { label: 'What\'s Next',    icon: <ArrowRight size={14} />, text: person.story.vision    },
          ].map(section => (
            <div key={section.label} className="border-l-2 border-zinc-800 pl-6 hover:border-amber-500 transition-colors duration-300">
              <div className="flex items-center gap-2 mb-3">
                <span className="text-amber-500">{section.icon}</span>
                <p className="text-[10px] font-black uppercase tracking-widest text-zinc-500">
                  {section.label}
                </p>
              </div>
              <p className="text-zinc-300 text-sm sm:text-base leading-relaxed">
                {section.text}
              </p>
            </div>
          ))}
        </div>

        {/* ── Modal footer ─────────────────────────────────────── */}
        <div className="border-t border-zinc-900 px-8 py-6 flex justify-end">
          <button
            onClick={onClose}
            className="bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white px-6 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}


// ─────────────────────────────────────────────────────────────────
// NominationModal
// ─────────────────────────────────────────────────────────────────
// Submissions are posted to a Google Apps Script endpoint.
// Set your deployed web app URL below — same pattern as Under30App.
const NOMINATION_ENDPOINT = '/api/nominations';

const INDUSTRIES = [
  'Finance & Fintech',
  'Technology',
  'Agriculture & Food',
  'Health & MedTech',
  'Fashion & Art',
  'Media & Entertainment',
  'Logistics & Supply Chain',
  'Education & EdTech',
  'Energy & CleanTech',
  'Real Estate & PropTech',
  'Retail & E-commerce',
  'Social Impact & NGO',
  'Other',
];

function NominationModal({ onClose }) {
  const [step, setStep]           = useState(1); // 1 = nominee details, 2 = nominator details
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted]   = useState(false);
  const [error, setError]           = useState('');

  const [form, setForm] = useState({
    // Step 1 — About the nominee
    nomineeName:        '',
    nomineeAge:         '',
    nomineeCompany:     '',
    nomineePosition:    '',
    nomineeIndustry:    '',
    nomineeLocation:    '',
    achievement:        '',
    impact:             '',
    socialOrWebsite:    '',
    // Step 2 — About the nominator
    nominatorName:      '',
    nominatorEmail:     '',
    relationship:       '',
    consent:            false,
  });

  // Lock body scroll
  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = ''; };
  }, []);

  // Close on Escape
  useEffect(() => {
    function onKey(e) { if (e.key === 'Escape') onClose(); }
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [onClose]);

  function set(field, value) {
    setForm(prev => ({ ...prev, [field]: value }));
    setError('');
  }

  function validateStep1() {
    if (!form.nomineeName.trim())     return 'Nominee name is required.';
    if (!form.nomineeAge.trim())      return 'Nominee age is required.';
    if (isNaN(form.nomineeAge) || +form.nomineeAge < 16 || +form.nomineeAge > 30)
                                      return 'Age must be between 16 and 30.';
    if (!form.nomineeCompany.trim())  return 'Company or venture name is required.';
    if (!form.nomineeIndustry)        return 'Please select an industry.';
    if (!form.nomineeLocation.trim()) return 'Location is required.';
    if (!form.achievement.trim())     return 'Please describe their key achievement.';
    if (!form.impact.trim())          return 'Please describe their business impact.';
    return null;
  }

  function validateStep2() {
    if (!form.nominatorName.trim())  return 'Your name is required.';
    if (!form.nominatorEmail.trim()) return 'Your email is required.';
    if (!/\S+@\S+\.\S+/.test(form.nominatorEmail)) return 'Please enter a valid email.';
    if (!form.relationship.trim())   return 'Please describe your relationship to the nominee.';
    if (!form.consent)               return 'You must confirm the information is accurate.';
    return null;
  }

  function handleNext() {
    const err = validateStep1();
    if (err) { setError(err); return; }
    setStep(2);
    setError('');
  }

  async function handleSubmit() {
    const err = validateStep2();
    if (err) { setError(err); return; }

    setSubmitting(true);
    setError('');
    try {
      await fetch(NOMINATION_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          submittedAt: new Date().toLocaleString('en-NG', { timeZone: 'Africa/Lagos' }),
          source: 'businessrun-top30-nomination',
        }),
      });
      setSubmitted(true);
    } catch {
      setError('Network error. Please check your connection and try again.');
    } finally {
      setSubmitting(false);
    }
  }

  const inputClass = "w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-zinc-100 placeholder:text-zinc-600 focus:outline-none focus:border-amber-500 transition-colors";
  const labelClass = "block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2";

  return (
    <div
      className="fixed inset-0 z-[300] flex items-end sm:items-center justify-center p-0 sm:p-4"
      style={{ backgroundColor: 'rgba(0,0,0,0.88)', backdropFilter: 'blur(8px)' }}
      onClick={onClose}
    >
      <div
        className="bg-zinc-950 border border-zinc-800 w-full sm:rounded-[2rem] max-w-2xl max-h-[95vh] overflow-y-auto shadow-2xl"
        onClick={e => e.stopPropagation()}
      >
        {/* ── Header ───────────────────────────────────────────── */}
        <div className="sticky top-0 z-10 bg-zinc-950/95 backdrop-blur-md border-b border-zinc-900 px-6 py-4 flex items-center justify-between">
          <div>
            <p className="text-[9px] font-black uppercase tracking-widest text-amber-500">
              BusinessRun Top 30 · Class of 2026
            </p>
            <h2 className="text-white font-black text-lg uppercase italic tracking-tight mt-0.5">
              Nominate a Visionary
            </h2>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 bg-zinc-800 hover:bg-zinc-700 rounded-full flex items-center justify-center text-zinc-400 hover:text-white transition-all"
          >
            <X size={16} />
          </button>
        </div>

        {/* ── Success state ─────────────────────────────────────── */}
        {submitted ? (
          <div className="px-8 py-16 text-center">
            <div className="w-16 h-16 bg-amber-500 rounded-full flex items-center justify-center mx-auto mb-5">
              <CheckCircle size={30} className="text-black" />
            </div>
            <h3 className="text-2xl font-black italic uppercase text-white mb-3">
              Nomination Received!
            </h3>
            <p className="text-zinc-400 text-sm leading-relaxed max-w-md mx-auto mb-2">
              Thank you for nominating <strong className="text-zinc-200">{form.nomineeName}</strong>.
              Our editorial team will review all nominations and reach out if selected for the 2026 Class.
            </p>
            <p className="text-zinc-600 text-xs mt-6 uppercase tracking-widest font-black">
              Nominations close 30th June 2026
            </p>
            <button
              onClick={onClose}
              className="mt-8 px-8 py-3 bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-white hover:border-zinc-700 rounded-xl text-xs font-black uppercase tracking-widest transition"
            >
              Close
            </button>
          </div>
        ) : (
          <div className="px-6 sm:px-8 py-8">

            {/* ── Step indicator ───────────────────────────────── */}
            <div className="flex items-center gap-3 mb-8">
              {[1, 2].map(s => (
                <React.Fragment key={s}>
                  <div className={`flex items-center gap-2 ${step >= s ? 'text-amber-500' : 'text-zinc-600'}`}>
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black border transition-all ${
                      step > s  ? 'bg-amber-500 border-amber-500 text-black' :
                      step === s ? 'border-amber-500 text-amber-500' :
                                  'border-zinc-700 text-zinc-600'
                    }`}>
                      {step > s ? '✓' : s}
                    </div>
                    <span className="text-[10px] font-black uppercase tracking-widest hidden sm:block">
                      {s === 1 ? 'About the Nominee' : 'Your Details'}
                    </span>
                  </div>
                  {s < 2 && <div className={`flex-1 h-px transition-all ${step > 1 ? 'bg-amber-500' : 'bg-zinc-800'}`} />}
                </React.Fragment>
              ))}
            </div>

            {/* ── Step 1 — Nominee Details ──────────────────────── */}
            {step === 1 && (
              <div className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className={labelClass}>Full Name *</label>
                    <input
                      type="text"
                      placeholder="e.g. Adaeze Okonkwo"
                      value={form.nomineeName}
                      onChange={e => set('nomineeName', e.target.value)}
                      className={inputClass}
                    />
                  </div>
                  <div>
                    <label className={labelClass}>Age *</label>
                    <input
                      type="number"
                      placeholder="Must be 30 or under"
                      min="16" max="30"
                      value={form.nomineeAge}
                      onChange={e => set('nomineeAge', e.target.value)}
                      className={inputClass}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className={labelClass}>Company / Venture *</label>
                    <input
                      type="text"
                      placeholder="e.g. PayStack Nigeria"
                      value={form.nomineeCompany}
                      onChange={e => set('nomineeCompany', e.target.value)}
                      className={inputClass}
                    />
                  </div>
                  <div>
                    <label className={labelClass}>Position / Role</label>
                    <input
                      type="text"
                      placeholder="e.g. Founder & CEO"
                      value={form.nomineePosition}
                      onChange={e => set('nomineePosition', e.target.value)}
                      className={inputClass}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className={labelClass}>Industry *</label>
                    <select
                      value={form.nomineeIndustry}
                      onChange={e => set('nomineeIndustry', e.target.value)}
                      className={inputClass + " appearance-none cursor-pointer"}
                    >
                      <option value="">Select industry...</option>
                      {INDUSTRIES.map(ind => (
                        <option key={ind} value={ind}>{ind}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className={labelClass}>Location (City, Country) *</label>
                    <input
                      type="text"
                      placeholder="e.g. Lagos, Nigeria"
                      value={form.nomineeLocation}
                      onChange={e => set('nomineeLocation', e.target.value)}
                      className={inputClass}
                    />
                  </div>
                </div>

                <div>
                  <label className={labelClass}>Key Achievement *</label>
                  <textarea
                    rows={3}
                    placeholder="Describe their single most impressive achievement — a milestone, a number, a breakthrough. Be specific."
                    value={form.achievement}
                    onChange={e => set('achievement', e.target.value)}
                    className={inputClass + " resize-none"}
                  />
                  <p className="text-[10px] text-zinc-600 mt-1">e.g. Raised $3M, serves 50,000 users, launched in 6 countries</p>
                </div>

                <div>
                  <label className={labelClass}>Business Impact *</label>
                  <textarea
                    rows={3}
                    placeholder="How has their work changed lives, created jobs, or moved an industry? What problem are they solving at scale?"
                    value={form.impact}
                    onChange={e => set('impact', e.target.value)}
                    className={inputClass + " resize-none"}
                  />
                </div>

                <div>
                  <label className={labelClass}>Website or Social Media</label>
                  <input
                    type="text"
                    placeholder="e.g. linkedin.com/in/adaeze or @adaeze on X"
                    value={form.socialOrWebsite}
                    onChange={e => set('socialOrWebsite', e.target.value)}
                    className={inputClass}
                  />
                </div>
              </div>
            )}

            {/* ── Step 2 — Nominator Details ────────────────────── */}
            {step === 2 && (
              <div className="space-y-5">
                <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl px-5 py-4 mb-2">
                  <p className="text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-1">Nominating</p>
                  <p className="text-white font-black">{form.nomineeName}</p>
                  <p className="text-zinc-500 text-xs">{form.nomineeCompany} · {form.nomineeIndustry}</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className={labelClass}>Your Full Name *</label>
                    <input
                      type="text"
                      placeholder="Your name"
                      value={form.nominatorName}
                      onChange={e => set('nominatorName', e.target.value)}
                      className={inputClass}
                    />
                  </div>
                  <div>
                    <label className={labelClass}>Your Email *</label>
                    <input
                      type="email"
                      placeholder="you@email.com"
                      value={form.nominatorEmail}
                      onChange={e => set('nominatorEmail', e.target.value)}
                      className={inputClass}
                    />
                  </div>
                </div>

                <div>
                  <label className={labelClass}>Your Relationship to the Nominee *</label>
                  <input
                    type="text"
                    placeholder="e.g. Colleague, Investor, Mentor, Community member"
                    value={form.relationship}
                    onChange={e => set('relationship', e.target.value)}
                    className={inputClass}
                  />
                </div>

                <label className="flex items-start gap-3 cursor-pointer group">
                  <div
                    onClick={() => set('consent', !form.consent)}
                    className={`mt-0.5 w-5 h-5 rounded-md border-2 flex items-center justify-center flex-shrink-0 transition-all cursor-pointer ${
                      form.consent ? 'bg-amber-500 border-amber-500' : 'border-zinc-600 group-hover:border-zinc-400'
                    }`}
                  >
                    {form.consent && <span className="text-black text-xs font-black">✓</span>}
                  </div>
                  <span className="text-zinc-400 text-xs leading-relaxed">
                    I confirm that the information provided is accurate to the best of my knowledge,
                    and I consent to BusinessRun contacting me regarding this nomination.
                  </span>
                </label>
              </div>
            )}

            {/* ── Error message ─────────────────────────────────── */}
            {error && (
              <div className="flex items-center gap-2 mt-5 px-4 py-3 bg-red-500/10 border border-red-500/20 rounded-xl">
                <AlertCircle size={14} className="text-red-400 flex-shrink-0" />
                <p className="text-red-400 text-xs font-medium">{error}</p>
              </div>
            )}

            {/* ── Actions ───────────────────────────────────────── */}
            <div className="flex gap-3 mt-8">
              {step === 2 && (
                <button
                  onClick={() => { setStep(1); setError(''); }}
                  className="px-6 py-3 bg-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-700 rounded-xl text-xs font-black uppercase tracking-widest transition"
                >
                  Back
                </button>
              )}
              {step === 1 && (
                <button
                  onClick={handleNext}
                  className="flex-1 flex items-center justify-center gap-2 py-3 bg-amber-500 text-black font-black text-xs uppercase tracking-widest rounded-xl hover:bg-amber-400 transition active:scale-95"
                >
                  Next — Your Details <ArrowRight size={14} />
                </button>
              )}
              {step === 2 && (
                <button
                  onClick={handleSubmit}
                  disabled={submitting}
                  className="flex-1 flex items-center justify-center gap-2 py-3 bg-amber-500 text-black font-black text-xs uppercase tracking-widest rounded-xl hover:bg-amber-400 transition active:scale-95 disabled:opacity-50"
                >
                  {submitting
                    ? <><Loader2 size={14} className="animate-spin" /> Submitting...</>
                    : <><Send size={14} /> Submit Nomination</>
                  }
                </button>
              )}
            </div>

            <p className="text-[10px] text-zinc-700 text-center mt-4 uppercase tracking-widest">
              Nominations close 30th June 2026 · All submissions are reviewed by the editorial team
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// Top30Page
// ─────────────────────────────────────────────────────────────────
export default function Top30Page({ onBack }) {
  const [activeCategory, setActiveCategory]   = useState('All');
  const [selectedPerson, setSelectedPerson]   = useState(null);
  const [nominationOpen, setNominationOpen]   = useState(false);

  const filtered = honorees.filter(
    h => activeCategory === 'All' || h.category === activeCategory
  );

  return (
    <div className="min-h-screen bg-black font-sans text-zinc-100">

      {/* Story popup */}
      {selectedPerson && (
        <StoryModal
          person={selectedPerson}
          onClose={() => setSelectedPerson(null)}
        />
      )}

      {/* Nomination modal */}
      {nominationOpen && (
        <NominationModal onClose={() => setNominationOpen(false)} />
      )}

      {/* ── Breadcrumb ───────────────────────────────────────── */}
      <div className="bg-zinc-950 border-b border-zinc-900 px-4 sm:px-6 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs sm:text-sm min-w-0">
            <button onClick={onBack} className="text-zinc-500 hover:text-amber-500 transition font-bold shrink-0">
              BusinessRun
            </button>
            <span className="text-zinc-700">/</span>
            <span className="text-zinc-200 font-bold shrink-0">Top 30 Under 30</span>
          </div>
          <span className="text-xs text-zinc-500 font-medium shrink-0 ml-4">Class of 2025</span>
        </div>
      </div>

      {/* ── Hero ─────────────────────────────────────────────── */}
      <section className="relative bg-zinc-950 overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{ backgroundImage: "url('https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=2070')" }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-zinc-900/60 via-zinc-900/40 to-zinc-900" />

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-20 sm:py-28 md:py-36 text-center">
          <div className="flex justify-center items-center gap-4 mb-6">
            <div className="h-px w-10 bg-zinc-700" />
            <span className="text-zinc-500 uppercase tracking-[0.35em] text-xs font-semibold">
              Special Issue · Annual Edition
            </span>
            <div className="h-px w-10 bg-zinc-700" />
          </div>

          <h1 className="text-6xl sm:text-7xl md:text-9xl font-black italic tracking-tighter text-white leading-none uppercase mb-3">
            30
          </h1>
          <p className="text-2xl sm:text-3xl md:text-5xl font-black uppercase tracking-[0.15em] text-white mb-6">
            Under 30
          </p>
          <p className="max-w-xl mx-auto text-zinc-500 text-base sm:text-lg font-light leading-relaxed">
            The definitive annual guide to the young innovators, trailblazers,
            and disruptors shaping the Nigerian economy.
          </p>

          <div className="mt-10 sm:mt-14 flex flex-wrap justify-center gap-8 sm:gap-16">
            {[
              { value: '$140M+', label: 'Capital Raised' },
              { value: '4,500+', label: 'Jobs Created'   },
              { value: '9',      label: 'Industries'     },
            ].map(stat => (
              <div key={stat.label} className="text-left border-l-2 border-zinc-700 pl-4">
                <div className="text-xl sm:text-2xl font-bold italic text-white">{stat.value}</div>
                <div className="text-[10px] uppercase tracking-widest text-zinc-500 mt-0.5">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Category filter ───────────────────────────────────── */}
      <div className="sticky top-16 z-40 bg-zinc-950 border-b border-zinc-900 overflow-x-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center gap-6 sm:gap-8 min-w-max">
          <div className="flex items-center gap-2 text-zinc-500">
            <Filter size={13} />
            <span className="text-[10px] font-bold uppercase tracking-widest">Industry:</span>
          </div>
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`text-[11px] font-bold uppercase tracking-[0.18em] transition-all whitespace-nowrap pb-0.5 ${
                activeCategory === cat
                  ? 'text-amber-500 border-b-2 border-amber-500'
                  : 'text-zinc-500 hover:text-zinc-300'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* ── Honoree grid ─────────────────────────────────────── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-12 sm:py-16 md:py-20">
        {filtered.length === 0 ? (
          <div className="text-center py-24 text-zinc-500">
            <Award size={32} className="mx-auto mb-4 opacity-30" />
            <p className="text-sm font-medium">No honorees in this category yet.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-12 sm:gap-y-16">
            {filtered.map(person => (
              <div
                key={person.id}
                className="group cursor-pointer"
                onClick={() => setSelectedPerson(person)}
              >
                {/* Photo — NO rank number */}
                <div className="relative aspect-[3/4] overflow-hidden bg-zinc-800 rounded-xl">
                  <img
                    src={person.img}
                    alt={person.name}
                    className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 group-hover:scale-105"
                  />
                  {/* Tap hint overlay */}
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all duration-300 flex items-center justify-center">
                    <span className="opacity-0 group-hover:opacity-100 transition-all duration-300 bg-amber-500 text-black text-[9px] font-black uppercase tracking-widest px-4 py-2 rounded-full">
                      Read Story
                    </span>
                  </div>
                  {/* Category pill */}
                  <div className="absolute bottom-3 left-3">
                    <span className="bg-zinc-950/90 backdrop-blur-sm text-zinc-400 text-[10px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-full">
                      {person.category}
                    </span>
                  </div>
                </div>

                {/* Info */}
                <div className="mt-5 pl-3 border-l-2 border-transparent group-hover:border-amber-500 transition-all duration-300">
                  <div className="flex justify-between items-start gap-2">
                    <div>
                      <h3 className="text-lg font-bold uppercase tracking-tight text-zinc-100 leading-tight">
                        {person.name},{' '}
                        <span className="font-normal text-zinc-500">{person.age}</span>
                      </h3>
                      <p className="text-xs font-bold uppercase tracking-widest text-zinc-500 mt-1">
                        {person.company}
                      </p>
                    </div>
                    <Award size={18} className="text-zinc-700 group-hover:text-amber-500 transition-colors flex-shrink-0 mt-1" />
                  </div>
                  <p className="text-zinc-500 text-sm mt-3 leading-relaxed line-clamp-2">
                    {person.bio}
                  </p>
                  <div className="mt-4 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-amber-500 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-1 group-hover:translate-y-0">
                    Read Profile <ChevronRight size={12} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* ── Nomination CTA ───────────────────────────────────── */}
      <section className="bg-zinc-950 py-20 sm:py-24 mt-8">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 text-center">
          <div className="flex justify-center items-center gap-4 mb-6">
            <div className="h-px w-8 bg-zinc-700" />
            <span className="text-zinc-500 uppercase tracking-[0.3em] text-[10px] font-semibold">
              Class of 2026
            </span>
            <div className="h-px w-8 bg-zinc-700" />
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black italic uppercase tracking-tighter text-white mb-5">
            Know a Visionary?
          </h2>
          <p className="text-zinc-500 text-sm sm:text-base leading-relaxed mb-10 font-light">
            Nominations for the 2026 Class are now open. We are looking for
            the next generation of builders shaping Africa's future.
          </p>
          <button
            onClick={() => setNominationOpen(true)}
            className="group relative px-10 py-4 bg-zinc-900 border border-zinc-800 text-zinc-100 font-bold uppercase text-xs tracking-[0.25em] overflow-hidden rounded-xl hover:border-amber-500 transition-colors duration-300"
          >
            <span className="relative z-10 group-hover:text-black transition-colors duration-300">Nominate Now</span>
            <div className="absolute inset-0 bg-amber-500 rounded-xl transform translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
          </button>
        </div>
      </section>

    </div>
  );
}
