/**
 * services/auth.service.js
 *
 * All Firebase Authentication operations.
 * Controllers never call Firebase Auth directly — they call these functions.
 *
 * Firebase Auth handles all password hashing, salting, token signing,
 * and brute-force protection. We never store or manage passwords ourselves.
 *
 * The Admin SDK is used here rather than the client SDK because:
 *   - It runs on the server with full trust (no security rules)
 *   - createUser() works without a signed-in session
 *   - verifyIdToken() validates tokens cryptographically without a DB call
 *
 * For login, we use the Firebase Auth REST API (signInWithPassword endpoint)
 * because the Admin SDK does not expose a login method — it is designed
 * for admin operations, not for verifying user credentials.
 * The REST API returns an ID token we can then verify and send to the client.
 *
 * Exported functions:
 *   createFirebaseUser(email, password)  → { uid }
 *   loginWithEmailPassword(email, password) → { uid, idToken, profile }
 *   verifyIdToken(token)                 → decoded token payload
 *   deleteFirebaseUser(uid)              → void
 */

'use strict';

const { auth, admin } = require('../config/firebase');
const ApiError         = require('../utils/ApiError');

// Firebase Auth REST API — used for email/password sign-in
// (Admin SDK does not expose a login method by design)
const FIREBASE_SIGN_IN_URL =
  `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${process.env.FIREBASE_WEB_API_KEY}`;

// ─────────────────────────────────────────────────────────────────
// CREATE USER
// ─────────────────────────────────────────────────────────────────

/**
 * createFirebaseUser
 * Creates a new Firebase Auth user with email and password.
 * Called at GYB Step 4 when the user sets their password.
 *
 * Firebase Auth handles all password hashing internally.
 * We never see or store the plain-text password after this call.
 *
 * @param {string} email
 * @param {string} password   Plain text — Firebase hashes it
 * @returns {Promise<{ uid: string }>}
 * @throws {ApiError} 409 if email already exists
 */
async function createFirebaseUser(email, password) {
  // auth/email-already-exists is a Firebase error code caught
  // by the global errorHandler and mapped to a 409 response
  const userRecord = await auth.createUser({
    email:         email.toLowerCase().trim(),
    password,
    emailVerified: false,
  });

  return { uid: userRecord.uid };
}

// ─────────────────────────────────────────────────────────────────
// LOGIN
// ─────────────────────────────────────────────────────────────────

/**
 * loginWithEmailPassword
 * Authenticates a user with email and password via the Firebase
 * Auth REST API. Returns an ID token the client can store and
 * use for authenticated requests.
 *
 * The ID token is a short-lived JWT (expires in 1 hour).
 * The client should store it in memory (not localStorage) and
 * refresh it using the returned refreshToken when needed.
 *
 * @param {string} email
 * @param {string} password
 * @returns {Promise<{ uid: string, idToken: string, refreshToken: string }>}
 * @throws {ApiError} 401 if credentials are invalid
 */
async function loginWithEmailPassword(email, password) {
  if (!process.env.FIREBASE_WEB_API_KEY) {
    throw ApiError.internal(
      '[Auth] FIREBASE_WEB_API_KEY is not set. Add it to .env.'
    );
  }

  const { default: fetch } = await import('node-fetch');

  let response;
  try {
    response = await fetch(FIREBASE_SIGN_IN_URL, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email:             email.toLowerCase().trim(),
        password,
        returnSecureToken: true,
      }),
    });
  } catch (networkErr) {
    console.error('[Auth] Network error during login:', networkErr.message);
    throw new ApiError(503, 'Authentication service is temporarily unavailable.', true);
  }

  const data = await response.json();

  // Firebase returns error in data.error for wrong credentials
  if (data.error) {
    const code = data.error.message;
    console.warn('[Auth] Login failed:', code);

    // Map Firebase error codes to clean messages
    // Never reveal whether the email exists or just the password is wrong
    if (
      code === 'EMAIL_NOT_FOUND'      ||
      code === 'INVALID_PASSWORD'     ||
      code === 'INVALID_LOGIN_CREDENTIALS'
    ) {
      throw ApiError.unauthorized('Invalid email or password.');
    }

    if (code === 'USER_DISABLED') {
      throw ApiError.forbidden('This account has been disabled. Contact support.');
    }

    if (code && code.startsWith('TOO_MANY_ATTEMPTS')) {
      throw ApiError.tooManyRequests(
        'Too many failed login attempts. Please try again later.'
      );
    }

    throw ApiError.unauthorized('Login failed. Please check your credentials.');
  }

  return {
    uid:          data.localId,
    idToken:      data.idToken,
    refreshToken: data.refreshToken,
    expiresIn:    data.expiresIn,  // seconds until idToken expires (3600)
  };
}

// ─────────────────────────────────────────────────────────────────
// VERIFY TOKEN
// ─────────────────────────────────────────────────────────────────

/**
 * verifyIdToken
 * Validates a Firebase ID token and returns the decoded claims.
 * Used by the auth middleware on every protected request.
 *
 * This is a cryptographic verification — no network call or database
 * lookup is needed. Google's public keys are cached by the Admin SDK.
 *
 * @param {string} token
 * @returns {Promise<Object>}  Decoded token payload { uid, email, ... }
 * @throws {ApiError} 401 if token is invalid or expired
 */
async function verifyIdToken(token) {
  try {
    return await auth.verifyIdToken(token);
  } catch (err) {
    // Let the errorHandler map Firebase error codes to clean responses
    throw err;
  }
}

// ─────────────────────────────────────────────────────────────────
// DELETE USER  (admin use only)
// ─────────────────────────────────────────────────────────────────

/**
 * deleteFirebaseUser
 * Permanently deletes a Firebase Auth user.
 * Not called from any route currently — reserved for future
 * account deletion functionality.
 *
 * @param {string} uid
 */
async function deleteFirebaseUser(uid) {
  await auth.deleteUser(uid);
}

// ─────────────────────────────────────────────────────────────────
// GET USER RECORD  (Admin SDK lookup by UID or email)
// ─────────────────────────────────────────────────────────────────

/**
 * getAuthUserByEmail
 * Looks up a Firebase Auth user record by email.
 * Used to check if an email already has an Auth account
 * before creating a new one.
 *
 * @param {string} email
 * @returns {Promise<Object|null>}  Firebase UserRecord or null
 */
async function getAuthUserByEmail(email) {
  try {
    return await auth.getUserByEmail(email.toLowerCase().trim());
  } catch (err) {
    if (err.code === 'auth/user-not-found') return null;
    throw err;
  }
}

module.exports = {
  createFirebaseUser,
  loginWithEmailPassword,
  verifyIdToken,
  deleteFirebaseUser,
  getAuthUserByEmail,
};
