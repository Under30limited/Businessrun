/**
 * services/firebase.service.js
 *
 * All Firestore database operations for BusinessRun.
 * Controllers never call Firestore directly — they call these functions.
 *
 * Collections managed here:
 *   users                — GYB onboarding profiles (one doc per user)
 *   nominations          — Top 30 nominations
 *   subscribers          — Capital Club + resource requests
 *   under30applications  — Under30Women mentorship applications
 *   advisorSessions      — AI Advisor conversation history
 *
 * Every write uses server timestamps (admin.firestore.FieldValue.serverTimestamp())
 * rather than Date objects from the frontend. This ensures all timestamps
 * are consistent, UTC, and cannot be spoofed by client clocks.
 *
 * Exported functions:
 *
 *   -- Users / GYB --
 *   createGybSession(sessionId, data)
 *   updateGybSession(sessionId, data)
 *   promoteSessionToUser(sessionId, uid, passwordData)
 *   getUserByUid(uid)
 *   getUserByEmail(email)
 *   getUserBySessionId(sessionId)
 *
 *   -- Nominations --
 *   createNomination(data)
 *
 *   -- Subscribers --
 *   createSubscriber(data)
 *   subscriberExists(email, type)
 *
 *   -- Under30 --
 *   createUnder30Application(data)
 *
 *   -- Advisor Sessions --
 *   getAdvisorSession(sessionId)
 *   upsertAdvisorSession(sessionId, userId, messages)
 */

'use strict';

const { db, admin } = require('../config/firebase');
const ApiError       = require('../utils/ApiError');

const FieldValue = admin.firestore.FieldValue;

// ── Collection name constants ─────────────────────────────────────
const COLLECTIONS = {
  USERS:       'users',
  NOMINATIONS: 'nominations',
  SUBSCRIBERS: 'subscribers',
  UNDER30:     'under30applications',
  ADVISOR:     'advisorSessions',
};

// ─────────────────────────────────────────────────────────────────
// USERS / GYB ONBOARDING
// ─────────────────────────────────────────────────────────────────

/**
 * createGybSession
 * Called at GYB Step 1 (name, business, email).
 * Creates a new Firestore document keyed by sessionId.
 * The document is temporary — it gets promoted to a real user doc
 * (keyed by Firebase Auth UID) when the user sets their password.
 *
 * @param {string} sessionId  Temporary session key from the frontend
 * @param {Object} data       { fullName, businessName, email, source }
 */
async function createGybSession(sessionId, data) {
  const ref = db.collection(COLLECTIONS.USERS).doc(sessionId);

  // Check if a session with this ID already exists (duplicate submission)
  const existing = await ref.get();
  if (existing.exists) {
    // Idempotent — update rather than throw
    await ref.update({
      fullName:     data.fullName,
      businessName: data.businessName,
      email:        data.email,
      updatedAt:    FieldValue.serverTimestamp(),
    });
    return;
  }

  await ref.set({
    sessionId,
    fullName:        data.fullName,
    businessName:    data.businessName,
    email:           data.email,
    onboardingStep:  1,
    completed:       false,
    profileSaved:    false,
    source:          data.source || 'businessrun-gyb',
    createdAt:       FieldValue.serverTimestamp(),
    updatedAt:       FieldValue.serverTimestamp(),
  });
}

/**
 * updateGybSession
 * Called at GYB Steps 2 and 3.
 * Updates the existing session document with new fields.
 * Uses merge:true so existing fields are preserved.
 *
 * @param {string} sessionId
 * @param {Object} data   Fields to update + step number
 */
async function updateGybSession(sessionId, data) {
  const ref = db.collection(COLLECTIONS.USERS).doc(sessionId);

  const existing = await ref.get();
  if (!existing.exists) {
    // Session not found — could be a network retry after step 1 failed silently
    // Create a recovery document so data is not lost
    console.warn(`[Firebase] updateGybSession: session ${sessionId} not found — creating recovery doc`);
    await ref.set({
      sessionId,
      ...data,
      onboardingStep: data.onboardingStep || 2,
      completed:      false,
      profileSaved:   false,
      createdAt:      FieldValue.serverTimestamp(),
      updatedAt:      FieldValue.serverTimestamp(),
    });
    return;
  }

  await ref.update({
    ...data,
    updatedAt: FieldValue.serverTimestamp(),
  });
}

/**
 * promoteSessionToUser
 * Called at GYB Step 4 (password set).
 * The temporary sessionId document is copied to a new document
 * keyed by the Firebase Auth UID, then the old doc is deleted.
 * This is the moment the user becomes a permanent, identifiable record.
 *
 * @param {string} sessionId   The temporary document ID
 * @param {string} uid         Firebase Auth UID
 * @param {Object} extraData   { profileSavedAt }
 */
async function promoteSessionToUser(sessionId, uid, extraData = {}) {
  const sessionRef = db.collection(COLLECTIONS.USERS).doc(sessionId);
  const userRef    = db.collection(COLLECTIONS.USERS).doc(uid);

  // Run in a Firestore transaction so both operations succeed or both fail
  await db.runTransaction(async (txn) => {
    const sessionDoc = await txn.get(sessionRef);

    if (!sessionDoc.exists) {
      throw ApiError.notFound(
        `GYB session ${sessionId} not found during promotion.`
      );
    }

    const sessionData = sessionDoc.data();

    // Write permanent user doc keyed by Firebase Auth UID
    txn.set(userRef, {
      ...sessionData,
      uid,
      sessionId,           // keep the original sessionId for reference
      onboardingStep:  4,
      completed:       true,
      profileSaved:    true,
      profileSavedAt:  extraData.profileSavedAt || FieldValue.serverTimestamp(),
      updatedAt:       FieldValue.serverTimestamp(),
    });

    // Delete the temporary session doc
    txn.delete(sessionRef);
  });
}

/**
 * getUserByUid
 * Fetches a user document by Firebase Auth UID.
 *
 * @param {string} uid
 * @returns {Promise<Object|null>}
 */
async function getUserByUid(uid) {
  const doc = await db.collection(COLLECTIONS.USERS).doc(uid).get();
  if (!doc.exists) return null;
  return { id: doc.id, ...doc.data() };
}

/**
 * getUserByEmail
 * Queries the users collection for a document with a matching email.
 * Used when looking up a user before returning their profile on login.
 *
 * @param {string} email
 * @returns {Promise<Object|null>}
 */
async function getUserByEmail(email) {
  const snapshot = await db
    .collection(COLLECTIONS.USERS)
    .where('email', '==', email.toLowerCase().trim())
    .limit(1)
    .get();

  if (snapshot.empty) return null;
  const doc = snapshot.docs[0];
  return { id: doc.id, ...doc.data() };
}

/**
 * getUserBySessionId
 * Looks up a user document by sessionId field.
 * Useful for verifying a session exists before step updates.
 *
 * @param {string} sessionId
 * @returns {Promise<Object|null>}
 */
async function getUserBySessionId(sessionId) {
  // First try direct doc lookup (session docs are keyed by sessionId)
  const directDoc = await db
    .collection(COLLECTIONS.USERS)
    .doc(sessionId)
    .get();

  if (directDoc.exists) {
    return { id: directDoc.id, ...directDoc.data() };
  }

  // Fall back to a field query (promoted user docs have sessionId as a field)
  const snapshot = await db
    .collection(COLLECTIONS.USERS)
    .where('sessionId', '==', sessionId)
    .limit(1)
    .get();

  if (snapshot.empty) return null;
  const doc = snapshot.docs[0];
  return { id: doc.id, ...doc.data() };
}

// ─────────────────────────────────────────────────────────────────
// NOMINATIONS
// ─────────────────────────────────────────────────────────────────

/**
 * createNomination
 * Writes a new Top 30 nomination to Firestore.
 * Firestore auto-generates the document ID.
 *
 * @param {Object} data  All nomination form fields (already sanitised)
 * @returns {Promise<{ id: string }>}  The new document ID
 */
async function createNomination(data) {
  const ref = await db.collection(COLLECTIONS.NOMINATIONS).add({
    ...data,
    status:      'Pending',
    submittedAt: FieldValue.serverTimestamp(),
  });
  return { id: ref.id };
}

// ─────────────────────────────────────────────────────────────────
// SUBSCRIBERS
// ─────────────────────────────────────────────────────────────────

/**
 * subscriberExists
 * Checks whether an email has already subscribed for a given type.
 * Prevents duplicate entries in the subscribers collection.
 *
 * @param {string} email
 * @param {string} type  'capital-club' | 'resource-request'
 * @returns {Promise<boolean>}
 */
async function subscriberExists(email, type) {
  const snapshot = await db
    .collection(COLLECTIONS.SUBSCRIBERS)
    .where('email', '==', email.toLowerCase().trim())
    .where('type',  '==', type)
    .limit(1)
    .get();

  return !snapshot.empty;
}

/**
 * createSubscriber
 * Writes a new subscriber document.
 * Should be called only after subscriberExists() returns false.
 *
 * @param {Object} data  { email, type, resource, source }
 * @returns {Promise<{ id: string }>}
 */
async function createSubscriber(data) {
  const ref = await db.collection(COLLECTIONS.SUBSCRIBERS).add({
    email:        data.email.toLowerCase().trim(),
    type:         data.type,
    resource:     data.resource || null,
    source:       data.source   || 'businessrun-website',
    subscribedAt: FieldValue.serverTimestamp(),
  });
  return { id: ref.id };
}

// ─────────────────────────────────────────────────────────────────
// UNDER30 APPLICATIONS
// ─────────────────────────────────────────────────────────────────

/**
 * createUnder30Application
 * Writes a new Under30Women application to Firestore.
 *
 * @param {Object} data  All Under30App form fields (already sanitised)
 * @returns {Promise<{ id: string }>}
 */
async function createUnder30Application(data) {
  const ref = await db.collection(COLLECTIONS.UNDER30).add({
    ...data,
    status:      'Pending',
    submittedAt: FieldValue.serverTimestamp(),
  });
  return { id: ref.id };
}

// ─────────────────────────────────────────────────────────────────
// ADVISOR SESSIONS
// ─────────────────────────────────────────────────────────────────

/**
 * getAdvisorSession
 * Fetches an advisor conversation session by its sessionId.
 *
 * @param {string} sessionId
 * @returns {Promise<Object|null>}
 */
async function getAdvisorSession(sessionId) {
  const doc = await db
    .collection(COLLECTIONS.ADVISOR)
    .doc(sessionId)
    .get();

  if (!doc.exists) return null;
  return { id: doc.id, ...doc.data() };
}

/**
 * upsertAdvisorSession
 * Creates or updates an advisor conversation session.
 * Each message is appended to the messages array.
 *
 * @param {string}    sessionId
 * @param {string|null} userId   Firebase Auth UID (null for anonymous)
 * @param {Object[]}  messages   Full messages array including new message
 */
async function upsertAdvisorSession(sessionId, userId, messages) {
  const ref = db.collection(COLLECTIONS.ADVISOR).doc(sessionId);

  await ref.set(
    {
      userId,
      messages,
      updatedAt: FieldValue.serverTimestamp(),
    },
    { merge: true } // creates if not exists, updates if it does
  );

  // Set createdAt only if this is a new document (merge won't overwrite it
  // if it already exists, but set with merge on a new doc won't set it either)
  const doc = await ref.get();
  if (!doc.data().createdAt) {
    await ref.update({ createdAt: FieldValue.serverTimestamp() });
  }
}

module.exports = {
  // Users / GYB
  createGybSession,
  updateGybSession,
  promoteSessionToUser,
  getUserByUid,
  getUserByEmail,
  getUserBySessionId,

  // Nominations
  createNomination,

  // Subscribers
  subscriberExists,
  createSubscriber,

  // Under30
  createUnder30Application,

  // Advisor Sessions
  getAdvisorSession,
  upsertAdvisorSession,
};
