/**
 * routes/auth.routes.js
 *
 * POST /api/auth/register   → Create account (called internally by gyb/password)
 * POST /api/auth/login      → Login with email + password
 * GET  /api/auth/me         → Get current user profile (protected)
 */

'use strict';

const express    = require('express');
const router     = express.Router();
const controller = require('../controllers/auth.controller');
const { protect }    = require('../middleware/auth');
const { authLimiter } = require('../middleware/rateLimiter');
const validate   = require('../middleware/validate');

// Validation schemas
const loginSchema = {
  email:    { required: true,  type: 'email' },
  password: { required: true,  type: 'string', min: 6 },
};

const registerSchema = {
  email:     { required: true,  type: 'email' },
  password:  { required: true,  type: 'string', min: 6 },
  sessionId: { required: true,  type: 'string' },
};

router.post('/register',
  authLimiter,
  validate(registerSchema),
  controller.register
);

router.post('/login',
  authLimiter,
  validate(loginSchema),
  controller.login
);

router.get('/me',
  protect,
  controller.getMe
);

module.exports = router;
