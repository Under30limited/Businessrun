/**
 * routes/gyb.routes.js
 *
 * POST /api/gyb          → Steps 1, 2, 3 (progressive onboarding save)
 * POST /api/gyb/password → Step 4 (create Firebase Auth user + promote session)
 */

'use strict';

const express    = require('express');
const router     = express.Router();
const controller = require('../controllers/gyb.controller');
const { dataLimiter } = require('../middleware/rateLimiter');

// Both routes share the same data limiter (20 req / hour per IP)
// A single full onboarding makes 4 requests — limit is never hit legitimately

router.post('/',
  dataLimiter,
  controller.saveStep
);

router.post('/password',
  dataLimiter,
  controller.savePassword
);

module.exports = router;
