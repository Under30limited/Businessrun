/**
 * controllers/gyb.controller.js
 *
 * Handles the Grow Your Business onboarding flow.
 * Steps 1-3 write to a temporary Firestore session doc.
 * Step 4 (password) creates a Firebase Auth user and promotes the doc.
 *
 * Routes:
 *   POST /api/gyb          → saveStep (steps 1, 2, 3)
 *   POST /api/gyb/password → savePassword (step 4 — creates account)
 */

'use strict';

const asyncHandler    = require('../utils/asyncHandler');
const ApiError        = require('../utils/ApiError');
const { sanitise, requireFields, isValidEmail } = require('../utils/sanitise');
const firebaseService = require('../services/firebase.service');
const authService     = require('../services/auth.service');

// ── Allowed fields per step ───────────────────────────────────────
const STEP_FIELDS = {
  1: ['sessionId', 'fullName', 'businessName', 'email', 'startedAt', 'source'],
  2: ['sessionId', 'stage', 'salesChannel', 'revenue', 'headache'],
  3: ['sessionId', 'matchmaking', 'completedAt'],
};

const VALID_STAGES   = ['Ideation', 'Launch', 'Scaling', 'Established'];
const VALID_CHANNELS = ['Social Media', 'Physical Store', 'E-commerce', 'B2B/Referrals'];
const VALID_REVENUES = ['Under ₦500k', '₦500k – ₦2M', '₦2M – ₦10M', 'Over ₦10M'];
const VALID_HEADACHES = [
  'Pricing for Profit',
  'Tracking Cashflow',
  'Accessing Credit/Loans',
  'Managing Staff/Payroll',
];

// ── POST /api/gyb ─────────────────────────────────────────────────
// Handles all three onboarding steps.
// The `step` field in the body determines which Firestore operation runs.
const saveStep = asyncHandler(async (req, res) => {
  const step = parseInt(req.body?.step);

  if (![1, 2, 3].includes(step)) {
    throw ApiError.badRequest('Invalid step. Must be 1, 2, or 3.');
  }

  const body = sanitise(req.body, [...STEP_FIELDS[step], 'step']);
  requireFields(body, ['sessionId']);

  // ── Step 1 — Identity ─────────────────────────────────────────
  if (step === 1) {
    requireFields(body, ['fullName', 'businessName', 'email']);

    if (!isValidEmail(body.email)) {
      throw ApiError.badRequest('Invalid email address.');
    }

    await firebaseService.createGybSession(body.sessionId, {
      fullName:     body.fullName.trim(),
      businessName: body.businessName.trim(),
      email:        body.email.toLowerCase().trim(),
      source:       body.source || 'businessrun-gyb',
    });
  }

  // ── Step 2 — Business Pulse ───────────────────────────────────
  if (step === 2) {
    requireFields(body, ['stage', 'salesChannel', 'revenue', 'headache']);

    if (!VALID_STAGES.includes(body.stage)) {
      throw ApiError.badRequest(`Invalid stage: "${body.stage}".`);
    }
    if (!VALID_CHANNELS.includes(body.salesChannel)) {
      throw ApiError.badRequest(`Invalid sales channel: "${body.salesChannel}".`);
    }
    if (!VALID_REVENUES.includes(body.revenue)) {
      throw ApiError.badRequest(`Invalid revenue bracket: "${body.revenue}".`);
    }
    if (!VALID_HEADACHES.includes(body.headache)) {
      throw ApiError.badRequest(`Invalid headache: "${body.headache}".`);
    }

    await firebaseService.updateGybSession(body.sessionId, {
      stage:          body.stage,
      salesChannel:   body.salesChannel,
      revenue:        body.revenue,
      headache:       body.headache,
      onboardingStep: 2,
    });
  }

  // ── Step 3 — Trust & Matchmaking ─────────────────────────────
  if (step === 3) {
    requireFields(body, ['matchmaking']);

    const validMatchmaking = ['Yes, help me scale', "No, I'll manage on my own"];
    if (!validMatchmaking.includes(body.matchmaking)) {
      throw ApiError.badRequest('Invalid matchmaking response.');
    }

    await firebaseService.updateGybSession(body.sessionId, {
      matchmaking:    body.matchmaking,
      onboardingStep: 3,
      completedAt:    body.completedAt || new Date().toISOString(),
    });
  }

  res.json({ success: true, step });
});

// ── POST /api/gyb/password ────────────────────────────────────────
// Step 4 — creates the Firebase Auth user and promotes the
// temporary session doc to a permanent user doc keyed by UID.
const savePassword = asyncHandler(async (req, res) => {
  const body = sanitise(req.body, [
    'sessionId', 'email', 'password', 'profileSavedAt',
  ]);
  requireFields(body, ['sessionId', 'email', 'password']);

  if (!isValidEmail(body.email)) {
    throw ApiError.badRequest('Invalid email address.');
  }
  if (typeof body.password !== 'string' || body.password.length < 6) {
    throw ApiError.badRequest('Password must be at least 6 characters.');
  }

  // Verify the session exists before creating an Auth user
  const session = await firebaseService.getUserBySessionId(body.sessionId);
  if (!session) {
    throw ApiError.notFound(
      'Onboarding session not found. Please complete the previous steps.'
    );
  }

  // Guard: check if a Firebase Auth account already exists for this email
  // (user may have refreshed and resubmitted step 4)
  const existingAuthUser = await authService.getAuthUserByEmail(body.email);

  let uid;
  if (existingAuthUser) {
    // Auth user already exists — this is a duplicate submission.
    // Use the existing UID and skip user creation.
    uid = existingAuthUser.uid;
  } else {
    // Create new Firebase Auth user — password is hashed by Firebase
    const created = await authService.createFirebaseUser(body.email, body.password);
    uid = created.uid;
  }

  // Promote Firestore session doc to permanent user doc
  await firebaseService.promoteSessionToUser(body.sessionId, uid, {
    profileSavedAt: body.profileSavedAt,
  });

  res.status(201).json({ success: true });
});

module.exports = { saveStep, savePassword };
