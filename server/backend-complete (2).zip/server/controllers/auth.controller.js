/**
 * controllers/auth.controller.js
 *
 * Handles user registration (via GYB password step),
 * login, and profile retrieval.
 *
 * Flow:
 *   register → createFirebaseUser → promoteSessionToUser → { success }
 *   login    → loginWithEmailPassword → getUserByEmail → { profile, idToken }
 *   getMe    → getUserByUid → { profile }
 */

'use strict';

const asyncHandler    = require('../utils/asyncHandler');
const ApiError        = require('../utils/ApiError');
const { sanitise, requireFields, isValidEmail } = require('../utils/sanitise');
const authService     = require('../services/auth.service');
const firebaseService = require('../services/firebase.service');

// ── POST /api/auth/register ───────────────────────────────────────
// Called from GYB Step 4 (/api/gyb/password route) — not a direct
// frontend call. Kept here for separation of concerns.
// Creates the Firebase Auth user and promotes the Firestore session doc.
const register = asyncHandler(async (req, res) => {
  const body = sanitise(req.body, ['email', 'password', 'sessionId', 'profileSavedAt']);
  requireFields(body, ['email', 'password', 'sessionId']);

  if (!isValidEmail(body.email)) {
    throw ApiError.badRequest('Invalid email address.');
  }
  if (body.password.length < 6) {
    throw ApiError.badRequest('Password must be at least 6 characters.');
  }

  // Check if a Firebase Auth account already exists for this email
  const existingAuthUser = await authService.getAuthUserByEmail(body.email);
  if (existingAuthUser) {
    throw new ApiError(409, 'An account with this email already exists.');
  }

  // Create Firebase Auth user — Firebase handles password hashing
  const { uid } = await authService.createFirebaseUser(body.email, body.password);

  // Promote the temporary Firestore session doc to a permanent user doc
  await firebaseService.promoteSessionToUser(body.sessionId, uid, {
    profileSavedAt: body.profileSavedAt,
  });

  res.status(201).json({ success: true, uid });
});

// ── POST /api/auth/login ──────────────────────────────────────────
// Called from GrowYourBusinessModal login form.
// Returns the user's Firestore profile + Firebase ID token.
const login = asyncHandler(async (req, res) => {
  const body = sanitise(req.body, ['email', 'password']);
  requireFields(body, ['email', 'password']);

  if (!isValidEmail(body.email)) {
    throw ApiError.badRequest('Invalid email address.');
  }

  // Verify credentials via Firebase Auth REST API
  const authResult = await authService.loginWithEmailPassword(
    body.email,
    body.password
  );

  // Fetch the user's Firestore profile to send back to the frontend
  // so it can populate the roadmap page without an extra request
  const profile = await firebaseService.getUserByUid(authResult.uid);

  if (!profile) {
    // Auth succeeded but no Firestore doc — edge case where account exists
    // in Firebase Auth but onboarding was never completed
    return res.json({
      success: true,
      idToken:      authResult.idToken,
      refreshToken: authResult.refreshToken,
      expiresIn:    authResult.expiresIn,
      profile:      { uid: authResult.uid, email: body.email },
    });
  }

  res.json({
    success: true,
    idToken:      authResult.idToken,
    refreshToken: authResult.refreshToken,
    expiresIn:    authResult.expiresIn,
    profile: {
      uid:          profile.uid,
      fullName:     profile.fullName,
      businessName: profile.businessName,
      email:        profile.email,
      stage:        profile.profile?.stage        ?? profile.stage,
      salesChannel: profile.profile?.salesChannel ?? profile.salesChannel,
      revenue:      profile.profile?.revenue      ?? profile.revenue,
      headache:     profile.profile?.headache     ?? profile.headache,
      matchmaking:  profile.profile?.matchmaking  ?? profile.matchmaking,
    },
  });
});

// ── GET /api/auth/me ──────────────────────────────────────────────
// Protected route — requires valid Firebase ID token.
// Returns the current user's full Firestore profile.
const getMe = asyncHandler(async (req, res) => {
  // req.user is set by the protect middleware
  const profile = await firebaseService.getUserByUid(req.user.uid);

  if (!profile) {
    throw ApiError.notFound('User profile not found.');
  }

  res.json({ success: true, profile });
});

module.exports = { register, login, getMe };
