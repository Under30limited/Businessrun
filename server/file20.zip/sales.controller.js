/**
 * controllers/sales.controller.js
 *
 * Sales Day Book — record sales, auto-deduct inventory, fetch history.
 *
 * All routes protected — valid JWT cookie required.
 *
 * Routes:
 *   GET  /api/sales          — fetch all sales (optional ?from=&to= date filter)
 *   POST /api/sales          — record a sale + deduct inventory stock server-side
 *
 * WHY stock deduction happens here (not in inventory controller):
 *   A sale and its stock deduction are one atomic business event.
 *   Handling both in one endpoint means if the stock update fails,
 *   the sale record is not written either — no orphaned data.
 *   The inventory PATCH endpoint is reused internally (same logic,
 *   no duplicate code) by calling firebaseService.updateInventoryItem.
 */

'use strict';

const asyncHandler    = require('../utils/asyncHandler');
const ApiError        = require('../utils/ApiError');
const { sanitise, requireFields } = require('../utils/sanitise');
const firebaseService = require('../services/firebase.service');

// ── GET /api/sales ────────────────────────────────────────────────
/**
 * Returns all sales for the logged-in user, newest first.
 * Optional query params:
 *   ?from=2024-01-01   ISO date string — start of range
 *   ?to=2024-01-31     ISO date string — end of range
 *
 * Response: { success: true, sales: [...] }
 */
const getSales = asyncHandler(async (req, res) => {
  const uid = req.user.uid;

  let fromDate, toDate;
  if (req.query.from) {
    fromDate = new Date(req.query.from);
    if (isNaN(fromDate)) throw ApiError.badRequest('Invalid "from" date format. Use ISO format: YYYY-MM-DD.');
    fromDate.setHours(0, 0, 0, 0);
  }
  if (req.query.to) {
    toDate = new Date(req.query.to);
    if (isNaN(toDate)) throw ApiError.badRequest('Invalid "to" date format. Use ISO format: YYYY-MM-DD.');
    toDate.setHours(23, 59, 59, 999);
  }

  const sales = await firebaseService.getSales(uid, fromDate, toDate);
  res.json({ success: true, sales });
});

// ── POST /api/sales ───────────────────────────────────────────────
/**
 * Records a sale and atomically deducts stock from the inventory item.
 *
 * Flow:
 *   1. Validate request body
 *   2. Fetch the inventory item to verify it exists and has enough stock
 *   3. Write the sale record to Firestore
 *   4. Deduct the quantity from inventory via updateInventoryItem
 *      (same service function used by PATCH /api/inventory/:id)
 *   5. Return the saved sale + updated inventory quantity
 *
 * Body:
 *   { inventoryItemId, itemName, unitPrice, salePrice, quantity }
 *
 * Response:
 *   { success: true, sale: {...}, updatedQuantity: number }
 */
const logSale = asyncHandler(async (req, res) => {
  const uid  = req.user.uid;
  const body = sanitise(req.body, [
    'items', 'buyerName', 'businessName',
  ]);
  requireFields(body, ['items']);

  // items is an array of { inventoryItemId, itemName, unitPrice, salePrice, quantity }
  if (!Array.isArray(body.items) || body.items.length === 0) {
    throw ApiError.badRequest('At least one item is required.');
  }

  const buyerName    = (body.buyerName    || '').trim();
  const businessName = (body.businessName || '').trim();

  // ── Validate each line item ───────────────────────────────────────
  const validatedItems = body.items.map((line, idx) => {
    const quantity  = parseInt(line.quantity,  10);
    const salePrice = parseFloat(line.salePrice);
    const unitPrice = parseFloat(line.unitPrice);
    if (!line.inventoryItemId)          throw ApiError.badRequest(`Item ${idx + 1}: inventoryItemId is required.`);
    if (isNaN(quantity)  || quantity  <= 0) throw ApiError.badRequest(`Item ${idx + 1}: quantity must be a positive integer.`);
    if (isNaN(salePrice) || salePrice <  0) throw ApiError.badRequest(`Item ${idx + 1}: salePrice must be a positive number.`);
    if (isNaN(unitPrice) || unitPrice <  0) throw ApiError.badRequest(`Item ${idx + 1}: unitPrice must be a positive number.`);
    return {
      inventoryItemId: line.inventoryItemId,
      itemName:        (line.itemName || '').trim(),
      unitPrice,
      salePrice,
      quantity,
      totalAmount:     parseFloat((salePrice * quantity).toFixed(2)),
    };
  });

  // ── Fetch all inventory items once — validate stock for each line ─
  const inventoryItems = await firebaseService.getInventoryItems(uid);
  const stockUpdates   = []; // { id, newQuantity }

  for (const line of validatedItems) {
    const inv = inventoryItems.find(i => i.id === line.inventoryItemId);
    if (!inv) throw ApiError.badRequest(`"${line.itemName}" not found in inventory. It may have been deleted.`);
    if (inv.quantity < line.quantity) {
      throw ApiError.badRequest(
        `Insufficient stock for "${line.itemName}". ` +
        `Available: ${inv.quantity}, requested: ${line.quantity}.`
      );
    }
    stockUpdates.push({ id: line.inventoryItemId, newQuantity: inv.quantity - line.quantity });
  }

  const grandTotal = validatedItems.reduce((s, l) => s + l.totalAmount, 0);

  // ── Write sale record ─────────────────────────────────────────────
  const sale = await firebaseService.recordSale(uid, {
    items:         validatedItems,
    buyerName,
    businessName,
    totalAmount:   parseFloat(grandTotal.toFixed(2)),
    // Keep legacy flat fields for backwards compat with existing records
    inventoryItemId: validatedItems[0].inventoryItemId,
    itemName:        validatedItems.length === 1 ? validatedItems[0].itemName : `${validatedItems.length} items`,
    unitPrice:       validatedItems[0].unitPrice,
    salePrice:       validatedItems[0].salePrice,
    quantity:        validatedItems.reduce((s, l) => s + l.quantity, 0),
  });

  // ── Deduct stock for every line item ──────────────────────────────
  await Promise.all(
    stockUpdates.map(({ id, newQuantity }) =>
      firebaseService.updateInventoryItem(uid, id, { quantity: newQuantity })
    )
  );

  // Return sale + stock updates so frontend can update all items at once
  res.status(201).json({
    success:      true,
    sale,
    stockUpdates, // [{ id, newQuantity }]
  });
});

module.exports = { getSales, logSale };
