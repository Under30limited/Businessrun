/**
 * SalesDayBook.jsx
 *
 * Updates in this version:
 *   - Multi-item cart: add multiple products in one sale
 *   - Buyer name (manual) + seller name auto-filled from user profile
 *   - Downloadable receipt per sale row (window.print)
 *   - Receipt pre-filled from sale data — mirrors ReceiptGenerator design
 */

import React, { useState, useMemo } from 'react';
import {
  ShoppingBag, TrendingUp, Package,
  Loader2, AlertCircle, CheckCircle,
  ChevronDown, Calendar, ArrowRight,
  Receipt, Plus, X, Download, User,
} from 'lucide-react';

const inputClass = 'w-full bg-black border border-zinc-800 rounded-xl px-4 py-3 text-sm text-zinc-100 placeholder:text-zinc-600 focus:outline-none focus:border-amber-500 transition-colors';

// ── Date helpers ──────────────────────────────────────────────────
function todayISO() { return new Date().toISOString().slice(0, 10); }
function isToday(iso) { return iso ? iso.slice(0, 10) === todayISO() : false; }
function formatDate(iso) {
  if (!iso) return '—';
  return new Date(iso).toLocaleString('en-NG', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
}
function receiptDate(iso) {
  const d = iso ? new Date(iso) : new Date();
  return d.toLocaleDateString('en-NG', { day: '2-digit', month: 'long', year: 'numeric' });
}
function receiptId(id) {
  return 'INV-' + String(id || Date.now()).slice(-8).toUpperCase();
}

// ── Empty cart line ───────────────────────────────────────────────
const emptyLine = () => ({
  _key:            Date.now() + Math.random(),
  inventoryItemId: '',
  itemName:        '',
  unitPrice:       0,
  salePrice:       '',
  quantity:        '',
});

// ─────────────────────────────────────────────────────────────────
// RECEIPT CANVAS
// Hidden in normal view, becomes visible only during window.print().
// Mirrors the ReceiptGenerator layout from the home page exactly.
// ─────────────────────────────────────────────────────────────────
function SaleReceipt({ sale, businessName }) {
  const lines = sale.items && sale.items.length > 0
    ? sale.items
    : [{ itemName: sale.itemName, quantity: sale.quantity, salePrice: sale.salePrice, totalAmount: sale.totalAmount }];

  const grandTotal = sale.totalAmount || 0;
  const fmt = n => '₦' + Number(n || 0).toLocaleString('en-NG', { minimumFractionDigits: 2 });

  return (
    <div id="sale-receipt-canvas" style={{
      background: '#ffffff', width: '210mm',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
      color: '#18181b', borderRadius: '16px', border: '1px solid #e4e4e7', overflow: 'hidden',
    }}>
      {/* Dark header */}
      <div style={{ background: '#18181b', padding: '40px 48px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div>
            <div style={{ width: 40, height: 40, background: '#fff', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 16 }}>
              <span style={{ color: '#18181b', fontWeight: 900, fontSize: 14 }}>B</span>
            </div>
            <h2 style={{ color: '#fff', fontWeight: 900, fontSize: 22, margin: 0, letterSpacing: '-0.03em' }}>
              {businessName || 'Your Business'}
            </h2>
            {sale.buyerName && (
              <p style={{ color: '#a1a1aa', fontSize: 12, margin: '4px 0 0' }}>Issued to: {sale.buyerName}</p>
            )}
          </div>
          <div style={{ textAlign: 'right' }}>
            <p style={{ color: 'rgba(255,255,255,0.1)', fontSize: 48, fontWeight: 900, margin: '0 0 8px', letterSpacing: '-0.04em', textTransform: 'uppercase' }}>Invoice</p>
            <p style={{ color: '#fff', fontWeight: 700, fontSize: 15, margin: 0 }}>{receiptId(sale.id)}</p>
            <p style={{ color: '#a1a1aa', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.1em', margin: '4px 0 0' }}>{receiptDate(sale.saleDate || sale.saleDateISO)}</p>
          </div>
        </div>
      </div>

      {/* Bill to bar */}
      <div style={{ background: '#f4f4f5', padding: '16px 48px', borderBottom: '1px solid #e4e4e7', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <span style={{ fontSize: 9, fontWeight: 900, color: '#a1a1aa', textTransform: 'uppercase', letterSpacing: '0.2em', display: 'block', marginBottom: 4 }}>Bill To</span>
          <p style={{ fontWeight: 700, fontSize: 15, margin: 0 }}>{sale.buyerName || 'Customer'}</p>
        </div>
        <div style={{ textAlign: 'right' }}>
          <span style={{ fontSize: 9, fontWeight: 900, color: '#a1a1aa', textTransform: 'uppercase', letterSpacing: '0.2em', display: 'block', marginBottom: 4 }}>Sold By</span>
          <p style={{ fontWeight: 700, fontSize: 13, margin: 0 }}>{businessName || 'Your Business'}</p>
        </div>
      </div>

      {/* Items table */}
      <div style={{ padding: '32px 48px', background: '#fff' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ borderBottom: '2px solid #18181b' }}>
              {['Description', 'Qty', 'Unit Price', 'Total'].map((h, i) => (
                <th key={h} style={{ paddingBottom: 10, fontSize: 10, fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.15em', color: '#18181b', textAlign: i === 0 ? 'left' : 'right' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {lines.map((line, idx) => (
              <tr key={idx} style={{ borderBottom: '1px solid #f4f4f5' }}>
                <td style={{ padding: '14px 0', fontSize: 13, fontWeight: 600 }}>{line.itemName}</td>
                <td style={{ padding: '14px 0', fontSize: 13, color: '#71717a', textAlign: 'right' }}>{line.quantity}</td>
                <td style={{ padding: '14px 0', fontSize: 13, color: '#71717a', textAlign: 'right' }}>{fmt(line.salePrice)}</td>
                <td style={{ padding: '14px 0', fontSize: 13, fontWeight: 700, textAlign: 'right' }}>{fmt(line.totalAmount || ((line.salePrice || 0) * (line.quantity || 0)))}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Totals + signature */}
      <div style={{ padding: '24px 48px 40px', background: '#fafafa', borderTop: '1px solid #e4e4e7' }}>
        <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
          <div style={{ width: 260 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
              <span style={{ color: '#71717a', fontSize: 13, fontWeight: 600 }}>Subtotal</span>
              <span style={{ fontWeight: 600, fontSize: 13 }}>{fmt(grandTotal)}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', paddingBottom: 12, borderBottom: '1px solid #e4e4e7', marginBottom: 12 }}>
              <span style={{ color: '#71717a', fontSize: 13, fontWeight: 600 }}>VAT (0%)</span>
              <span style={{ fontWeight: 600, fontSize: 13 }}>₦0.00</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 11, fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.15em' }}>Amount Due</span>
              <span style={{ fontSize: 32, fontWeight: 900, letterSpacing: '-0.04em' }}>{fmt(grandTotal)}</span>
            </div>
          </div>
        </div>
        <div style={{ marginTop: 40, paddingTop: 24, borderTop: '1px solid #e4e4e7', display: 'flex', justifyContent: 'flex-end' }}>
          <div style={{ textAlign: 'right', minWidth: 180 }}>
            <div style={{ borderBottom: '2px solid #18181b', width: 192, marginLeft: 'auto', marginBottom: 8, minHeight: 40 }} />
            <p style={{ fontSize: 12, fontWeight: 700, margin: 0 }}>{businessName || 'Authorized Signatory'}</p>
            <p style={{ fontSize: 9, fontWeight: 900, color: '#a1a1aa', textTransform: 'uppercase', letterSpacing: '0.18em', margin: '4px 0 0' }}>Authorized Signature</p>
          </div>
        </div>
        <div style={{ marginTop: 24, paddingTop: 16, borderTop: '1px solid #e4e4e7' }} />
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// MAIN COMPONENT
// ─────────────────────────────────────────────────────────────────
export default function SalesDayBook({
  sales, setSales, inventoryItems, setInventoryItems, businessName,
}) {
  const [cart,        setCart]        = useState([emptyLine()]);
  const [buyerName,   setBuyerName]   = useState('');
  const [isLogging,   setIsLogging]   = useState(false);
  const [formError,   setFormError]   = useState('');
  const [formSuccess, setFormSuccess] = useState('');
  const [filterFrom,  setFilterFrom]  = useState('');
  const [filterTo,    setFilterTo]    = useState('');
  const [receiptSale, setReceiptSale] = useState(null);

  // ── Stats ─────────────────────────────────────────────────────
  const todaysSales  = sales.filter(s => isToday(s.saleDate || s.saleDateISO));
  const todayRevenue = todaysSales.reduce((s, x) => s + (x.totalAmount || 0), 0);
  const todayUnits   = todaysSales.reduce((s, x) => s + (x.quantity    || 0), 0);
  const totalRevenue = sales.reduce((s, x) => s + (x.totalAmount || 0), 0);

  // ── Filtered history ──────────────────────────────────────────
  const filteredSales = useMemo(() => sales.filter(sale => {
    const date = (sale.saleDate || sale.saleDateISO || '').slice(0, 10);
    if (filterFrom && date < filterFrom) return false;
    if (filterTo   && date > filterTo)   return false;
    return true;
  }), [sales, filterFrom, filterTo]);

  const availableItems = inventoryItems.filter(i => i.quantity > 0);

  // ── Grand total ───────────────────────────────────────────────
  const grandTotal = cart.reduce((sum, line) => {
    const p = parseFloat(line.salePrice), q = parseInt(line.quantity, 10);
    return sum + (isNaN(p) || isNaN(q) ? 0 : p * q);
  }, 0);

  // ── Cart helpers ──────────────────────────────────────────────
  function addLine() { setCart(p => [...p, emptyLine()]); }
  function removeLine(key) { setCart(p => p.length === 1 ? [emptyLine()] : p.filter(l => l._key !== key)); }
  function updateLine(key, field, val) { setFormError(''); setCart(p => p.map(l => l._key === key ? { ...l, [field]: val } : l)); }

  function selectProduct(key, itemId) {
    if (!itemId) {
      setCart(p => p.map(l => l._key === key ? { ...l, inventoryItemId: '', itemName: '', unitPrice: 0, salePrice: '' } : l));
      return;
    }
    const item = inventoryItems.find(i => i.id === itemId);
    if (!item) return;
    setCart(p => p.map(l => l._key === key ? { ...l, inventoryItemId: item.id, itemName: item.name, unitPrice: item.unit_price, salePrice: String(item.unit_price) } : l));
    setFormError('');
  }

  // ── Log sale ──────────────────────────────────────────────────
  async function handleLogSale(e) {
    e.preventDefault();

    for (let i = 0; i < cart.length; i++) {
      const line  = cart[i];
      const label = cart.length > 1 ? `Row ${i + 1}: ` : '';
      if (!line.inventoryItemId)                                          { setFormError(label + 'Please select a product.');         return; }
      if (!line.quantity || isNaN(+line.quantity) || +line.quantity <= 0) { setFormError(label + 'Enter a valid quantity.');           return; }
      if (line.salePrice === '' || isNaN(+line.salePrice))                { setFormError(label + 'Enter a valid sale price.');         return; }
      const inv = inventoryItems.find(i => i.id === line.inventoryItemId);
      if (inv && inv.quantity < +line.quantity) {
        setFormError(`${label}Only ${inv.quantity} unit${inv.quantity === 1 ? '' : 's'} of "${line.itemName}" in stock.`);
        return;
      }
    }

    setFormError(''); setFormSuccess(''); setIsLogging(true);

    try {
      const res = await fetch('/api/sales', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          buyerName:    buyerName.trim(),
          businessName: businessName || '',
          items: cart.map(line => ({
            inventoryItemId: line.inventoryItemId,
            itemName:        line.itemName,
            unitPrice:       parseFloat(line.unitPrice),
            salePrice:       parseFloat(line.salePrice),
            quantity:        parseInt(line.quantity, 10),
          })),
        }),
      });

      let data;
      try { data = await res.json(); }
      catch { setFormError("We couldn't complete this sale right now. Please try again."); return; }

      if (!res.ok || !data.success) { setFormError(data.message || "Something went wrong. The sale wasn't recorded."); return; }

      setSales(prev => [data.sale, ...prev]);

      if (data.stockUpdates) {
        setInventoryItems(prev => prev.map(item => {
          const u = data.stockUpdates.find(x => x.id === item.id);
          return u ? { ...item, quantity: u.newQuantity } : item;
        }));
      }

      setFormSuccess(`Sale logged! ₦${grandTotal.toLocaleString()} recorded across ${cart.length} product${cart.length === 1 ? '' : 's'}.`);
      setCart([emptyLine()]); setBuyerName('');

    } catch { setFormError("We couldn't reach the server. Please check your connection and try again."); }
    finally  { setIsLogging(false); }
  }

  // ── Receipt download ──────────────────────────────────────────
  function downloadReceipt(sale) {
    setReceiptSale(sale);
    setTimeout(() => {
      window.print();
      setTimeout(() => setReceiptSale(null), 1000);
    }, 150);
  }

  return (
    <>
      {/* Print styles */}
      <style>{`
        @page { margin: 0; size: A4; }
        @media print {
          body * { visibility: hidden !important; }
          #sale-receipt-canvas, #sale-receipt-canvas * { visibility: visible !important; }
          #sale-receipt-canvas {
            position: fixed !important; top: 0; left: 0;
            width: 100% !important; height: auto !important;
            box-shadow: none !important; border-radius: 0 !important; border: none !important;
          }
          html { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        }
      `}</style>

      {/* Hidden receipt canvas — rendered off-screen when downloading */}
      {receiptSale && (
        <div style={{ position: 'fixed', top: -9999, left: -9999, zIndex: -1 }}>
          <SaleReceipt sale={receiptSale} businessName={businessName} />
        </div>
      )}

      <div className="space-y-8 pb-20">

        {/* ── Header + Stats ────────────────────────────────────── */}
        <div className="border-b border-zinc-900 -mx-5 px-5 pb-8">
          <div className="flex items-start justify-between flex-wrap gap-4 mb-6">
            <div>
              <h1 className="text-3xl md:text-4xl font-black tracking-tighter italic uppercase mb-2">Sales Day Book</h1>
              <p className="text-zinc-500 text-sm">Log every sale, track daily revenue, and auto-update your inventory.</p>
            </div>
            <span className="text-[9px] font-black uppercase tracking-widest text-amber-500 bg-amber-500/10 px-4 py-2 rounded-full border border-amber-500/20 self-start">Live Ledger</span>
          </div>

          <div className="flex flex-wrap gap-4">
            <div className="bg-amber-500 rounded-2xl px-5 py-4 flex items-center gap-3">
              <TrendingUp size={16} className="text-black" />
              <div>
                <p className="text-[9px] font-black uppercase tracking-widest text-black/60">Today's Revenue</p>
                <p className="text-xl font-black text-black">₦{todayRevenue.toLocaleString()}</p>
              </div>
            </div>
            <div className="bg-zinc-950 border border-zinc-800 rounded-2xl px-5 py-4 flex items-center gap-3">
              <ShoppingBag size={16} className="text-zinc-500" />
              <div>
                <p className="text-[9px] font-black uppercase tracking-widest text-zinc-600">Today's Sales</p>
                <p className="text-xl font-black text-white">{todaysSales.length}</p>
              </div>
            </div>
            <div className="bg-zinc-950 border border-zinc-800 rounded-2xl px-5 py-4 flex items-center gap-3">
              <Package size={16} className="text-zinc-500" />
              <div>
                <p className="text-[9px] font-black uppercase tracking-widest text-zinc-600">Units Sold Today</p>
                <p className="text-xl font-black text-white">{todayUnits}</p>
              </div>
            </div>
            <div className="bg-zinc-950 border border-zinc-800 rounded-2xl px-5 py-4 flex items-center gap-3">
              <Receipt size={16} className="text-zinc-500" />
              <div>
                <p className="text-[9px] font-black uppercase tracking-widest text-zinc-600">All-Time Revenue</p>
                <p className="text-xl font-black text-white">₦{totalRevenue.toLocaleString()}</p>
              </div>
            </div>
          </div>
        </div>

        {/* ── Log Sale Form ─────────────────────────────────────── */}
        <div className="bg-zinc-950 border border-zinc-900 rounded-[2rem] overflow-hidden">
          <div className="border-b border-zinc-900 px-8 py-5 flex items-center justify-between">
            <div>
              <h2 className="text-lg font-black italic uppercase">Log a Sale</h2>
              <p className="text-zinc-600 text-xs mt-0.5">
                {availableItems.length === 0
                  ? 'No items in stock — add stock in the Inventory tab first.'
                  : `${availableItems.length} product${availableItems.length === 1 ? '' : 's'} available`}
              </p>
            </div>
            <div className="w-10 h-10 bg-amber-500/10 rounded-xl flex items-center justify-center text-amber-500 border border-amber-500/20">
              <ShoppingBag size={18} />
            </div>
          </div>

          <form onSubmit={handleLogSale} className="p-8 space-y-6">

            {/* Seller + Buyer */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">Seller (Your Business)</label>
                <div className="flex items-center gap-3 px-4 py-3 bg-zinc-900 border border-zinc-800 rounded-xl">
                  <User size={14} className="text-zinc-600 shrink-0" />
                  <span className="text-sm text-zinc-300 font-black truncate">{businessName || 'Your Business'}</span>
                  <span className="text-[9px] text-zinc-600 ml-auto uppercase tracking-widest shrink-0">Auto</span>
                </div>
              </div>
              <div>
                <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">
                  Buyer Name <span className="text-zinc-700 normal-case font-normal">— optional</span>
                </label>
                <input type="text" placeholder="e.g. Aisha Mohammed"
                  value={buyerName} onChange={e => setBuyerName(e.target.value)}
                  className={inputClass} />
              </div>
            </div>

            {/* Cart lines */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500">Items in this Sale</label>
                <button type="button" onClick={addLine}
                  className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest text-amber-500 hover:text-amber-400 transition px-3 py-1.5 bg-amber-500/10 rounded-lg border border-amber-500/20">
                  <Plus size={11} /> Add Item
                </button>
              </div>

              {cart.map((line, idx) => (
                <div key={line._key} className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-4 space-y-3">
                  {cart.length > 1 && (
                    <div className="flex items-center justify-between">
                      <span className="text-[9px] font-black uppercase tracking-widest text-zinc-600">Item {idx + 1}</span>
                      <button type="button" onClick={() => removeLine(line._key)} className="text-zinc-700 hover:text-red-400 transition">
                        <X size={13} />
                      </button>
                    </div>
                  )}

                  <div className="relative">
                    <select value={line.inventoryItemId}
                      onChange={e => selectProduct(line._key, e.target.value)}
                      className={inputClass + ' appearance-none cursor-pointer pr-10'}
                      disabled={availableItems.length === 0}>
                      <option value="">Select product to sell...</option>
                      {availableItems.map(item => (
                        <option key={item.id} value={item.id}>
                          {item.name} — {item.quantity} in stock · ₦{Number(item.unit_price).toLocaleString()}
                        </option>
                      ))}
                    </select>
                    <ChevronDown size={14} className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-600 pointer-events-none" />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[9px] font-black uppercase tracking-widest text-zinc-600 mb-1.5">Qty</label>
                      <input type="number" min="1" placeholder="e.g. 3"
                        value={line.quantity}
                        onChange={e => updateLine(line._key, 'quantity', e.target.value)}
                        className={inputClass} disabled={!line.inventoryItemId} />
                    </div>
                    <div>
                      <label className="block text-[9px] font-black uppercase tracking-widest text-zinc-600 mb-1.5">
                        Sale Price (₦) <span className="text-zinc-700 font-normal normal-case">editable</span>
                      </label>
                      <input type="number" min="0" placeholder="e.g. 25000"
                        value={line.salePrice}
                        onChange={e => updateLine(line._key, 'salePrice', e.target.value)}
                        className={inputClass} disabled={!line.inventoryItemId} />
                    </div>
                  </div>

                  {line.inventoryItemId && line.salePrice !== '' && line.quantity !== '' && (
                    <div className="flex items-center justify-between px-3 py-2 bg-zinc-900 rounded-xl">
                      <span className="text-[10px] font-black uppercase tracking-widest text-zinc-600">
                        Line total
                        {parseFloat(line.salePrice) < line.unitPrice && <span className="text-red-400 ml-2">· Below listed</span>}
                        {parseFloat(line.salePrice) > line.unitPrice && <span className="text-green-400 ml-2">· Above listed</span>}
                      </span>
                      <span className="text-sm font-black text-amber-500">
                        ₦{((parseFloat(line.salePrice) || 0) * (parseInt(line.quantity, 10) || 0)).toLocaleString()}
                      </span>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Grand total */}
            {grandTotal > 0 && (
              <div className="flex items-center justify-between px-5 py-4 bg-amber-500/5 border border-amber-500/20 rounded-xl">
                <span className="text-[10px] font-black uppercase tracking-widest text-amber-500/70">
                  Grand Total ({cart.length} item{cart.length === 1 ? '' : 's'})
                </span>
                <span className="text-2xl font-black text-amber-500">₦{grandTotal.toLocaleString()}</span>
              </div>
            )}

            {formError && (
              <div className="flex items-center gap-2 px-4 py-3 bg-red-500/10 border border-red-500/20 rounded-xl">
                <AlertCircle size={13} className="text-red-400 shrink-0" />
                <p className="text-red-400 text-xs">{formError}</p>
              </div>
            )}

            {formSuccess && (
              <div className="flex items-center gap-2 px-4 py-3 bg-green-500/10 border border-green-500/20 rounded-xl">
                <CheckCircle size={13} className="text-green-400 shrink-0" />
                <p className="text-green-400 text-xs">{formSuccess}</p>
              </div>
            )}

            <button type="submit" disabled={isLogging || availableItems.length === 0}
              className="w-full flex items-center justify-center gap-2 py-4 bg-amber-500 text-black font-black text-xs uppercase tracking-widest rounded-xl hover:bg-amber-400 transition-all disabled:opacity-40">
              {isLogging
                ? <><Loader2 size={15} className="animate-spin" /> Recording Sale...</>
                : <><ArrowRight size={15} /> Log Sale & Deduct Stock</>}
            </button>
          </form>
        </div>

        {/* ── Sales History ─────────────────────────────────────── */}
        <div className="bg-zinc-950 border border-zinc-900 rounded-[2rem] overflow-hidden">
          <div className="border-b border-zinc-900 px-8 py-5 flex items-center justify-between flex-wrap gap-4">
            <div>
              <h2 className="text-lg font-black italic uppercase">Sales History</h2>
              <p className="text-zinc-600 text-xs mt-0.5">
                {filteredSales.length} record{filteredSales.length === 1 ? '' : 's'}
                {(filterFrom || filterTo) ? ' in selected range' : ' total'}
              </p>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <Calendar size={13} className="text-zinc-600" />
              <input type="date" value={filterFrom} onChange={e => setFilterFrom(e.target.value)}
                className="bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-zinc-300 focus:outline-none focus:border-amber-500 transition" />
              <span className="text-zinc-700 text-xs font-black">→</span>
              <input type="date" value={filterTo} onChange={e => setFilterTo(e.target.value)}
                className="bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-zinc-300 focus:outline-none focus:border-amber-500 transition" />
              {(filterFrom || filterTo) && (
                <button onClick={() => { setFilterFrom(''); setFilterTo(''); }}
                  className="text-[10px] font-black uppercase tracking-widest text-zinc-600 hover:text-amber-500 transition px-3 py-2 bg-zinc-900 rounded-xl border border-zinc-800">
                  Clear
                </button>
              )}
            </div>
          </div>

          {filteredSales.length === 0 && (
            <div className="flex flex-col items-center justify-center py-20 text-center px-8">
              <div className="w-16 h-16 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center mb-5">
                <Receipt size={24} className="text-zinc-700" />
              </div>
              <h3 className="text-base font-black uppercase tracking-tighter mb-2">No Sales Yet</h3>
              <p className="text-zinc-600 text-sm max-w-xs leading-relaxed">
                {(filterFrom || filterTo)
                  ? 'No sales found in the selected date range. Try adjusting the filter.'
                  : 'Log your first sale above to start building your ledger.'}
              </p>
            </div>
          )}

          {filteredSales.length > 0 && (
            <div>
              {/* Table header */}
              <div className="hidden sm:grid grid-cols-[1.5fr_1fr_1fr_0.8fr_1fr_auto] gap-4 px-8 py-3 bg-zinc-900/60 border-b border-zinc-900">
                {['Product(s)', 'Buyer', 'Date', 'Lines', 'Total', ''].map(h => (
                  <p key={h} className="text-[9px] font-black uppercase tracking-widest text-zinc-600">{h}</p>
                ))}
              </div>

              <div className="divide-y divide-zinc-900/60">
                {filteredSales.map(sale => {
                  const saleLines = sale.items && sale.items.length > 0
                    ? sale.items
                    : [{ itemName: sale.itemName, quantity: sale.quantity }];
                  const itemLabel = saleLines.length === 1 ? saleLines[0].itemName : `${saleLines.length} products`;
                  const totalQty  = saleLines.reduce((s, l) => s + (l.quantity || 0), 0);

                  return (
                    <div key={sale.id}
                      className="grid grid-cols-1 sm:grid-cols-[1.5fr_1fr_1fr_0.8fr_1fr_auto] gap-2 sm:gap-4 px-8 py-4 hover:bg-zinc-900/20 transition items-center">

                      <div>
                        <p className="text-sm font-black text-white">{itemLabel}</p>
                        {saleLines.length > 1 && (
                          <p className="text-[10px] text-zinc-600 mt-0.5 leading-relaxed">
                            {saleLines.map(l => l.itemName).join(', ')}
                          </p>
                        )}
                        <p className="text-[10px] text-zinc-600 sm:hidden">{formatDate(sale.saleDate || sale.saleDateISO)}</p>
                      </div>

                      <p className="text-xs text-zinc-400">{sale.buyerName || '—'}</p>

                      <p className="hidden sm:block text-xs text-zinc-500 font-mono">
                        {formatDate(sale.saleDate || sale.saleDateISO)}
                      </p>

                      <p className="text-xs text-zinc-500">
                        {saleLines.length} line{saleLines.length > 1 ? 's' : ''} · {totalQty} unit{totalQty > 1 ? 's' : ''}
                      </p>

                      <p className="text-sm font-black text-amber-500">
                        ₦{Number(sale.totalAmount).toLocaleString()}
                      </p>

                      {/* Download receipt button */}
                      <button onClick={() => downloadReceipt(sale)}
                        title="Download receipt"
                        className="flex items-center gap-1.5 px-3 py-2 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-zinc-700 rounded-xl text-[10px] font-black uppercase tracking-widest text-zinc-500 hover:text-white transition print:hidden">
                        <Download size={11} />
                        <span className="hidden sm:inline">Receipt</span>
                      </button>
                    </div>
                  );
                })}
              </div>

              {(filterFrom || filterTo) && filteredSales.length > 0 && (
                <div className="px-8 py-4 border-t border-zinc-900 bg-zinc-900/40 flex flex-wrap gap-6">
                  <div>
                    <p className="text-[9px] font-black uppercase tracking-widest text-zinc-600 mb-1">Range Revenue</p>
                    <p className="text-lg font-black text-amber-500">
                      ₦{filteredSales.reduce((s, x) => s + x.totalAmount, 0).toLocaleString()}
                    </p>
                  </div>
                  <div>
                    <p className="text-[9px] font-black uppercase tracking-widest text-zinc-600 mb-1">Range Units</p>
                    <p className="text-lg font-black text-white">
                      {filteredSales.reduce((s, x) => s + (x.quantity || 0), 0)}
                    </p>
                  </div>
                  <div>
                    <p className="text-[9px] font-black uppercase tracking-widest text-zinc-600 mb-1">Transactions</p>
                    <p className="text-lg font-black text-white">{filteredSales.length}</p>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </>
  );
}
