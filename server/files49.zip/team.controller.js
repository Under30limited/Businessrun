/**
 * controllers/team.controller.js
 *
 * Lets a business owner invite team members and grant them access to
 * a subset of dashboard features. A team member is a br-users item
 * with role:'member' — they log in through the exact same
 * POST /api/auth/login as an owner; the only difference is what their
 * JWT carries (see utils/jwt.js and middleware/permissions.js).
 *
 * Routes (wired in routes/team.routes.js):
 *   POST   /api/team/invite          (owner only)  — invite by email + permissions
 *   GET    /api/team                 (owner only)  — list all members
 *   PATCH  /api/team/:memberId       (owner only)  — update permissions or status
 *   DELETE /api/team/:memberId       (owner only)  — permanently remove a member
 *   POST   /api/team/accept-invite   (public)      — set password, activate
 *
 * FEATURE KEYS — must match RoadmapPage's tab keys exactly:
 *   inventory | sales | daylog | reports | cfo | advisor
 */

'use strict';

const asyncHandler    = require('../utils/asyncHandler');
const ApiError         = require('../utils/ApiError');
const { sanitise, requireFields, isValidEmail } = require('../utils/sanitise');
const db               = require('../services/db.service');
const { sendInviteEmail } = require('../services/email.service');
const { v4: uuidv4 }   = require('uuid');
const crypto            = require('crypto');
const bcrypt             = require('bcryptjs');
const { signToken, COOKIE_NAME, COOKIE_OPTIONS } = require('../utils/jwt');

const FEATURE_KEYS = ['inventory', 'sales', 'daylog', 'reports', 'cfo', 'advisor'];
const FEATURE_LABELS = {
  inventory: 'Inventory',
  sales:     'Sales Day Book',
  daylog:    'Day Log',
  reports:   'Reports',
  cfo:       'Digital CFO',
  advisor:   'AI Advisor',
};

const INVITE_EXPIRY_MS = 7 * 24 * 60 * 60 * 1000; // 7 days
const APP_URL = process.env.APP_URL || 'https://thebusinessrun.com';

// ── Guard: only owners manage a team ───────────────────────────────
function requireOwner(req) {
  if (req.user.role === 'member') {
    throw ApiError.forbidden('Only the business owner can manage team access.');
  }
}

function validatePermissions(permissions) {
  if (!Array.isArray(permissions)) {
    throw ApiError.badRequest('permissions must be an array of feature keys.');
  }
  const invalid = permissions.filter(p => !FEATURE_KEYS.includes(p));
  if (invalid.length > 0) {
    throw ApiError.badRequest(
      `Invalid permission${invalid.length > 1 ? 's' : ''}: ${invalid.join(', ')}. ` +
      `Valid keys: ${FEATURE_KEYS.join(', ')}.`
    );
  }
}

function publicMember(m) {
  return {
    uid:         m.uid,
    email:       m.email,
    permissions: m.permissions || [],
    status:      m.status,
    invitedAt:   m.invitedAt,
    acceptedAt:  m.acceptedAt || null,
  };
}

// ── POST /api/team/invite ───────────────────────────────────────────
const inviteMember = asyncHandler(async (req, res) => {
  requireOwner(req);

  const body = sanitise(req.body, ['email', 'permissions']);
  requireFields(body, ['email']);

  const email = body.email.toLowerCase().trim();
  if (!isValidEmail(email)) throw ApiError.badRequest('Invalid email address.');

  const permissions = body.permissions || [];
  validatePermissions(permissions);
  if (permissions.length === 0) {
    throw ApiError.badRequest('Grant at least one feature when inviting a team member.');
  }

  // Block inviting an email that's already a completed account
  // (owner or member, anywhere) — same "already exists" rule GYB uses.
  const existing = await db.getUserByEmail(email);
  if (existing && existing.completed === true) {
    throw ApiError.badRequest('An account with this email already exists.');
  }

  const uid             = uuidv4();
  const inviteToken      = crypto.randomBytes(32).toString('hex');
  const inviteExpiresAt = Date.now() + INVITE_EXPIRY_MS;

  await db.createTeamMember(uid, {
    email,
    ownerUid: req.user.uid,
    permissions,
    inviteToken,
    inviteExpiresAt,
  });

  const inviteUrl = `${APP_URL}/accept-invite?uid=${uid}&token=${inviteToken}`;

  try {
    await sendInviteEmail({
      to:                email,
      ownerBusinessName: req.user.businessName || 'BusinessRun',
      inviteUrl,
      featureLabels:     permissions.map(p => FEATURE_LABELS[p]),
    });
  } catch (err) {
    // The invite record exists either way — owner can resend by
    // deleting and re-inviting if the email genuinely never arrives.
    console.error('[Team] Invite email failed to send:', err.message);
  }

  res.status(201).json({ success: true, message: `Invite sent to ${email}.` });
});

// ── GET /api/team ────────────────────────────────────────────────────
const listMembers = asyncHandler(async (req, res) => {
  requireOwner(req);
  const members = await db.getTeamMembers(req.user.uid);
  res.json({ success: true, members: members.map(publicMember) });
});

// ── PATCH /api/team/:memberId ────────────────────────────────────────
const updateMember = asyncHandler(async (req, res) => {
  requireOwner(req);

  const { memberId } = req.params;
  const member = await db.getUserByUid(memberId);
  if (!member || member.role !== 'member' || member.ownerUid !== req.user.uid) {
    throw ApiError.notFound('Team member not found.');
  }

  const body    = sanitise(req.body, ['permissions', 'status']);
  const updates = {};

  if (body.permissions !== undefined) {
    validatePermissions(body.permissions);
    updates.permissions = body.permissions;
  }

  if (body.status !== undefined) {
    if (!['active', 'revoked'].includes(body.status)) {
      throw ApiError.badRequest('status must be "active" or "revoked".');
    }
    // Can't reactivate someone who never accepted their invite —
    // that's still 'pending', not something PATCH should flip.
    if (body.status === 'active' && member.status === 'pending') {
      throw ApiError.badRequest('This member has not accepted their invite yet.');
    }
    updates.status = body.status;
  }

  if (Object.keys(updates).length === 0) {
    throw ApiError.badRequest('Nothing to update — provide permissions and/or status.');
  }

  await db.updateTeamMember(memberId, updates);
  res.json({ success: true, message: 'Team member updated.' });
});

// ── DELETE /api/team/:memberId ───────────────────────────────────────
const removeMember = asyncHandler(async (req, res) => {
  requireOwner(req);

  const { memberId } = req.params;
  const member = await db.getUserByUid(memberId);
  if (!member || member.role !== 'member' || member.ownerUid !== req.user.uid) {
    throw ApiError.notFound('Team member not found.');
  }

  await db.deleteTeamMember(memberId);
  res.json({ success: true, message: 'Team member removed.' });
});

// ── POST /api/team/accept-invite ─────────────────────────────────────
// Public — no auth cookie exists yet, this IS how one gets created.
const acceptInvite = asyncHandler(async (req, res) => {
  const body = sanitise(req.body, ['uid', 'token', 'password']);
  requireFields(body, ['uid', 'token', 'password']);

  if (typeof body.password !== 'string' || body.password.length < 6) {
    throw ApiError.badRequest('Password must be at least 6 characters.');
  }

  const member = await db.getUserByUid(body.uid);
  if (!member || member.role !== 'member') {
    throw ApiError.badRequest('Invalid or expired invite link.');
  }
  if (member.status === 'revoked') {
    throw ApiError.forbidden('This invite has been revoked.');
  }
  if (member.status === 'active') {
    throw ApiError.badRequest('This invite has already been accepted. Please log in instead.');
  }
  if (member.inviteToken !== body.token) {
    throw ApiError.badRequest('Invalid or expired invite link.');
  }
  if (Date.now() > member.inviteExpiresAt) {
    throw ApiError.badRequest('This invite link has expired. Ask the business owner to resend it.');
  }

  const hashedPassword = await bcrypt.hash(body.password, 12);
  await db.acceptTeamInvite(body.uid, hashedPassword);

  // Fetch the owner's business name for a friendlier profile — not
  // required, but nice for the dashboard header ("Managing: Ada Foods").
  const owner = await db.getUserByUid(member.ownerUid);

  const token = signToken({
    uid:          member.uid,           // actorUid default
    tenantUid:    member.ownerUid,      // → becomes payload.uid for data scoping
    role:         'member',
    permissions:  member.permissions || [],
    email:        member.email,
    businessName: owner?.businessName || '',
  });
  res.cookie(COOKIE_NAME, token, COOKIE_OPTIONS);

  res.status(200).json({
    success: true,
    profile: {
      uid:          member.uid,
      email:        member.email,
      role:         'member',
      permissions:  member.permissions || [],
      businessName: owner?.businessName || '',
    },
  });
});

module.exports = { inviteMember, listMembers, updateMember, removeMember, acceptInvite, FEATURE_KEYS };
