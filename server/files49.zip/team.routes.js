/**
 * routes/team.routes.js
 *
 *   POST   /api/team/invite          (owner)  — invite a team member
 *   GET    /api/team                 (owner)  — list team members
 *   PATCH  /api/team/:memberId       (owner)  — update permissions/status
 *   DELETE /api/team/:memberId       (owner)  — remove a member
 *   POST   /api/team/accept-invite   (public) — set password, activate
 *
 * accept-invite has no session yet — it must be registered BEFORE
 * router.use(protect), same reasoning as auth.routes.js's login route.
 */

'use strict';

const express       = require('express');
const router        = express.Router();
const controller    = require('../controllers/team.controller');
const { protect }   = require('../middleware/auth');
const { authLimiter, dataLimiter, dashboardLimiter } = require('../middleware/rateLimiter');

// ── Public — no session required ────────────────────────────────────
router.post('/accept-invite', authLimiter, controller.acceptInvite);

// ── Owner-only management — session required ───────────────────────
router.use(protect);

router.post('/invite',        dataLimiter,      controller.inviteMember);
router.get('/',                dashboardLimiter, controller.listMembers);
router.patch('/:memberId',     dashboardLimiter, controller.updateMember);
router.delete('/:memberId',    dashboardLimiter, controller.removeMember);

module.exports = router;
