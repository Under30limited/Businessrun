/**
 * middleware/permissions.js
 *
 * Gates a dashboard route to a specific feature key. Owners always
 * pass (they have unrestricted access to their own business data).
 * Team members must have the feature in their permissions list AND
 * still be active.
 *
 * ── WHY A LIVE DB CHECK, NOT JUST THE JWT ──────────────────────────
 * Permissions are embedded in the JWT at login for convenience, but
 * the cookie lives for 7 days (see utils/jwt.js COOKIE_OPTIONS). If
 * an owner revokes a member's access, that must take effect on their
 * very next request — not up to 7 days later when the token expires.
 * So this middleware re-reads the member's row from br-users on every
 * request. It's a single DynamoDB GetItem by primary key (uid) — cheap
 * — and it's only paid by team members, never by owners, since owners
 * skip straight through without a DB call.
 * ─────────────────────────────────────────────────────────────────
 *
 * USAGE (in a route file, right after router.use(protect)):
 *
 *   const { requireFeature } = require('../middleware/permissions');
 *   router.use(requireFeature('sales'));
 */

'use strict';

const ApiError      = require('../utils/ApiError');
const asyncHandler   = require('../utils/asyncHandler');
const db             = require('../services/db.service');

/**
 * @param {string} featureKey  One of: 'inventory' | 'sales' | 'daylog' |
 *                              'reports' | 'cfo' | 'advisor'
 */
function requireFeature(featureKey) {
  return asyncHandler(async (req, res, next) => {
    // Owners always have full access to their own business data —
    // no DB round-trip needed, this is the common case.
    if (req.user.role !== 'member') {
      return next();
    }

    // Member — re-check live, using their own identity (actorUid),
    // not req.user.uid (which is the OWNER's uid / tenant scope).
    const member = await db.getUserByUid(req.user.actorUid);

    if (!member || member.role !== 'member') {
      throw ApiError.forbidden('Your access could not be verified. Please log in again.');
    }

    if (member.status === 'revoked') {
      throw ApiError.forbidden('Your access to this business has been revoked.');
    }

    if (member.status !== 'active') {
      throw ApiError.forbidden('Your invite has not been accepted yet.');
    }

    const permissions = member.permissions || [];
    if (!permissions.includes(featureKey)) {
      throw ApiError.forbidden(`You don't have access to ${featureKey}. Ask the business owner to grant it.`);
    }

    next();
  });
}

module.exports = { requireFeature };
