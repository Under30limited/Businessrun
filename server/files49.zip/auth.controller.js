/**
 * controllers/auth.controller.js
 *
 * Three auth endpoints:
 *
 *   POST /api/auth/login   — verify credentials, issue JWT cookie, return profile
 *   POST /api/auth/logout  — clear the JWT cookie
 *   GET  /api/auth/me      — validate current cookie, return fresh profile
 *
 * COOKIE STRATEGY:
 *   On successful login or signup, the server sets an HTTP-only cookie
 *   named 'br_token' containing a signed JWT. The browser stores and sends
 *   this cookie automatically — JavaScript on the frontend cannot read it.
 *
 *   This means:
 *   - No token stored in localStorage or sessionStorage (no XSS risk)
 *   - No Authorization header to manage on the frontend
 *   - Session persists across tab closes and browser restarts for 7 days
 *   - /api/auth/me lets the frontend check "am I still logged in?" on load
 *
 *   On logout, the server clears the cookie by setting it with maxAge=0.
 *   The client cannot clear an HTTP-only cookie itself — only the server can.
 */

'use strict';

const asyncHandler    = require('../utils/asyncHandler');
const ApiError        = require('../utils/ApiError');
const { sanitise, requireFields, isValidEmail } = require('../utils/sanitise');
const firebaseService = require('../services/db.service');
const bcrypt          = require('bcryptjs');
const { signToken, COOKIE_NAME, COOKIE_OPTIONS, CLEAR_COOKIE_OPTIONS } = require('../utils/jwt');

// ── Normalise profile for consistent response shape ───────────────
// Only safe, non-sensitive fields are returned.
// hashedPassword is never included.
function normaliseProfile(doc) {
  const isMember = doc.role === 'member';
  return {
    uid:            doc.uid          || doc.id  || '',
    fullName:       doc.fullName                || '',
    businessName:   doc.businessName            || '',
    email:          doc.email                   || '',
    stage:          doc.stage                   || '',
    salesChannel:   doc.salesChannel            || '',
    revenue:        doc.revenue                 || '',
    headache:       doc.headache                || '',
    matchmaking:    doc.matchmaking              || '',
    onboardingStep: doc.onboardingStep          || 0,
    completed:      doc.completed               || false,
    // ── Team feature ──────────────────────────────────────────
    role:           doc.role || 'owner',
    permissions:    isMember ? (doc.permissions || []) : null, // null = unrestricted (owner)
    tenantUid:      isMember ? doc.ownerUid : (doc.uid || doc.id || ''),
  };
}

// ── POST /api/auth/login ──────────────────────────────────────────
/**
 * 1. Find user in the database by email
 * 2. Compare submitted password against stored bcrypt hash
 * 3. Sign a JWT containing the profile
 * 4. Set the JWT in an HTTP-only cookie
 * 5. Return the profile in the response body (so the frontend can
 *    populate the AuthContext immediately without waiting for /me)
 */
const login = asyncHandler(async (req, res) => {
  const body = sanitise(req.body, ['email', 'password']);
  requireFields(body, ['email', 'password']);

  if (!isValidEmail(body.email)) {
    throw ApiError.badRequest('Invalid email address.');
  }

  // 1. Fetch user from the database
  const profileDoc = await firebaseService.getUserByEmail(body.email);
  if (!profileDoc) {
    // Use the same message for "not found" and "wrong password" —
    // never reveal which part is wrong (prevents email enumeration)
    throw ApiError.unauthorized('Invalid email or password.');
  }

  // 2. Verify password
  if (!profileDoc.hashedPassword) {
    console.error(`[Auth] No hashedPassword found for ${body.email}`);
    throw ApiError.unauthorized('Invalid email or password.');
  }

  const passwordMatch = await bcrypt.compare(body.password, profileDoc.hashedPassword);
  if (!passwordMatch) {
    throw ApiError.unauthorized('Invalid email or password.');
  }

  // 2b. Team-member specific checks
  if (profileDoc.role === 'member') {
    if (profileDoc.status === 'revoked') {
      throw ApiError.forbidden('Your access to this business has been revoked. Contact the business owner.');
    }
    if (profileDoc.status !== 'active') {
      throw ApiError.forbidden('Your invite has not been accepted yet.');
    }
  }

  // 3. Build the normalised profile — for a member, pull the owner's
  //    businessName so the dashboard has something to display; the
  //    member record itself doesn't carry one.
  let profile = normaliseProfile(profileDoc);
  if (profileDoc.role === 'member') {
    const owner = await firebaseService.getUserByUid(profileDoc.ownerUid);
    profile = { ...profile, businessName: owner?.businessName || '' };
  }

  // 4. Sign a JWT and set it as an HTTP-only cookie
  const token = signToken(profile);
  res.cookie(COOKIE_NAME, token, COOKIE_OPTIONS);

  // 5. Return profile in body — frontend stores it in AuthContext (React state only)
  res.json({ success: true, profile });
});

// ── POST /api/auth/logout ─────────────────────────────────────────
/**
 * Clears the session cookie.
 * The client cannot clear an HTTP-only cookie itself — only the server can.
 * This route requires no auth — clearing an already-missing cookie is harmless.
 */
const logout = asyncHandler(async (req, res) => {
  res.clearCookie(COOKIE_NAME, CLEAR_COOKIE_OPTIONS);
  res.json({ success: true, message: 'Logged out successfully.' });
});

// ── GET /api/auth/me ──────────────────────────────────────────────
/**
 * Called by the frontend on every app load (in AuthContext) to check
 * whether the user's cookie is still valid and restore their session.
 *
 * Flow:
 *   - Browser sends cookie automatically
 *   - protect middleware verifies the JWT and sets req.user
 *   - This handler returns the profile from the JWT payload
 *     (no DB call needed — the JWT is the source of truth)
 *
 * If the cookie is expired or missing, protect throws 401 and the
 * frontend clears its React state — user must log in again.
 *
 * Optional DB refresh:
 *   If you want guaranteed-fresh data (e.g. after an admin changes a
 *   user's profile), add a db.service lookup here. For now,
 *   the JWT payload is sufficient and avoids a DB call on every load.
 */
const getMe = asyncHandler(async (req, res) => {
  // req.user is populated by the protect middleware from the JWT payload
  // No DB call needed — JWT is the source of truth for the session.
  //
  // Note: req.user.uid is the TENANT/business id (used server-side to
  // scope data queries). The profile returned to the frontend uses
  // actorUid as "uid" instead — the frontend should see the real
  // logged-in identity, not the business they're operating on.
  const profile = {
    uid:          req.user.actorUid,
    tenantUid:    req.user.tenantUid,
    role:         req.user.role,
    permissions:  req.user.permissions,
    email:        req.user.email,
    fullName:     req.user.fullName,
    businessName: req.user.businessName,
    stage:        req.user.stage,
    salesChannel: req.user.salesChannel,
    revenue:      req.user.revenue,
    headache:     req.user.headache,
    matchmaking:  req.user.matchmaking,
  };

  res.json({ success: true, profile });
});

// ── POST /api/auth/check-email ───────────────────────────────────
/**
 * Email check used during GYB signup Step 1.
 *
 * Returns three possible states:
 *
 *   completed: true  — email is fully registered → block, prompt to log in
 *   completed: false — email exists but registration was never finished
 *                      → allow silently, user resumes their incomplete signup
 *   exists: false    — email not found at all → allow, fresh signup
 *
 * WHY we check completed:
 *   A user may have started GYB, dropped off at step 2 or 3, and is
 *   now trying again with the same email. We should never block them —
 *   they never actually completed registration. Blocking them would
 *   lock them out of an account they cannot log into yet.
 *
 * Body:    { email }
 * Response: { success: true, exists: boolean, completed: boolean }
 */
const checkEmail = asyncHandler(async (req, res) => {
  const body  = sanitise(req.body, ['email']);
  requireFields(body, ['email']);

  const email = body.email.trim().toLowerCase();
  if (!isValidEmail(email)) throw ApiError.badRequest('Invalid email address.');

  let exists    = false;
  let completed = false;

  try {
    // getUserByEmail already checks for a completed user first, then
    // falls back to any user (including incomplete signups) with this
    // email — exactly the "find ALL users with this email" behavior
    // this endpoint needs.
    const user = await firebaseService.getUserByEmail(email);

    if (user) {
      exists    = true;
      completed = user.completed === true;
    }
  } catch {
    // Query failed — allow progression rather than blocking signup
    exists    = false;
    completed = false;
  }

  res.json({ success: true, exists, completed });
});

module.exports = { login, logout, getMe, checkEmail };
