require('dotenv').config({ path: '/var/www/businessrun/server/.env' });

module.exports = {
  apps: [{
    name: 'businessrun-api',
    script: '/var/www/businessrun/server/index.js',
    cwd: '/var/www/businessrun/server',
    env: {
      NODE_ENV: 'development',
      PORT: process.env.PORT,

      // ── AI Provider Selection ──────────────────────────────────
      GEMINI_PROVIDER: process.env.GEMINI_PROVIDER,

      // AI Studio
      GEMINI_API_KEY: process.env.GEMINI_API_KEY,
      GEMINI_MODEL: process.env.GEMINI_MODEL,

      // Vertex AI
      VERTEX_PROJECT_ID: process.env.VERTEX_PROJECT_ID,
      VERTEX_LOCATION: process.env.VERTEX_LOCATION,
      VERTEX_MODEL: process.env.VERTEX_MODEL,
      GOOGLE_APPLICATION_CREDENTIALS: process.env.GOOGLE_APPLICATION_CREDENTIALS,

      // AWS Bedrock
      AWS_ACCESS_KEY_ID: process.env.AWS_ACCESS_KEY_ID,
      AWS_SECRET_ACCESS_KEY: process.env.AWS_SECRET_ACCESS_KEY,
      AWS_REGION: process.env.AWS_REGION,
      BEDROCK_MODEL_ID: process.env.BEDROCK_MODEL_ID,

      // ── Firebase ────────────────────────────────────────────────
      FIREBASE_PROJECT_ID: process.env.FIREBASE_PROJECT_ID,
      FIREBASE_CLIENT_EMAIL: process.env.FIREBASE_CLIENT_EMAIL,
      FIREBASE_PRIVATE_KEY: process.env.FIREBASE_PRIVATE_KEY,
      FIREBASE_STORAGE_BUCKET: process.env.FIREBASE_STORAGE_BUCKET,

      // ── Email ───────────────────────────────────────────────────
      RESEND_API_KEY: process.env.RESEND_API_KEY,
      EMAIL_FROM: process.env.EMAIL_FROM,

      // ── Auth / App ──────────────────────────────────────────────
      JWT_SECRET: process.env.JWT_SECRET,
      FRONTEND_URL: process.env.FRONTEND_URL,
    }
  }]
};
