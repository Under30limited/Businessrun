/**
 * migrate-to-multitenant.js
 *
 * One-time migration: splits the OLD flat br-users shape into the new
 * multi-tenant model (identity / business / membership).
 *
 * Run once, AFTER creating the two new tables (br-businesses,
 * br-memberships) and the br-memberships businessUid-index GSI, and
 * BEFORE deploying the new auth.controller.js / gyb.controller.js /
 * team.controller.js / db.service.js.
 *
 *   node migrate-to-multitenant.js 2>&1 | tee multitenant-migration.log
 *
 * Safe to re-run — every write is idempotent (PutItem overwrites,
 * membership keys are deterministic).
 *
 * WHAT THIS HANDLES:
 *
 *   1. Old OWNER rows (role !== 'member', completed: true) — e.g.
 *      { uid, email, hashedPassword, businessName, stage, ... }
 *      →  br-businesses:  { businessUid: uid, businessName, stage, ... }
 *      →  br-memberships: { identityUid: uid, businessUid: uid,
 *                            role: 'owner', permissions: null,
 *                            status: 'active' }
 *      →  br-users row is REWRITTEN to pure identity shape (business
 *         fields stripped off; uid unchanged, so br-inventory/
 *         br-salesDayBook/br-dayLog/br-reports/br-cfoEntries — all
 *         keyed by this same uid — need ZERO changes).
 *
 *   2. Old MEMBER rows (from last turn's single-tenant team feature)
 *      — { uid, email, role:'member', ownerUid, permissions, status,
 *          hashedPassword, ... }
 *      →  br-memberships: { identityUid: uid, businessUid: ownerUid,
 *                            role: 'member', permissions, status,
 *                            inviteToken, inviteExpiresAt, ... }
 *      →  br-users row is REWRITTEN to pure identity shape.
 *
 *   3. In-flight GYB session docs (uid === sessionId, no
 *      hashedPassword, not completed) — left untouched. They're
 *      transient onboarding state, not real accounts yet.
 *
 * NOT idempotent-DESTRUCTIVE: this reads each row ONCE at the top and
 * decides its shape from the ORIGINAL fields, so it's safe to run
 * again (a row already migrated to pure-identity shape has no
 * businessName/ownerUid fields left, so it's correctly skipped on
 * a second pass — see the "already migrated" check below).
 */

'use strict';

require('dotenv').config();

const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const {
  DynamoDBDocumentClient,
  ScanCommand,
  PutCommand,
} = require('@aws-sdk/lib-dynamodb');

const dynamo = DynamoDBDocumentClient.from(
  new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-1' }),
  { marshallOptions: { removeUndefinedValues: true } }
);

const USERS_TABLE       = 'br-users';
const BUSINESSES_TABLE = 'br-businesses';
const MEMBERSHIPS_TABLE = 'br-memberships';

async function scanAll(tableName) {
  const items = [];
  let ExclusiveStartKey;
  do {
    const result = await dynamo.send(new ScanCommand({ TableName: tableName, ExclusiveStartKey }));
    items.push(...(result.Items || []));
    ExclusiveStartKey = result.LastEvaluatedKey;
  } while (ExclusiveStartKey);
  return items;
}

function isInFlightGybSession(row) {
  // uid === sessionId and no password yet — still mid-onboarding
  return row.sessionId === row.uid && !row.hashedPassword && !row.completed;
}

function isAlreadyMigrated(row) {
  // A pure identity row has 'claimed' set and none of the old
  // business/membership fields left on it.
  return row.claimed !== undefined && row.businessName === undefined && row.ownerUid === undefined;
}

function isOldMemberRow(row) {
  return row.role === 'member' && row.ownerUid !== undefined;
}

function isOldOwnerRow(row) {
  return row.completed === true && row.role !== 'member';
}

async function run() {
  console.log('Multi-tenant migration — splitting br-users into identity/business/membership');
  console.log('================================================================================');

  const rows = await scanAll(USERS_TABLE);
  console.log(`Scanned ${rows.length} br-users rows.\n`);

  let ownersMigrated  = 0;
  let membersMigrated = 0;
  let skippedSessions = 0;
  let skippedAlready  = 0;

  for (const row of rows) {
    if (isAlreadyMigrated(row)) { skippedAlready++; continue; }
    if (isInFlightGybSession(row)) { skippedSessions++; continue; }

    if (isOldOwnerRow(row)) {
      const businessUid = row.uid; // preserve — inventory/sales/etc are keyed by this

      await dynamo.send(new PutCommand({
        TableName: BUSINESSES_TABLE,
        Item: {
          businessUid,
          businessName: row.businessName || '',
          stage:        row.stage        || '',
          salesChannel: row.salesChannel || '',
          revenue:      row.revenue      || '',
          headache:     row.headache     || '',
          matchmaking:  row.matchmaking  || '',
          createdAt:    row.createdAt    || new Date().toISOString(),
          updatedAt:    new Date().toISOString(),
        },
      }));

      await dynamo.send(new PutCommand({
        TableName: MEMBERSHIPS_TABLE,
        Item: {
          identityUid: row.uid,
          businessUid,
          role:        'owner',
          permissions: null,
          status:      'active',
          email:       row.email || '',
          invitedAt:   row.createdAt || new Date().toISOString(),
          invitedBy:   null,
          acceptedAt:  row.createdAt || new Date().toISOString(),
          inviteToken: null,
          inviteExpiresAt: null,
          createdAt:   row.createdAt || new Date().toISOString(),
          updatedAt:   new Date().toISOString(),
        },
      }));

      await dynamo.send(new PutCommand({
        TableName: USERS_TABLE,
        Item: {
          uid:            row.uid,
          email:          row.email          || '',
          hashedPassword: row.hashedPassword || null,
          claimed:        true,
          fullName:       row.fullName       || '',
          // sessionId is a GSI key — never write '', omit entirely
          ...(row.sessionId ? { sessionId: row.sessionId } : {}),
          source:         row.source || 'businessrun-gyb',
          createdAt:      row.createdAt || new Date().toISOString(),
          updatedAt:      new Date().toISOString(),
        },
      }));

      ownersMigrated++;
      console.log(`  ✓ Owner migrated: ${row.uid} (${row.email}) → business ${businessUid}`);
      continue;
    }

    if (isOldMemberRow(row)) {
      await dynamo.send(new PutCommand({
        TableName: MEMBERSHIPS_TABLE,
        Item: {
          identityUid:     row.uid,
          businessUid:     row.ownerUid,
          role:            'member',
          permissions:     row.permissions || [],
          status:          row.status || 'pending',
          email:           row.email  || '',
          invitedAt:       row.invitedAt || new Date().toISOString(),
          invitedBy:       row.invitedBy || row.ownerUid,
          acceptedAt:      row.acceptedAt || null,
          inviteToken:     row.inviteToken     || null,
          inviteExpiresAt: row.inviteExpiresAt || null,
          createdAt:       row.createdAt || new Date().toISOString(),
          updatedAt:       new Date().toISOString(),
        },
      }));

      await dynamo.send(new PutCommand({
        TableName: USERS_TABLE,
        Item: {
          uid:            row.uid,
          email:          row.email          || '',
          hashedPassword: row.hashedPassword || null,
          claimed:        Boolean(row.hashedPassword),
          fullName:       row.fullName       || '',
          // sessionId is a GSI key — never write '', omit entirely
          ...(row.sessionId ? { sessionId: row.sessionId } : {}),
          source:         row.source || 'businessrun-gyb',
          createdAt:      row.createdAt || new Date().toISOString(),
          updatedAt:      new Date().toISOString(),
        },
      }));

      membersMigrated++;
      console.log(`  ✓ Member migrated: ${row.uid} (${row.email}) → business ${row.ownerUid}`);
      continue;
    }

    console.warn(`  ? Unrecognised row shape, left untouched: ${row.uid} (${row.email || 'no email'})`);
  }

  console.log('\n================================================================================');
  console.log(`Owners migrated:        ${ownersMigrated}`);
  console.log(`Members migrated:       ${membersMigrated}`);
  console.log(`Skipped (in-flight GYB sessions): ${skippedSessions}`);
  console.log(`Skipped (already migrated):       ${skippedAlready}`);
  console.log('\nVerify counts in br-businesses and br-memberships before deploying the new code.');
}

run().catch(err => {
  console.error('\nMigration FAILED:', err);
  process.exit(1);
});
