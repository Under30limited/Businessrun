/**
 * services/email.service.js
 *
 * Email delivery via Resend (https://resend.com).
 *
 * WHY RESEND:
 *   - 3,000 free emails/month, 100/day — enough for a growing product
 *   - Clean REST API — one fetch() call, no SDK required
 *   - Emails sent from your own domain land in inbox, not spam
 *   - Takes ~15 minutes to set up (domain verification + API key)
 *
 * ENVIRONMENT VARIABLES REQUIRED:
 *   RESEND_API_KEY    — from Resend dashboard → API Keys
 *   EMAIL_FROM        — verified sender e.g. noreply@thebusinessrun.com
 *
 * USAGE:
 *   const { sendOTPEmail, sendInviteEmail } = require('../services/email.service');
 *   await sendOTPEmail({ to: 'user@example.com', code: '483921', name: 'Ada' });
 *   await sendInviteEmail({ to: 'member@example.com', ownerBusinessName: 'Ada Foods', inviteUrl, featureLabels: ['Sales', 'Inventory'] });
 */

'use strict';

const RESEND_API_URL = 'https://api.resend.com/emails';

// ── Guard — fail loudly if config is missing ──────────────────────
function getConfig() {
  const apiKey  = process.env.RESEND_API_KEY;
  const from    = process.env.EMAIL_FROM || 'noreply@thebusinessrun.com';

  if (!apiKey) {
    throw new Error('[Email] RESEND_API_KEY is not set in .env');
  }

  return { apiKey, from };
}

// ── OTP email template ─────────────────────────────────────────────
function buildOTPEmail({ to, code, name }) {
  const firstName = (name || 'there').split(' ')[0];

  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body style="margin:0;padding:0;background:#0A0A0A;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#0A0A0A;padding:40px 20px;">
    <tr>
      <td align="center">
        <table width="520" cellpadding="0" cellspacing="0" style="background:#111111;border:1px solid #222222;border-radius:16px;overflow:hidden;">

          <!-- Header -->
          <tr>
            <td style="padding:32px 40px 24px;border-bottom:1px solid #1A1A1A;">
              <p style="margin:0;font-size:13px;font-weight:900;letter-spacing:0.15em;text-transform:uppercase;color:#C5A028;">
                BUSINESSRUN
              </p>
            </td>
          </tr>

          <!-- Body -->
          <tr>
            <td style="padding:36px 40px;">
              <p style="margin:0 0 8px;font-size:22px;font-weight:900;color:#FFFFFF;letter-spacing:-0.03em;">
                Password Reset Code
              </p>
              <p style="margin:0 0 28px;font-size:14px;color:#71717A;line-height:1.6;">
                Hi ${firstName}, use the code below to reset your BusinessRun password.
                This code expires in <strong style="color:#A1A1AA;">15 minutes</strong>.
              </p>

              <!-- OTP Code -->
              <div style="background:#0A0A0A;border:1px solid #222222;border-radius:12px;padding:28px;text-align:center;margin-bottom:28px;">
                <p style="margin:0 0 8px;font-size:11px;font-weight:900;letter-spacing:0.15em;text-transform:uppercase;color:#52525B;">
                  Your Reset Code
                </p>
                <p style="margin:0;font-size:40px;font-weight:900;letter-spacing:0.2em;color:#C5A028;font-variant-numeric:tabular-nums;">
                  ${code}
                </p>
              </div>

              <p style="margin:0 0 8px;font-size:12px;color:#52525B;line-height:1.6;">
                If you didn't request this, you can safely ignore this email.
                Your password will not change.
              </p>
              <p style="margin:0;font-size:12px;color:#52525B;line-height:1.6;">
                For security: never share this code with anyone.
                BusinessRun will never ask for it.
              </p>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="padding:20px 40px;border-top:1px solid #1A1A1A;">
              <p style="margin:0;font-size:11px;color:#3F3F46;">
                © ${new Date().getFullYear()} BusinessRun · thebusinessrun.com
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;

  const text =
    'BusinessRun Password Reset\n\n' +
    'Hi ' + firstName + ',\n\n' +
    'Your password reset code is: ' + code + '\n\n' +
    'This code expires in 15 minutes.\n\n' +
    'If you did not request this, please ignore this email.\n\n' +
    '© ' + new Date().getFullYear() + ' BusinessRun';

  return { to, subject: 'Your BusinessRun Reset Code: ' + code, html, text };
}

// ── sendOTPEmail ───────────────────────────────────────────────────
/**
 * Sends the OTP reset code to the user's email via Resend.
 *
 * @param {Object} opts
 * @param {string} opts.to    Recipient email
 * @param {string} opts.code  6-digit OTP code
 * @param {string} opts.name  User's full name (for personalisation)
 * @returns {Promise<void>}
 * @throws {Error} if Resend API returns an error
 */
async function sendOTPEmail({ to, code, name }) {
  const { apiKey, from } = getConfig();
  const email = buildOTPEmail({ to, code, name });

  let res;
  try {
    res = await fetch(RESEND_API_URL, {
      method:  'POST',
      headers: {
        'Authorization': 'Bearer ' + apiKey,
        'Content-Type':  'application/json',
      },
      body: JSON.stringify({
        from,
        to:      [to],
        subject: email.subject,
        html:    email.html,
        text:    email.text,
      }),
    });
  } catch (networkErr) {
    // fetch() itself threw — DNS failure, timeout, no internet
    throw new Error('[Email] Network error reaching Resend: ' + networkErr.message);
  }

  if (!res.ok) {
    let body = {};
    try { body = await res.json(); } catch { /* ignore parse failure */ }
    // Log full details server-side for debugging
    console.error('[Email] Resend API error:', {
      status:  res.status,
      message: body.message,
      name:    body.name,
      from,
      to,
    });
    throw new Error(
      '[Email] Resend rejected the request (' + res.status + '): ' +
      (body.message || 'Unknown error')
    );
  }
}

// ── Invite email template ──────────────────────────────────────────
function buildInviteEmail({ to, ownerBusinessName, inviteUrl, featureLabels }) {
  const businessName = ownerBusinessName || 'a business';
  const featureList   = (featureLabels || []).length
    ? featureLabels.join(', ')
    : 'selected features';

  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body style="margin:0;padding:0;background:#0A0A0A;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#0A0A0A;padding:40px 20px;">
    <tr>
      <td align="center">
        <table width="520" cellpadding="0" cellspacing="0" style="background:#111111;border:1px solid #222222;border-radius:16px;overflow:hidden;">

          <!-- Header -->
          <tr>
            <td style="padding:32px 40px 24px;border-bottom:1px solid #1A1A1A;">
              <p style="margin:0;font-size:13px;font-weight:900;letter-spacing:0.15em;text-transform:uppercase;color:#C5A028;">
                BUSINESSRUN
              </p>
            </td>
          </tr>

          <!-- Body -->
          <tr>
            <td style="padding:36px 40px;">
              <p style="margin:0 0 8px;font-size:22px;font-weight:900;color:#FFFFFF;letter-spacing:-0.03em;">
                You've been invited to ${businessName}
              </p>
              <p style="margin:0 0 28px;font-size:14px;color:#71717A;line-height:1.6;">
                You've been given access to: <strong style="color:#A1A1AA;">${featureList}</strong>.
                Set your password to get started.
              </p>

              <!-- CTA -->
              <div style="text-align:center;margin-bottom:28px;">
                <a href="${inviteUrl}" style="display:inline-block;background:#C5A028;color:#0A0A0A;font-weight:900;font-size:14px;text-decoration:none;padding:16px 32px;border-radius:10px;">
                  Set Your Password
                </a>
              </div>

              <p style="margin:0 0 8px;font-size:12px;color:#52525B;line-height:1.6;">
                This invite link expires in 7 days.
              </p>
              <p style="margin:0;font-size:12px;color:#52525B;line-height:1.6;">
                If you weren't expecting this, you can safely ignore this email.
              </p>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="padding:20px 40px;border-top:1px solid #1A1A1A;">
              <p style="margin:0;font-size:11px;color:#3F3F46;">
                © ${new Date().getFullYear()} BusinessRun · thebusinessrun.com
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;

  const text =
    `You've been invited to ${businessName} on BusinessRun\n\n` +
    `You've been given access to: ${featureList}.\n\n` +
    `Set your password here: ${inviteUrl}\n\n` +
    `This link expires in 7 days.\n\n` +
    `If you weren't expecting this, you can safely ignore this email.\n\n` +
    `© ${new Date().getFullYear()} BusinessRun`;

  return { to, subject: `You've been invited to ${businessName} on BusinessRun`, html, text };
}

// ── sendInviteEmail ─────────────────────────────────────────────────
/**
 * Sends a team-invite email with a link to set a password and join
 * the owner's business.
 *
 * @param {Object} opts
 * @param {string} opts.to                 Recipient email
 * @param {string} opts.ownerBusinessName  The inviting owner's business name
 * @param {string} opts.inviteUrl          Full link to the accept-invite page
 * @param {string[]} [opts.featureLabels]  Human-readable feature names granted
 * @returns {Promise<void>}
 * @throws {Error} if Resend API returns an error
 */
async function sendInviteEmail({ to, ownerBusinessName, inviteUrl, featureLabels }) {
  const { apiKey, from } = getConfig();
  const email = buildInviteEmail({ to, ownerBusinessName, inviteUrl, featureLabels });

  let res;
  try {
    res = await fetch(RESEND_API_URL, {
      method:  'POST',
      headers: {
        'Authorization': 'Bearer ' + apiKey,
        'Content-Type':  'application/json',
      },
      body: JSON.stringify({
        from,
        to:      [to],
        subject: email.subject,
        html:    email.html,
        text:    email.text,
      }),
    });
  } catch (networkErr) {
    throw new Error('[Email] Network error reaching Resend: ' + networkErr.message);
  }

  if (!res.ok) {
    let body = {};
    try { body = await res.json(); } catch { /* ignore parse failure */ }
    console.error('[Email] Resend API error:', {
      status:  res.status,
      message: body.message,
      name:    body.name,
      from,
      to,
    });
    throw new Error(
      '[Email] Resend rejected the request (' + res.status + '): ' +
      (body.message || 'Unknown error')
    );
  }
}

module.exports = { sendOTPEmail, sendInviteEmail };
