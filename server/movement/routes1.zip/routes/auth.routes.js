/**
 * routes/auth.routes.js
 *
 * POST /api/auth/login   → Verify credentials, issue JWT cookie, return profile
 * POST /api/auth/logout  → Clear the JWT cookie (server-side)
 * GET  /api/auth/me      → Validate cookie, return profile (used on app load)
 */

'use strict';

const express    = require('express');
const router     = express.Router();
const controller    = require('../controllers/auth.controller');
const otpController = require('../controllers/otp.controller');
const { protect }               = require('../middleware/auth');
const { authLimiter, otpLimiter, dataLimiter } = require('../middleware/rateLimiter');
const validate   = require('../middleware/validate');

const loginSchema = {
  email:    { required: true, type: 'email' },
  password: { required: true, type: 'string', min: 1 },
};

// Email existence check — used during GYB signup Step 1
// dataLimiter used (not authLimiter) — less strict, not a brute force target
router.post('/check-email',
  dataLimiter,
  controller.checkEmail
);

// Login — rate limited to prevent brute force
router.post('/login',
  authLimiter,
  validate(loginSchema),
  controller.login
);

// Logout — no auth required (clearing a missing cookie is harmless)
// Rate limit still applied to prevent log-flooding
router.post('/logout',
  authLimiter,
  controller.logout
);

// Session restore — called on every app load by AuthContext
// protect middleware reads the cookie and verifies the JWT
router.get('/me',
  protect,
  controller.getMe
);


// ── OTP Password Reset ────────────────────────────────────────────
// No auth required — user is locked out of their account
router.post('/otp/request', otpLimiter, otpController.requestOTP);
router.post('/otp/verify',  otpLimiter, otpController.verifyOTPCode);
router.post('/otp/reset',   otpLimiter, otpController.resetPassword);

module.exports = router;
