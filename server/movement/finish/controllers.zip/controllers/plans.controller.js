/**
 * controllers/plans.controller.js
 *
 * GET /api/plans — public, no auth required. Returns every plan
 * definition with a freshly-computed NGN display price, so the
 * frontend never hardcodes pricing or duplicates conversion logic.
 *
 * Note the distinction (see config/plans.js's header comment):
 *   priceNGNDisplay — live, via services/fx.service.js, changes daily
 *   priceNGNFixed   — what's ACTUALLY charged, fixed until
 *                     scripts/setup-paystack-plans.js is re-run
 * These will usually be close but not always identical — that's
 * expected and fine; the fixed price is what the customer is
 * literally being billed, the display price is just today's estimate
 * for browsing.
 */

'use strict';

const asyncHandler = require('../utils/asyncHandler');
const { PLANS, PLAN_ORDER } = require('../config/plans');
const { convertUsdToNgn }    = require('../services/fx.service');

const getPlans = asyncHandler(async (req, res) => {
  const plans = await Promise.all(
    PLAN_ORDER.map(async (planId) => {
      const plan = PLANS[planId];
      return {
        id:               plan.id,
        name:             plan.name,
        tagline:          plan.tagline,
        priceUSD:         plan.priceUSD,
        priceNGNDisplay:  plan.priceUSD > 0 ? await convertUsdToNgn(plan.priceUSD) : 0,
        priceNGNFixed:    plan.priceNGNFixed,
        features:         plan.features,
        limits:           plan.limits,
        // Whether this tier can actually be paid for yet — false until
        // scripts/setup-paystack-plans.js has been run for it.
        payable: {
          usd: Boolean(plan.paystack?.plans?.usd),
          ngn: Boolean(plan.paystack?.plans?.ngn),
        },
      };
    })
  );

  res.json({ success: true, plans });
});

module.exports = { getPlans };
