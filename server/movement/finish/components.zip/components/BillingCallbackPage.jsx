/**
 * BillingCallbackPage.jsx
 *
 * Route: /billing/callback
 *
 * Paystack redirects the browser here after checkout (success,
 * cancellation, or failure) with a `reference` (or `trxref`) query
 * param. This page calls GET /api/payments/verify/:reference for an
 * immediate, definitive answer — rather than making the user guess
 * while the webhook processes asynchronously in the background (the
 * webhook still runs regardless and remains the source of truth for
 * renewals; this call is a redundant-but-safe, idempotent confirmation
 * that just gives faster feedback for THIS checkout).
 */

import React, { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { CheckCircle2, XCircle, Loader2, ArrowRight } from 'lucide-react';

export default function BillingCallbackPage() {
  const [searchParams] = useSearchParams();
  const navigate         = useNavigate();
  const { refreshSubscription } = useAuth();

  const reference = searchParams.get('reference') || searchParams.get('trxref') || '';

  const [status,  setStatus]  = useState('checking'); // 'checking' | 'success' | 'failed'
  const [message, setMessage] = useState('');
  const [planName, setPlanName] = useState('');

  useEffect(() => {
    if (!reference) {
      setStatus('failed');
      setMessage('No payment reference found in the link. If you completed checkout, check your dashboard — it may have already gone through.');
      return;
    }

    let cancelled = false;
    (async () => {
      try {
        const res  = await fetch(`/api/payments/verify/${encodeURIComponent(reference)}`, {
          credentials: 'include',
        });
        const data = await res.json();

        if (cancelled) return;

        if (!res.ok || !data.success) {
          setStatus('failed');
          setMessage(data.message || 'Could not confirm this payment. Please contact support if you were charged.');
          return;
        }

        if (data.paymentStatus === 'success') {
          setStatus('success');
          setPlanName(data.planName || '');
          await refreshSubscription(); // so the dashboard reflects the new plan immediately
        } else {
          setStatus('failed');
          setMessage('This payment was not completed. No charge was made — feel free to try again.');
        }
      } catch {
        if (!cancelled) {
          setStatus('failed');
          setMessage('Network error confirming this payment. Check your dashboard, or contact support if you were charged.');
        }
      }
    })();

    return () => { cancelled = true; };
  }, [reference, refreshSubscription]);

  return (
    <div className="min-h-screen bg-zinc-950 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white border border-zinc-200 rounded-2xl shadow-2xl p-8 text-center">
        {status === 'checking' && (
          <>
            <Loader2 size={32} className="animate-spin text-amber-500 mx-auto mb-4" />
            <h1 className="text-lg font-black uppercase tracking-tight text-zinc-900">Confirming Payment…</h1>
            <p className="text-sm text-zinc-500 mt-2">This only takes a moment.</p>
          </>
        )}

        {status === 'success' && (
          <>
            <div className="w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-4 bg-green-500/10">
              <CheckCircle2 size={24} className="text-green-500" />
            </div>
            <h1 className="text-lg font-black uppercase tracking-tight text-zinc-900">Payment Successful</h1>
            <p className="text-sm text-zinc-500 mt-2">
              {planName ? `You're now on ${planName}.` : 'Your subscription is now active.'}
            </p>
            <button
              onClick={() => navigate('/your-roadmap', { replace: true })}
              className="mt-6 w-full flex items-center justify-center gap-2 bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-widest py-3.5 rounded-xl transition"
            >
              Go to Dashboard
              <ArrowRight size={15} />
            </button>
          </>
        )}

        {status === 'failed' && (
          <>
            <div className="w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-4 bg-red-500/10">
              <XCircle size={24} className="text-red-500" />
            </div>
            <h1 className="text-lg font-black uppercase tracking-tight text-zinc-900">Payment Not Completed</h1>
            <p className="text-sm text-zinc-500 mt-2">{message}</p>
            <button
              onClick={() => navigate('/billing', { replace: true })}
              className="mt-6 w-full flex items-center justify-center gap-2 bg-zinc-900 hover:bg-zinc-800 text-white font-black text-xs uppercase tracking-widest py-3.5 rounded-xl transition"
            >
              Back to Billing
            </button>
          </>
        )}
      </div>
    </div>
  );
}
