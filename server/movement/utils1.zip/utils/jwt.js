/**
 * utils/jwt.js
 *
 * Sign and verify JSON Web Tokens for BusinessRun session management.
 *
 * WHY JWT (not just cookies with profile data):
 *   A cookie holding raw profile JSON could be tampered with by anyone
 *   who edits their browser storage — they could set businessName to
 *   anything, or worse, forge a uid. A JWT is cryptographically signed
 *   with a secret only the server knows. If anyone tampers with the
 *   payload, the signature no longer matches and the server rejects it.
 *
 * WHAT IS STORED IN THE TOKEN:
 *   Only the minimum needed to identify the user and restore their profile:
 *     uid          — Firestore document ID (to fetch fresh profile if needed)
 *     email        — for logging and /api/auth/me lookups
 *     businessName — so RoadmapPage can render immediately without a DB call
 *     fullName
 *     stage
 *     salesChannel
 *     revenue
 *     headache
 *     matchmaking
 *
 *   No password, no sensitive data, no payment info.
 *
 * TOKEN LIFETIME:
 *   ACCESS TOKEN  — 7 days (JWT_EXPIRES_IN env var, default '7d').
 *     Stored in an HTTP-only, Secure, SameSite=Strict cookie.
 *     The browser sends it automatically — JS cannot read or steal it.
 *
 * ENVIRONMENT VARIABLES REQUIRED:
 *   JWT_SECRET      — long random string (min 32 chars). Generate with:
 *                     node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
 *   JWT_EXPIRES_IN  — optional, defaults to '7d'
 *
 * USAGE:
 *   const { signToken, verifyToken } = require('../utils/jwt');
 *   const token = signToken(profile);                // sign
 *   const payload = verifyToken(token);              // verify → payload or throws
 */

'use strict';

const jwt      = require('jsonwebtoken');
const ApiError = require('./ApiError');

// ── Guard: fail loudly at startup if secret is missing ────────────
// Never silently fall back to a weak or empty secret in production.
function getSecret() {
  const secret = process.env.JWT_SECRET;
  if (!secret || secret.length < 32) {
    throw new Error(
      '[JWT] JWT_SECRET is not set or is too short (need ≥ 32 chars). ' +
      'Generate one with: node -e "console.log(require(\'crypto\').randomBytes(64).toString(\'hex\'))"'
    );
  }
  return secret;
}

// ── Cookie configuration ──────────────────────────────────────────
// Centralised here so auth controller and auth middleware use exactly
// the same settings — no risk of mismatch between set and clear calls.
const COOKIE_NAME = 'br_token';

const COOKIE_OPTIONS = {
  httpOnly:  true,            // JS cannot read this cookie — blocks XSS token theft
  secure:    process.env.NODE_ENV === 'production', // HTTPS only in production
  sameSite:  'lax',        // never sent on cross-site requests — blocks CSRF
  maxAge:    7 * 24 * 60 * 60 * 1000, // 7 days in milliseconds (matches JWT expiry)
  path:      '/',             // cookie valid for all routes

};

// Cookie options for clearing (maxAge 0 + expires in the past)
const CLEAR_COOKIE_OPTIONS = {
  ...COOKIE_OPTIONS,
  maxAge:  0,
  expires: new Date(0),
};

// ── signToken ─────────────────────────────────────────────────────
/**
 * Signs a JWT containing the user's profile fields.
 * Called on login (POST /api/auth/login) and signup (POST /api/gyb step 4).
 *
 * @param {Object} profile  Normalised user profile from Firestore
 * @returns {string}        Signed JWT string
 */
function signToken(profile) {
  const secret  = getSecret();
  const payload = {
    uid:          profile.uid          || '',
    email:        profile.email        || '',
    fullName:     profile.fullName     || '',
    businessName: profile.businessName || '',
    stage:        profile.stage        || '',
    salesChannel: profile.salesChannel || '',
    revenue:      profile.revenue      || '',
    headache:     profile.headache     || '',
    matchmaking:  profile.matchmaking  || '',
  };

  return jwt.sign(payload, secret, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
    algorithm: 'HS256',
  });
}

// ── verifyToken ───────────────────────────────────────────────────
/**
 * Verifies a JWT and returns its payload.
 * Called by the auth middleware on every protected or session-restore request.
 *
 * Throws ApiError 401 if the token is:
 *   - Missing or malformed
 *   - Expired (TokenExpiredError)
 *   - Tampered with (JsonWebTokenError)
 *
 * @param {string} token  Raw JWT string
 * @returns {Object}      Decoded payload { uid, email, fullName, ... }
 */
function verifyToken(token) {
  try {
    return jwt.verify(token, getSecret(), { algorithms: ['HS256'] });
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      throw ApiError.unauthorized('Your session has expired. Please log in again.');
    }
    throw ApiError.unauthorized('Invalid session token. Please log in again.');
  }
}

module.exports = {
  COOKIE_NAME,
  COOKIE_OPTIONS,
  CLEAR_COOKIE_OPTIONS,
  signToken,
  verifyToken,
};
