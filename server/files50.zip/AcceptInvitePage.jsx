/**
 * AcceptInvitePage.jsx
 *
 * Public route: /accept-invite?uid=...&token=...
 *
 * The link comes from the invite email (see services/email.service.js
 * sendInviteEmail on the backend). Sets a password, which activates
 * the member and logs them straight in — POST /api/team/accept-invite
 * sets the session cookie server-side, same pattern as GYB step 4.
 */

import React, { useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Lock, Loader2, AlertCircle, CheckCircle2 } from 'lucide-react';

const inputClass = 'w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm text-zinc-900 placeholder:text-zinc-400 focus:outline-none focus:border-amber-500 transition-colors';
const BRAND = '#C5A028';

export default function AcceptInvitePage() {
  const [searchParams] = useSearchParams();
  const navigate        = useNavigate();
  const { login }        = useAuth();

  const uid   = searchParams.get('uid')   || '';
  const token = searchParams.get('token') || '';

  const [password,        setPassword]        = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [submitting,      setSubmitting]      = useState(false);
  const [error,           setError]           = useState('');

  const linkLooksValid = Boolean(uid && token);

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');

    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    setSubmitting(true);
    try {
      const res  = await fetch('/api/team/accept-invite', {
        method:      'POST',
        credentials: 'include',
        headers:     { 'Content-Type': 'application/json' },
        body:        JSON.stringify({ uid, token, password }),
      });
      const data = await res.json();

      if (!res.ok || !data.success) {
        setError(data.message || 'This invite link is invalid or has expired.');
        setSubmitting(false);
        return;
      }

      // Cookie is already set by the server — hydrate AuthContext and
      // go straight to the dashboard, same as GYB step 4 does.
      login(data.profile);
      navigate('/your-roadmap', { replace: true });
    } catch {
      setError('Network error. Please check your connection and try again.');
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen bg-zinc-950 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white border border-zinc-200 rounded-2xl shadow-2xl p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: BRAND + '15' }}>
            <Lock size={17} style={{ color: BRAND }} />
          </div>
          <div>
            <h1 className="text-lg font-black uppercase tracking-tight text-zinc-900">Set Your Password</h1>
            <p className="text-xs text-zinc-500">You've been invited to join a business on BusinessRun</p>
          </div>
        </div>

        {!linkLooksValid ? (
          <div className="flex items-start gap-2 px-4 py-3 bg-red-50 border border-red-200 rounded-xl text-sm text-red-600">
            <AlertCircle size={16} className="flex-shrink-0 mt-0.5" />
            <span>This invite link is missing information. Please use the exact link from your invite email.</span>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">
                New password
              </label>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="At least 6 characters"
                className={inputClass}
                autoFocus
              />
            </div>

            <div>
              <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">
                Confirm password
              </label>
              <input
                type="password"
                value={confirmPassword}
                onChange={e => setConfirmPassword(e.target.value)}
                placeholder="Re-enter your password"
                className={inputClass}
              />
            </div>

            {error && (
              <div className="flex items-start gap-2 px-4 py-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-600">
                <AlertCircle size={14} className="flex-shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full flex items-center justify-center gap-2 bg-amber-500 hover:bg-amber-400 disabled:opacity-60 text-black font-black text-xs uppercase tracking-widest py-3.5 rounded-xl transition"
            >
              {submitting ? <Loader2 size={15} className="animate-spin" /> : <CheckCircle2 size={15} />}
              {submitting ? 'Activating…' : 'Activate My Account'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
