import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// ── Register Service Worker ───────────────────────────────────────
// Only in production — service workers interfere with hot reload in dev.
// The SW enables offline support, home screen installation, and
// background caching that makes the app feel native on mobile.
if ('serviceWorker' in navigator && process.env.NODE_ENV === 'production') {
  window.addEventListener('load', () => {
    navigator.serviceWorker
      .register('/sw.js')
      .then(registration => {
        console.log('[SW] Registered:', registration.scope);

        // Check for updates every time the app loads
        registration.addEventListener('updatefound', () => {
          const newWorker = registration.installing;
          if (!newWorker) return;

          newWorker.addEventListener('statechange', () => {
            if (
              newWorker.state === 'installed' &&
              navigator.serviceWorker.controller
            ) {
              // A new version is available — the app will use it on next load.
              // In future: show a "Update available — reload" toast to the user.
              console.log('[SW] New version available. Reload to update.');
            }
          });
        });
      })
      .catch(error => {
        console.error('[SW] Registration failed:', error);
      });
  });
}
