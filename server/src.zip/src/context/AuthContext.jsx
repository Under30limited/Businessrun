/**
 * context/AuthContext.jsx
 *
 * Global authentication state for BusinessRun.
 *
 * HOW THE COOKIE SESSION WORKS — end to end:
 *
 *   1. USER LOGS IN (or completes GYB signup):
 *      - Server verifies credentials / creates account
 *      - Server signs a JWT and sets it as an HTTP-only cookie named 'br_token'
 *      - Server returns the profile in the response body
 *      - Frontend calls login(profile) → stores profile in React state only
 *      - React state is fast; cookie is the durable source of truth
 *
 *   2. USER REFRESHES THE PAGE (or opens a new tab):
 *      - React state is wiped (it lives only in memory)
 *      - AuthContext calls GET /api/auth/me on mount
 *      - Browser automatically sends the 'br_token' cookie with the request
 *      - Server verifies the JWT, returns the profile
 *      - AuthContext calls login(profile) to re-populate React state
 *      - RoadmapPage renders with real data — user never sees a loading blip
 *        if /api/auth/me responds before the guard effect fires
 *
 *   3. USER IS NOT LOGGED IN (direct URL visitor, expired cookie):
 *      - GET /api/auth/me returns 401
 *      - AuthContext sets user = null, isAuthenticated = false
 *      - RoadmapPage guard redirects to home
 *
 *   4. USER LOGS OUT:
 *      - Frontend calls logout()
 *      - POST /api/auth/logout — server clears the cookie (only the server
 *        can clear an HTTP-only cookie; JS cannot touch it)
 *      - React state cleared, user redirected to home
 *
 * WHY NO sessionStorage / localStorage:
 *   With HTTP-only cookies, no token ever touches JS-accessible storage.
 *   XSS attacks cannot steal the session token because they cannot read
 *   HTTP-only cookies. This is the industry-standard approach.
 *
 * USAGE:
 *   // In App.jsx (once):
 *   <AuthProvider> ... </AuthProvider>
 *
 *   // Anywhere in the tree:
 *   const { user, isAuthenticated, isRestoring, login, logout } = useAuth();
 */

import React, {
  createContext, useContext, useState,
  useCallback, useEffect, useRef,
} from 'react';

// ── Context ───────────────────────────────────────────────────────
const AuthContext = createContext(null);

// ── Provider ──────────────────────────────────────────────────────
export function AuthProvider({ children }) {
  const [user,         setUser]         = useState(null);
  const [isRestoring,  setIsRestoring]  = useState(true);  // true while /me is in-flight

  // Prevent double-firing in React 18 StrictMode (mounts twice in dev)
  const restoredRef = useRef(false);

  // ── Session restore on mount ────────────────────────────────────
  // On every page load / refresh, ask the server "is my cookie still valid?"
  // The browser sends the HTTP-only cookie automatically — no JS cookie access.
  useEffect(() => {
    if (restoredRef.current) return;
    restoredRef.current = true;

    async function restoreSession() {
      // Safety net — if /api/auth/me never resolves (network stall,
      // server down, CORS issue), we must still clear isRestoring so
      // the page never stays permanently blank. 8 seconds is generous
      // enough for slow connections but short enough to feel responsive.
      const safetyTimer = setTimeout(() => {
        setIsRestoring(false);
      }, 8000);

      try {
        const res = await fetch('/api/auth/me', {
          method:      'GET',
          credentials: 'include',
        });

        if (res.ok) {
          const data = await res.json();
          if (data.success && data.profile) {
            setUser(data.profile);
          }
        }
        // 401 = no valid cookie — user stays null (not logged in)
      } catch {
        // Network error — stay null, let the page guard handle it
      } finally {
        clearTimeout(safetyTimer);
        setIsRestoring(false);
      }
    }

    restoreSession();
  }, []);

  // ── login ────────────────────────────────────────────────────────
  /**
   * Called immediately after a successful login or signup response.
   * The profile comes from the server response body — the cookie was
   * already set by the server in the same response.
   *
   * @param {Object} profile  Normalised profile from server response
   */
  const login = useCallback((profile) => {
    setUser(profile);
  }, []);

  // ── logout ───────────────────────────────────────────────────────
  /**
   * Calls POST /api/auth/logout to clear the HTTP-only cookie server-side
   * (JS cannot clear HTTP-only cookies itself), then clears React state.
   *
   * @param {Function} [navigate]  Optional — pass navigate to redirect after logout
   */
  const logout = useCallback(async (navigate) => {
    try {
      await fetch('/api/auth/logout', {
        method:      'POST',
        credentials: 'include',
      });
    } catch {
      // If the network request fails, clear React state anyway —
      // the cookie will expire naturally in 7 days
      console.warn('[Auth] Logout request failed — clearing local state only.');
    }
    setUser(null);
    if (typeof navigate === 'function') {
      navigate('/', { replace: true });
    }
  }, []);

  // ── setUserProfile ───────────────────────────────────────────────
  /**
   * Merges partial updates into the current user profile.
   * Does NOT update the cookie — call a server endpoint and re-login()
   * if you need the cookie to reflect new data.
   *
   * @param {Object} updates  Partial profile fields to merge
   */
  const setUserProfile = useCallback((updates) => {
    setUser((prev) => (prev ? { ...prev, ...updates } : prev));
  }, []);

  const value = {
    user,
    isAuthenticated: user !== null,
    isRestoring,    // true while /api/auth/me is in-flight — guards can wait on this
    login,
    logout,
    setUserProfile,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

// ── useAuth hook ──────────────────────────────────────────────────
export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth() must be used inside <AuthProvider>.');
  }
  return ctx;
}
