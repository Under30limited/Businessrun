/**
 * controllers/payments.controller.js
 *
 * POST /api/payments/initialize  — owner starts a checkout for a plan
 * POST /api/payments/webhook     — Paystack calls this on every event
 *
 * ── WHY OWNER-ONLY ────────────────────────────────────────────────
 * Per how this was scoped: only the business owner can renew/change
 * a subscription — a team member only ever sees an informational
 * "ask your owner" prompt, never a real payment action.
 *
 * ── WEBHOOK IDENTIFICATION STRATEGY ─────────────────────────────────
 * The FIRST charge (from /initialize) carries OUR metadata
 * ({ businessUid, planId, currency }) reliably, because it's the same
 * request/response cycle we control. Paystack does not clearly
 * guarantee that metadata survives onto later, subscription-driven
 * renewal charges — so every event handler tries metadata.businessUid
 * FIRST, and falls back to looking up the business by
 * paystackCustomerCode (via a GSI) if metadata is missing. The
 * customer code itself is captured and stored on the very first
 * event (subscription.create), so the fallback path is always
 * available from the second charge onward.
 */

'use strict';

const asyncHandler = require('../utils/asyncHandler');
const ApiError      = require('../utils/ApiError');
const { sanitise, requireFields } = require('../utils/sanitise');
const db             = require('../services/db.service');
const paystack       = require('../services/paystack.service');
const { PLANS, getPlanByPaystackCode } = require('../config/plans');
const { v4: uuidv4 } = require('uuid');

const APP_URL = process.env.APP_URL || 'https://thebusinessrun.com';

// ── POST /api/payments/initialize ───────────────────────────────────
const initialize = asyncHandler(async (req, res) => {
  if (req.user.role === 'member') {
    throw ApiError.forbidden('Only the business owner can manage billing. Ask them to renew or change the plan.');
  }

  const body = sanitise(req.body, ['planId', 'currency']);
  requireFields(body, ['planId', 'currency']);

  const plan = PLANS[body.planId];
  if (!plan || body.planId === 'zero') {
    throw ApiError.badRequest('Invalid plan.');
  }

  const currency = body.currency.toUpperCase();
  if (!['USD', 'NGN'].includes(currency)) {
    throw ApiError.badRequest('currency must be USD or NGN.');
  }

  const planCode = currency === 'USD' ? plan.paystack.plans.usd : plan.paystack.plans.ngn;
  if (!planCode) {
    throw ApiError.badRequest(
      `${plan.name} (${currency}) isn't set up for payment yet — run scripts/setup-paystack-plans.js first.`
    );
  }

  const reference = `br_${req.user.uid}_${Date.now()}_${uuidv4().slice(0, 8)}`;

  // Paystack's /transaction/initialize validates that `amount` is a
  // real positive number even when `plan` is present — the plan's own
  // configured amount is still what actually governs the recurring
  // charge, but the request itself is rejected ("Invalid Amount Sent")
  // without a properly-formatted amount alongside it. Computed exactly
  // the same way scripts/setup-paystack-plans.js computed it when the
  // Plan was created, so the two always agree.
  const amount = currency === 'USD'
    ? Math.round(plan.priceUSD * 100)               // cents
    : Math.round((plan.priceNGNFixed || 0) * 100);   // kobo

  const transaction = await paystack.initializeTransaction({
    email:       req.user.email,
    planCode,
    amount,
    callbackUrl: `${APP_URL}/billing/callback`,
    reference,
    metadata: {
      businessUid: req.user.uid,
      planId:      body.planId,
      currency,
    },
  });

  res.json({
    success:          true,
    authorizationUrl: transaction.authorization_url,
    reference:         transaction.reference,
  });
});

// ── Webhook helpers ──────────────────────────────────────────────────

/**
 * resolveBusinessUid
 * Metadata first (reliable on the first charge), customer-code GSI
 * fallback (for renewals where metadata may be absent).
 */
async function resolveBusinessUid(data) {
  const metaBusinessUid = data?.metadata?.businessUid;
  if (metaBusinessUid) return metaBusinessUid;

  const customerCode = data?.customer?.customer_code;
  if (customerCode) {
    const subscription = await db.getSubscriptionByPaystackCustomerCode(customerCode);
    if (subscription) return subscription.businessUid;
  }

  return null;
}

function addOneMonth(fromISO) {
  const d = new Date(fromISO || Date.now());
  d.setUTCMonth(d.getUTCMonth() + 1);
  return d.toISOString();
}

// ── Event handlers ────────────────────────────────────────────────────

async function handleSubscriptionCreate(data) {
  const businessUid = await resolveBusinessUid(data);
  if (!businessUid) {
    console.error('[Paystack webhook] subscription.create: could not resolve businessUid', data?.customer?.customer_code);
    return;
  }

  const match = getPlanByPaystackCode(data.plan?.plan_code);

  await db.updateSubscription(businessUid, {
    planId:                   match?.planId || data?.metadata?.planId || 'plus1',
    status:                   'active',
    currentPeriodEnd:         data.next_payment_date || addOneMonth(),
    paystackCustomerCode:     data.customer?.customer_code || null,
    paystackSubscriptionCode: data.subscription_code || null,
    currency:                 match?.currency || data?.metadata?.currency || null,
  });

  console.log(`[Paystack webhook] subscription.create → business ${businessUid} is now active on ${match?.planId || data?.metadata?.planId}`);
}

async function handleChargeSuccess(data) {
  const businessUid = await resolveBusinessUid(data);
  if (!businessUid) {
    console.error('[Paystack webhook] charge.success: could not resolve businessUid', data?.customer?.customer_code);
    return;
  }

  // A charge not tied to a subscription (shouldn't normally happen
  // for our flow, since every checkout goes through a plan_code) —
  // still safe to just extend the period defensively.
  await db.updateSubscription(businessUid, {
    status:               'active',
    currentPeriodEnd:     addOneMonth(),
    paystackCustomerCode: data.customer?.customer_code || undefined,
  });

  console.log(`[Paystack webhook] charge.success → business ${businessUid} period extended`);
}

async function handlePaymentFailed(data) {
  const businessUid = await resolveBusinessUid(data);
  if (!businessUid) {
    console.error('[Paystack webhook] payment failed: could not resolve businessUid', data?.customer?.customer_code);
    return;
  }

  await db.updateSubscription(businessUid, { status: 'past_due' });
  console.log(`[Paystack webhook] payment failed → business ${businessUid} marked past_due`);
}

async function handleSubscriptionDisable(data) {
  const businessUid = await resolveBusinessUid(data);
  if (!businessUid) {
    console.error('[Paystack webhook] subscription.disable: could not resolve businessUid', data?.customer?.customer_code);
    return;
  }

  await db.updateSubscription(businessUid, { status: 'canceled' });
  console.log(`[Paystack webhook] subscription.disable → business ${businessUid} marked canceled`);
}

// ── POST /api/payments/webhook ──────────────────────────────────────
/**
 * No auth — Paystack calls this directly. Security comes entirely
 * from signature verification, not from a session/cookie.
 *
 * Must return 200 quickly (Paystack retries on anything else, and
 * on timeouts) — every handler above is a small, fast DynamoDB write,
 * so processing inline before responding is fine at this scale.
 */
const webhook = asyncHandler(async (req, res) => {
  const signature = req.headers['x-paystack-signature'];

  if (!paystack.verifyWebhookSignature(req.rawBody, signature)) {
    console.error('[Paystack webhook] Invalid signature — rejecting.');
    return res.status(401).json({ success: false });
  }

  const { event, data } = req.body;

  try {
    switch (event) {
      case 'subscription.create':
        await handleSubscriptionCreate(data);
        break;
      case 'charge.success':
        await handleChargeSuccess(data);
        break;
      case 'invoice.payment_failed':
      case 'charge.failed':
        await handlePaymentFailed(data);
        break;
      case 'subscription.disable':
      case 'subscription.not_renew':
        await handleSubscriptionDisable(data);
        break;
      default:
        console.log(`[Paystack webhook] Unhandled event type: ${event}`);
    }
  } catch (err) {
    // Log but still return 200 — Paystack will retry a non-200
    // response for up to 72 hours, which would just repeat this same
    // failure. A logged error here is something for us to look into
    // manually, not something Paystack retrying helps with.
    console.error(`[Paystack webhook] Error processing "${event}":`, err.message);
  }

  res.status(200).json({ success: true });
});

// ── GET /api/payments/verify/:reference ───────────────────────────
/**
 * Called by the billing callback page right after Paystack redirects
 * the browser back — gives the user INSTANT feedback rather than
 * making them guess while the webhook processes asynchronously in
 * the background. Safe to call alongside the webhook: both apply the
 * same idempotent update, and Paystack's own docs confirm verify
 * itself is idempotent to call repeatedly.
 *
 * SESSION IS OPTIONAL HERE (see routes/payments.routes.js) — req.user
 * may be null if the cookie expired while the founder was on
 * Paystack's hosted checkout page (card entry / OTP / 3D Secure
 * routinely take several minutes). This endpoint does NOT depend on
 * req.user for correctness: paystack.verifyTransaction() below is a
 * server-to-server call authenticated with OUR secret key, so its
 * response is exactly as trustworthy as a valid session — it's the
 * same trust model the signature-verified webhook already relies on
 * unauthenticated. req.user, when present, is used only as an EXTRA
 * ownership check, never as the sole source of which business to
 * upgrade (that's targetBusinessUid below, driven by Paystack's own
 * metadata).
 *
 * Two fraud-prevention checks before trusting the result, per
 * Paystack's own guidance: (1) if we know both who's asking AND whose
 * payment this was, they must match; (2) the amount actually charged
 * must match what the plan costs — "status: success" alone is not
 * sufficient to grant value.
 */
const verify = asyncHandler(async (req, res) => {
  if (req.user && req.user.role === 'member') {
    throw ApiError.forbidden('Only the business owner can manage billing.');
  }

  const { reference } = req.params;
  if (!reference) throw ApiError.badRequest('Missing transaction reference.');

  const result = await paystack.verifyTransaction(reference);

  if (result.status !== 'success') {
    return res.json({
      success:       true,
      paymentStatus: result.status, // 'abandoned' | 'failed' | 'pending' | ...
      message:       'This payment was not completed successfully.',
    });
  }

  const metaBusinessUid = result.metadata?.businessUid;

  // Fraud check 1 — only meaningful (and only possible) when we have
  // BOTH a logged-in session AND Paystack's own metadata to compare
  // it against. If either is missing, there's nothing to compare —
  // see targetBusinessUid below for why skipping this stays safe.
  if (req.user && metaBusinessUid && metaBusinessUid !== req.user.uid) {
    throw ApiError.forbidden('This transaction does not belong to your business.');
  }

  // Which business actually gets upgraded: Paystack's own verified
  // metadata is authoritative on its own — same as the webhook — so
  // it takes priority. Falls back to the logged-in user's uid only
  // for the unexpected case where metadata is absent but the request
  // is still authenticated.
  const targetBusinessUid = metaBusinessUid || req.user?.uid;
  if (!targetBusinessUid) {
    throw ApiError.badRequest(
      `Could not determine which business this payment belongs to. If you were charged, contact support with this reference: ${reference}`
    );
  }

  const match = getPlanByPaystackCode(result.plan?.plan_code);
  const planId = match?.planId || result.metadata?.planId;
  const plan   = planId ? PLANS[planId] : null;

  // Fraud check 2 — amount actually charged must match the plan's
  // real price (Paystack sends amounts in the smallest currency unit
  // — kobo for NGN, cents for USD — same convention used when the
  // plans were created in scripts/setup-paystack-plans.js).
  if (plan) {
    const currency       = match?.currency || result.metadata?.currency;
    const expectedAmount = currency === 'USD'
      ? Math.round(plan.priceUSD * 100)
      : Math.round((plan.priceNGNFixed || 0) * 100);

    if (expectedAmount > 0 && result.amount !== expectedAmount) {
      console.error(
        `[Payments] Amount mismatch for ${reference}: expected ${expectedAmount}, got ${result.amount}`
      );
      throw ApiError.badRequest('Payment amount does not match the expected plan price.');
    }
  }

  // Apply the same update the webhook would — idempotent, safe to
  // repeat. The webhook remains authoritative for
  // paystackSubscriptionCode specifically (set by subscription.create).
  await db.updateSubscription(targetBusinessUid, {
    ...(planId ? { planId } : {}),
    status:               'active',
    currentPeriodEnd:     addOneMonth(),
    paystackCustomerCode: result.customer?.customer_code || undefined,
    currency:             match?.currency || result.metadata?.currency || undefined,
  });

  res.json({
    success:       true,
    paymentStatus: 'success',
    planName:      plan?.name || null,
    // Lets the frontend know whether the browser's own session is
    // still valid — if not, the upgrade is applied and safe, but the
    // UI won't reflect it until the founder logs back in.
    sessionValid:  Boolean(req.user),
  });
});

module.exports = { initialize, webhook, verify };
