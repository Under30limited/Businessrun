/**
 * controllers/advisor.controller.js
 *
 * Handles the Strategic AI Advisor chat.
 * Proxies the request to Gemini via gemini.service.
 * Optionally saves conversation history to Firestore for logged-in users.
 *
 * Route:
 *   POST /api/advisor
 */

'use strict';

const asyncHandler    = require('../utils/asyncHandler');
const ApiError        = require('../utils/ApiError');
const { sanitise, requireFields } = require('../utils/sanitise');
const geminiService   = require('../services/gemini.service');
const firebaseService = require('../services/firebase.service');

// ── POST /api/advisor ─────────────────────────────────────────────
const chat = asyncHandler(async (req, res) => {
  const body = sanitise(req.body, ['message', 'history', 'sessionId']);
  requireFields(body, ['message']);

  if (typeof body.message !== 'string' || !body.message.trim()) {
    throw ApiError.badRequest('Message cannot be empty.');
  }

  // Validate history array if provided
  const history = Array.isArray(body.history) ? body.history : [];

  // Enforce reasonable limits to prevent abuse
  if (body.message.length > 2000) {
    throw ApiError.badRequest('Message is too long. Maximum 2000 characters.');
  }
  if (history.length > 40) {
    // Only keep the last 40 messages to avoid sending huge payloads to Gemini
    body.history = history.slice(-40);
  }

  let result;
  try {
    result = await geminiService.getAdvisorReply(body.message.trim(), history);
  } catch (err) {
    // AI unavailable — return advisorDown flag so the frontend
    // shows the friendly "unavailable" card rather than an error
    if (err.statusCode === 503) {
      return res.json({ text: null, advisorDown: true });
    }
    throw err;
  }

  // Optionally persist the conversation for logged-in users
  // req.user is set by the optionalAuth middleware on this route
  if (req.user && body.sessionId) {
    const updatedMessages = [
      ...history,
      { role: 'user',      content: body.message.trim() },
      { role: 'assistant', content: result.text          },
    ];

    // Fire and forget — don't await so it doesn't slow down the response
    firebaseService
      .upsertAdvisorSession(body.sessionId, req.user.uid, updatedMessages)
      .catch((err) =>
        console.error('[Advisor] Failed to save session:', err.message)
      );
  }

  res.json({ text: result.text });
});

module.exports = { chat };
