/**
 * controllers/auth.controller.js
 *
 * Login — finds user in Firestore by email, verifies password
 * with bcrypt.compare against the stored hash, returns profile.
 *
 * No Firebase Auth involved. Authentication is purely:
 *   bcrypt.compare(submittedPassword, storedHashedPassword)
 */

'use strict';

const asyncHandler    = require('../utils/asyncHandler');
const ApiError        = require('../utils/ApiError');
const { sanitise, requireFields, isValidEmail } = require('../utils/sanitise');
const firebaseService = require('../services/firebase.service');
const bcrypt          = require('bcryptjs');

// ── Normalise profile for consistent response shape ───────────────
function normaliseProfile(doc) {
  return {
    uid:            doc.uid          || doc.id  || '',
    fullName:       doc.fullName                || '',
    businessName:   doc.businessName            || '',
    email:          doc.email                   || '',
    stage:          doc.stage                   || '',
    salesChannel:   doc.salesChannel            || '',
    revenue:        doc.revenue                 || '',
    headache:       doc.headache                || '',
    matchmaking:    doc.matchmaking             || '',
    onboardingStep: doc.onboardingStep          || 0,
    completed:      doc.completed               || false,
  };
}

// ── POST /api/auth/login ──────────────────────────────────────────
const login = asyncHandler(async (req, res) => {
  const body = sanitise(req.body, ['email', 'password']);
  requireFields(body, ['email', 'password']);

  if (!isValidEmail(body.email)) {
    throw ApiError.badRequest('Invalid email address.');
  }

  // 1. Find user document in Firestore by email
  const profileDoc = await firebaseService.getUserByEmail(body.email);

  if (!profileDoc) {
    throw ApiError.unauthorized('Invalid email or password.');
  }

  // 2. Verify password against stored bcrypt hash
  if (!profileDoc.hashedPassword) {
    console.error(`[Auth] No hashedPassword found for ${body.email}`);
    throw ApiError.unauthorized('Invalid email or password.');
  }

  const passwordMatch = await bcrypt.compare(body.password, profileDoc.hashedPassword);

  if (!passwordMatch) {
    throw ApiError.unauthorized('Invalid email or password.');
  }

  // 3. Return profile — frontend navigates to /your-roadmap
  res.json({
    success: true,
    profile: normaliseProfile(profileDoc),
  });
});

// ── GET /api/auth/me ──────────────────────────────────────────────
// Protected by the auth middleware — requires a valid session.
// Currently used for future token-based session management.
const getMe = asyncHandler(async (req, res) => {
  const profileDoc = await firebaseService.getUserByEmail(req.user.email);

  if (!profileDoc) {
    throw ApiError.notFound('User profile not found.');
  }

  res.json({ success: true, profile: normaliseProfile(profileDoc) });
});

module.exports = { login, getMe };
