/**
 * middleware/auth.js
 *
 * Verifies a Firebase ID token sent in the Authorization header.
 * Attaches the decoded token payload to req.user on success.
 *
 * Usage:
 *   const { protect } = require('../middleware/auth');
 *
 *   // Protect a single route
 *   router.get('/me', protect, asyncHandler(getProfile));
 *
 *   // Protect all routes in a router
 *   router.use(protect);
 *
 * The frontend sends the token like this:
 *   Authorization: Bearer <firebase-id-token>
 *
 * After this middleware runs successfully, req.user contains:
 *   {
 *     uid:   'firebase-uid',
 *     email: 'user@example.com',
 *     // ...other Firebase token claims
 *   }
 *
 * How token verification works:
 *   Firebase Auth issues ID tokens (JWTs) signed with Google's
 *   private key. admin.auth().verifyIdToken() validates the
 *   signature against Google's public keys — no database call
 *   needed. The token itself is cryptographic proof of identity.
 *   Tokens expire after 1 hour; the frontend must refresh them.
 */

'use strict';

const { auth } = require('../config/firebase');
const ApiError  = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');

/**
 * protect — require a valid Firebase ID token.
 * Throws 401 if the token is missing, expired, or invalid.
 */
const protect = asyncHandler(async (req, res, next) => {
  const header = req.headers.authorization;

  if (!header || !header.startsWith('Bearer ')) {
    throw ApiError.unauthorized(
      'No authentication token provided. ' +
      'Include Authorization: Bearer <token> in the request headers.'
    );
  }

  const token = header.split(' ')[1];

  if (!token) {
    throw ApiError.unauthorized('Authentication token is empty.');
  }

  // verifyIdToken throws if the token is invalid or expired.
  // The thrown error has a `code` property (e.g. auth/id-token-expired)
  // which the global errorHandler maps to a clean 401 response.
  const decoded = await auth.verifyIdToken(token);

  // Attach the decoded claims to the request for use in controllers
  req.user = {
    uid:   decoded.uid,
    email: decoded.email,
  };

  next();
});

/**
 * optionalAuth — attaches req.user if a valid token is present,
 * but does NOT block the request if no token is provided.
 *
 * Useful for routes that work for both anonymous and logged-in users
 * (e.g. the AI Advisor — works for everyone, but could personalise
 * responses for logged-in users in the future).
 */
const optionalAuth = asyncHandler(async (req, res, next) => {
  const header = req.headers.authorization;

  if (!header || !header.startsWith('Bearer ')) {
    req.user = null;
    return next();
  }

  const token = header.split(' ')[1];

  try {
    const decoded = await auth.verifyIdToken(token);
    req.user = { uid: decoded.uid, email: decoded.email };
  } catch {
    // Invalid or expired token — treat as anonymous
    req.user = null;
  }

  next();
});

module.exports = { protect, optionalAuth };
