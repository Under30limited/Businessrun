/**
 * routes/advisor.routes.js
 *
 * POST /api/advisor → AI Advisor chat
 *
 * Uses optionalAuth — works for anonymous users but attaches
 * req.user when a valid Firebase ID token is present so that
 * conversation history can be saved for logged-in users.
 */

'use strict';

const express    = require('express');
const router     = express.Router();
const controller = require('../controllers/advisor.controller');
const { optionalAuth }    = require('../middleware/auth');
const { advisorLimiter }  = require('../middleware/rateLimiter');
const validate   = require('../middleware/validate');

const advisorSchema = {
  message: { required: true, type: 'string', min: 1, max: 2000 },
};

router.post('/',
  advisorLimiter,
  optionalAuth,
  validate(advisorSchema),
  controller.chat
);

module.exports = router;
