/**
 * controllers/auth.controller.js
 *
 * Three auth endpoints:
 *
 *   POST /api/auth/login   — verify credentials, issue JWT cookie, return profile
 *   POST /api/auth/logout  — clear the JWT cookie
 *   GET  /api/auth/me      — validate current cookie, return fresh profile
 *
 * COOKIE STRATEGY:
 *   On successful login or signup, the server sets an HTTP-only cookie
 *   named 'br_token' containing a signed JWT. The browser stores and sends
 *   this cookie automatically — JavaScript on the frontend cannot read it.
 *
 *   This means:
 *   - No token stored in localStorage or sessionStorage (no XSS risk)
 *   - No Authorization header to manage on the frontend
 *   - Session persists across tab closes and browser restarts for 7 days
 *   - /api/auth/me lets the frontend check "am I still logged in?" on load
 *
 *   On logout, the server clears the cookie by setting it with maxAge=0.
 *   The client cannot clear an HTTP-only cookie itself — only the server can.
 */

'use strict';

const asyncHandler    = require('../utils/asyncHandler');
const ApiError        = require('../utils/ApiError');
const { sanitise, requireFields, isValidEmail } = require('../utils/sanitise');
const firebaseService = require('../services/db.service');
const bcrypt          = require('bcryptjs');
const { signToken, COOKIE_NAME, COOKIE_OPTIONS, CLEAR_COOKIE_OPTIONS } = require('../utils/jwt');

// ── Normalise profile for consistent response shape ───────────────
// Only safe, non-sensitive fields are returned.
// hashedPassword is never included.
function normaliseProfile(doc) {
  return {
    uid:            doc.uid          || doc.id  || '',
    fullName:       doc.fullName                || '',
    businessName:   doc.businessName            || '',
    email:          doc.email                   || '',
    stage:          doc.stage                   || '',
    salesChannel:   doc.salesChannel            || '',
    revenue:        doc.revenue                 || '',
    headache:       doc.headache                || '',
    matchmaking:    doc.matchmaking             || '',
    onboardingStep: doc.onboardingStep          || 0,
    completed:      doc.completed               || false,
  };
}

// ── POST /api/auth/login ──────────────────────────────────────────
/**
 * 1. Find user in Firestore by email
 * 2. Compare submitted password against stored bcrypt hash
 * 3. Sign a JWT containing the profile
 * 4. Set the JWT in an HTTP-only cookie
 * 5. Return the profile in the response body (so the frontend can
 *    populate the AuthContext immediately without waiting for /me)
 */
const login = asyncHandler(async (req, res) => {
  const body = sanitise(req.body, ['email', 'password']);
  requireFields(body, ['email', 'password']);

  if (!isValidEmail(body.email)) {
    throw ApiError.badRequest('Invalid email address.');
  }

  // 1. Fetch user from Firestore
  const profileDoc = await firebaseService.getUserByEmail(body.email);
  if (!profileDoc) {
    // Use the same message for "not found" and "wrong password" —
    // never reveal which part is wrong (prevents email enumeration)
    throw ApiError.unauthorized('Invalid email or password.');
  }

  // 2. Verify password
  if (!profileDoc.hashedPassword) {
    console.error(`[Auth] No hashedPassword found for ${body.email}`);
    throw ApiError.unauthorized('Invalid email or password.');
  }

  const passwordMatch = await bcrypt.compare(body.password, profileDoc.hashedPassword);
  if (!passwordMatch) {
    throw ApiError.unauthorized('Invalid email or password.');
  }

  // 3. Build the normalised profile
  const profile = normaliseProfile(profileDoc);

  // 4. Sign a JWT and set it as an HTTP-only cookie
  const token = signToken(profile);
  res.cookie(COOKIE_NAME, token, COOKIE_OPTIONS);

  // 5. Return profile in body — frontend stores it in AuthContext (React state only)
  res.json({ success: true, profile });
});

// ── POST /api/auth/logout ─────────────────────────────────────────
/**
 * Clears the session cookie.
 * The client cannot clear an HTTP-only cookie itself — only the server can.
 * This route requires no auth — clearing an already-missing cookie is harmless.
 */
const logout = asyncHandler(async (req, res) => {
  res.clearCookie(COOKIE_NAME, CLEAR_COOKIE_OPTIONS);
  res.json({ success: true, message: 'Logged out successfully.' });
});

// ── GET /api/auth/me ──────────────────────────────────────────────
/**
 * Called by the frontend on every app load (in AuthContext) to check
 * whether the user's cookie is still valid and restore their session.
 *
 * Flow:
 *   - Browser sends cookie automatically
 *   - protect middleware verifies the JWT and sets req.user
 *   - This handler returns the profile from the JWT payload
 *     (no Firestore call needed — the JWT is the source of truth)
 *
 * If the cookie is expired or missing, protect throws 401 and the
 * frontend clears its React state — user must log in again.
 *
 * Optional Firestore refresh:
 *   If you want guaranteed-fresh data (e.g. after an admin changes a
 *   user's profile), uncomment the Firestore lookup below. For now,
 *   the JWT payload is sufficient and avoids a DB call on every load.
 */
const getMe = asyncHandler(async (req, res) => {
  // req.user is populated by the protect middleware from the JWT payload
  // No Firestore call needed — JWT is the source of truth for the session
  const profile = {
    uid:          req.user.uid,
    email:        req.user.email,
    fullName:     req.user.fullName,
    businessName: req.user.businessName,
    stage:        req.user.stage,
    salesChannel: req.user.salesChannel,
    revenue:      req.user.revenue,
    headache:     req.user.headache,
    matchmaking:  req.user.matchmaking,
  };

  res.json({ success: true, profile });
});

// ── POST /api/auth/check-email ───────────────────────────────────
/**
 * Email check used during GYB signup Step 1.
 *
 * Returns three possible states:
 *
 *   completed: true  — email is fully registered → block, prompt to log in
 *   completed: false — email exists but registration was never finished
 *                      → allow silently, user resumes their incomplete signup
 *   exists: false    — email not found at all → allow, fresh signup
 *
 * WHY we check completed:
 *   A user may have started GYB, dropped off at step 2 or 3, and is
 *   now trying again with the same email. We should never block them —
 *   they never actually completed registration. Blocking them would
 *   lock them out of an account they cannot log into yet.
 *
 * Body:    { email }
 * Response: { success: true, exists: boolean, completed: boolean }
 */
const checkEmail = asyncHandler(async (req, res) => {
  const body  = sanitise(req.body, ['email']);
  requireFields(body, ['email']);

  const email = body.email.trim().toLowerCase();
  if (!isValidEmail(email)) throw ApiError.badRequest('Invalid email address.');

  let exists    = false;
  let completed = false;

  try {
    // Query WITHOUT the completed filter so we find ALL users with this
    // email — including those who started but never finished registration
    const { db } = require('../config/firebase');
    const snap = await db
      .collection('users')
      .where('email', '==', email)
      .limit(1)
      .get();

    if (!snap.empty) {
      exists    = true;
      completed = snap.docs[0].data().completed === true;
    }
  } catch {
    // Query failed — allow progression rather than blocking signup
    exists    = false;
    completed = false;
  }

  res.json({ success: true, exists, completed });
});

module.exports = { login, logout, getMe, checkEmail };
