/**
 * config/firebase.js
 *
 * Initialises the Firebase Admin SDK using service account credentials
 * stored in environment variables — no JSON key file on disk in production.
 *
 * Exports:
 *   admin  — the initialised firebase-admin instance
 *   db     — Firestore database reference (use this everywhere)
 *   auth   — Firebase Auth instance (use this for user management)
 *
 * Usage in any file:
 *   const { db, auth } = require('../config/firebase');
 */

'use strict';

const admin = require('firebase-admin');

// ── Guard: only initialise once ───────────────────────────────────
// Firebase Admin throws if you call initializeApp() more than once.
// This guard makes the module safe to require from multiple files.
if (!admin.apps.length) {
  const privateKey = process.env.FIREBASE_PRIVATE_KEY;

  if (!privateKey) {
    throw new Error(
      '[Firebase] FIREBASE_PRIVATE_KEY is not set. ' +
      'Check your .env file.'
    );
  }

  if (!process.env.FIREBASE_PROJECT_ID) {
    throw new Error(
      '[Firebase] FIREBASE_PROJECT_ID is not set. ' +
      'Check your .env file.'
    );
  }

  if (!process.env.FIREBASE_CLIENT_EMAIL) {
    throw new Error(
      '[Firebase] FIREBASE_CLIENT_EMAIL is not set. ' +
      'Check your .env file.'
    );
  }

  admin.initializeApp({
    credential: admin.credential.cert({
      projectId:   process.env.FIREBASE_PROJECT_ID,
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
      // The private key is stored in .env with literal \n characters.
      // Replace them with actual newlines so the PEM is valid.
      privateKey:  privateKey.replace(/\\n/g, '\n'),
    }),
    // Storage bucket — required for Firebase Storage uploads.
    // Set FIREBASE_STORAGE_BUCKET in .env to your bucket name:
    //   e.g. your-project-id.appspot.com
    storageBucket: process.env.FIREBASE_STORAGE_BUCKET,
  });

  console.log(
    `[Firebase] Admin SDK initialised — project: ${process.env.FIREBASE_PROJECT_ID}`
  );
}

const db      = admin.firestore();
const auth    = admin.auth();
const storage = admin.storage();        // Firebase Storage bucket reference

// ── Firestore settings ────────────────────────────────────────────
// ignoreUndefinedProperties: Firestore throws by default if you try
// to write a field with value `undefined`. This setting makes it
// silently ignore those fields instead — much safer with dynamic
// form data where optional fields may be missing.
db.settings({ ignoreUndefinedProperties: true });

module.exports = { admin, db, auth, storage };
