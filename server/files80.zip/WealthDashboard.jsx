/**
 * components/WealthDashboard.jsx
 *
 * Personal Wealth OS dashboard shell — mirrors RoadmapPage.jsx's
 * overall structure (auth guard, tab-based navigation, light theme)
 * but for a personal session (spaceType: 'personal') instead of a
 * business one. No Team or Billing tabs — Personal Wealth OS is
 * single-user and free for now (see the build discussion).
 *
 * Tabs: Overview, Income, Expenses, Assets, Accounts, Debts & Loans,
 * Goals, Day Log, Net Worth, AI Advisor.
 *
 * ── BUILD STATUS ───────────────────────────────────────────────────
 * Overview is fully wired to the real backend (GET /api/personal/
 * networth). The other nine tabs are intentionally placeholders in
 * this pass — full screens (Income, Expenses, Assets, Accounts,
 * Debts, Goals, Day Log, the full Net Worth breakdown, and the AI
 * Advisor chat) are the next build pass, each wired to the endpoints
 * already built in earlier phases.
 */

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  Zap, Wallet, TrendingUp, ShoppingBag, Building2, Landmark,
  HandCoins, Target, NotebookPen, Sparkles, LogOut, Loader2,
} from 'lucide-react';

const TABS = [
  { id: 'overview',  label: 'Overview',      icon: Wallet },
  { id: 'income',    label: 'Income',        icon: TrendingUp },
  { id: 'expenses',  label: 'Expenses',      icon: ShoppingBag },
  { id: 'assets',    label: 'Assets',        icon: Building2 },
  { id: 'accounts',  label: 'Accounts',      icon: Landmark },
  { id: 'debts',     label: 'Debts & Loans', icon: HandCoins },
  { id: 'goals',     label: 'Goals',         icon: Target },
  { id: 'daylog',    label: 'Day Log',       icon: NotebookPen },
  { id: 'networth',  label: 'Net Worth',     icon: TrendingUp },
  { id: 'advisor',   label: 'AI Advisor',    icon: Sparkles },
];

export default function WealthDashboard() {
  const navigate = useNavigate();
  const { user, spaceType, isAuthenticated, isRestoring, logout } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');

  // ── Auth guard ───────────────────────────────────────────────────
  // Same pattern as RoadmapPage.jsx — but ALSO redirects a business
  // session away from here (this dashboard is personal-only), since
  // a business token landing on /wealth would have no personalUid to
  // operate on at all.
  useEffect(() => {
    if (isRestoring) return;
    if (!isAuthenticated || spaceType !== 'personal') {
      navigate('/', { replace: true });
    }
  }, [isRestoring, isAuthenticated, spaceType, navigate]);

  if (isRestoring) {
    return (
      <div className="min-h-screen bg-orange-50 flex flex-col items-center justify-center px-6 text-center">
        <div className="w-16 h-16 bg-amber-50 border border-amber-200 rounded-2xl flex items-center justify-center mb-8 animate-pulse">
          <Zap size={28} className="text-amber-500" />
        </div>
        <p className="text-zinc-500 text-xs font-black uppercase tracking-widest mb-3">Personal Wealth OS</p>
        <p className="text-zinc-900 text-lg font-black mb-6">Restoring your session...</p>
      </div>
    );
  }

  if (!isAuthenticated || spaceType !== 'personal') return null;

  return (
    <div className="min-h-screen bg-orange-50 flex flex-col lg:flex-row">
      {/* ── Sidebar ──────────────────────────────────────────────── */}
      <div className="lg:w-64 bg-white border-b lg:border-b-0 lg:border-r border-zinc-200 flex-shrink-0">
        <div className="p-5 border-b border-zinc-100">
          <p className="text-[9px] font-black uppercase tracking-widest text-amber-500">Personal</p>
          <h1 className="text-zinc-900 font-black text-lg uppercase italic tracking-tight">Wealth OS</h1>
          <p className="text-xs text-zinc-500 mt-1">{user?.nickname || user?.fullName}</p>
        </div>

        <nav className="p-3 flex lg:flex-col gap-1 overflow-x-auto lg:overflow-visible">
          {TABS.map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                  isActive ? 'bg-amber-500/10 text-amber-600' : 'text-zinc-500 hover:bg-zinc-50 hover:text-zinc-900'
                }`}
              >
                <Icon size={16} />
                {tab.label}
              </button>
            );
          })}
        </nav>

        <div className="p-3 border-t border-zinc-100 mt-auto hidden lg:block">
          <button
            onClick={() => logout(navigate)}
            className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-bold text-zinc-500 hover:bg-zinc-50 hover:text-red-600 transition-all"
          >
            <LogOut size={16} />
            Log Out
          </button>
        </div>
      </div>

      {/* ── Main content ─────────────────────────────────────────── */}
      <div className="flex-1 p-5 sm:p-8 overflow-y-auto">
        {activeTab === 'overview' && <OverviewTab />}
        {activeTab !== 'overview' && <ComingSoonTab tab={TABS.find(t => t.id === activeTab)} />}
      </div>
    </div>
  );
}

// ── Overview — real, wired to GET /api/personal/networth ────────────
function OverviewTab() {
  const [data, setData]       = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState('');

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res  = await fetch('/api/personal/networth?currency=NGN', { credentials: 'include' });
        const json = await res.json();
        if (!cancelled) {
          if (json.success) setData(json);
          else setError('Could not load your net worth right now.');
        }
      } catch {
        if (!cancelled) setError('Network error loading your net worth.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  if (loading) {
    return (
      <div className="flex items-center gap-2 text-zinc-400 text-sm">
        <Loader2 size={16} className="animate-spin" /> Loading your numbers...
      </div>
    );
  }

  if (error) {
    return <p className="text-sm text-red-600">{error}</p>;
  }

  const fmt = (n) => `₦${Math.round(n || 0).toLocaleString()}`;

  return (
    <div>
      <p className="text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-1">Net Worth</p>
      <h2 className="text-3xl sm:text-4xl font-black text-zinc-900 mb-8">{fmt(data.netWorth)}</h2>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <MetricCard label="Liquid Cash"   value={fmt(data.liquidCash)} />
        <MetricCard label="Asset Value"   value={fmt(data.totalAssetsValue)} />
        <MetricCard label="Owed To You"   value={fmt(data.owedToMe)} />
        <MetricCard label="You Owe"       value={fmt(data.owedByMe)} />
      </div>

      {data.unpricedAssetCount > 0 && (
        <p className="text-xs text-amber-600 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 mt-6 inline-block">
          {data.unpricedAssetCount} market-tracked asset{data.unpricedAssetCount === 1 ? '' : 's'} not counted yet — price unavailable right now.
        </p>
      )}

      {data.emergencyRunwayMonths !== null && (
        <p className="text-sm text-zinc-500 mt-6">
          At your current essential spending, your liquid cash covers about{' '}
          <span className="font-black text-zinc-900">{data.emergencyRunwayMonths} month{data.emergencyRunwayMonths === 1 ? '' : 's'}</span>.
        </p>
      )}
    </div>
  );
}

function MetricCard({ label, value }) {
  return (
    <div className="bg-white border border-zinc-200 rounded-2xl p-4">
      <p className="text-[9px] font-black uppercase tracking-widest text-zinc-400 mb-1">{label}</p>
      <p className="text-lg font-black text-zinc-900">{value}</p>
    </div>
  );
}

// ── Placeholder for every tab not yet built out ──────────────────────
function ComingSoonTab({ tab }) {
  const Icon = tab?.icon || Wallet;
  return (
    <div className="flex flex-col items-center justify-center text-center py-24">
      <div className="w-14 h-14 bg-amber-50 border border-amber-200 rounded-2xl flex items-center justify-center mb-5">
        <Icon size={22} className="text-amber-500" />
      </div>
      <p className="text-zinc-900 font-black text-lg mb-1">{tab?.label}</p>
      <p className="text-zinc-500 text-sm max-w-xs">
        This screen is coming in the next build pass — the backend for it is already live.
      </p>
    </div>
  );
}
