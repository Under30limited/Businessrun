/**
 * utils/jwt.js
 *
 * Sign and verify JSON Web Tokens for BusinessRun session management.
 *
 * WHY JWT (not just cookies with profile data):
 *   A cookie holding raw profile JSON could be tampered with by anyone
 *   who edits their browser storage — they could set businessName to
 *   anything, or worse, forge a uid. A JWT is cryptographically signed
 *   with a secret only the server knows. If anyone tampers with the
 *   payload, the signature no longer matches and the server rejects it.
 *
 * ── MULTI-TENANT IDENTITY MODEL ────────────────────────────────────
 * One person (one login identity) can belong to more than one business
 * — they might own their own business AND be an invited team member on
 * someone else's. So a session token has to carry TWO different ids:
 *
 *   identityUid — who is actually logged in (their own account, fixed
 *                 no matter which business they're currently viewing).
 *   businessUid — which business's data this session is scoped to
 *                 right now. This is what gets put in `uid` in the
 *                 payload, because every existing controller scopes
 *                 its DynamoDB queries by `req.user.uid` — keeping
 *                 that name means zero changes to any of those
 *                 controllers, whether uid happens to equal
 *                 identityUid (the common case: someone with exactly
 *                 one business) or not (a team member operating on an
 *                 owner's business, or someone who owns multiple
 *                 businesses and is currently viewing a non-default one).
 *
 * For a person with exactly one business, identityUid === businessUid
 * === uid, so nothing about existing behavior changes.
 *
 * WHAT IS STORED IN THE TOKEN:
 *   uid          — CURRENT business/data scope (see above)
 *   identityUid  — the real logged-in identity
 *   businessUid  — explicit alias of uid, for team/business-switch code
 *   role         — 'owner' | 'member', for THIS business
 *   permissions  — feature keys for THIS business if role is 'member',
 *                  else null (owner = unrestricted)
 *   email, fullName, businessName, stage, salesChannel, revenue,
 *   headache, matchmaking — profile fields for RoadmapPage to render
 *   immediately without a DB round-trip
 *
 *   No password, no sensitive data, no payment info.
 *
 * TOKEN LIFETIME:
 *   ACCESS TOKEN    — 7 days (JWT_EXPIRES_IN env var, default '7d').
 *     Stored in an HTTP-only, Secure, SameSite cookie.
 *   PRE-AUTH TOKEN  — 5 minutes. Issued by POST /api/auth/login instead
 *     of a session cookie when an identity has MORE THAN ONE active
 *     business membership — the client must call
 *     POST /api/auth/select-business with this token plus the chosen
 *     businessUid to get the real session cookie. It is NOT set as a
 *     cookie — returned in the JSON body only, and carries no business
 *     data at all (just identityUid + a purpose flag), so it can't be
 *     used to access anything by itself.
 *
 * ENVIRONMENT VARIABLES REQUIRED:
 *   JWT_SECRET      — long random string (min 32 chars). Generate with:
 *                     node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
 *   JWT_EXPIRES_IN  — optional, defaults to '7d'
 *
 * USAGE:
 *   const { signToken, verifyToken, signPreAuthToken, verifyPreAuthToken } = require('../utils/jwt');
 *   const token = signToken(profile);                // sign a full session
 *   const payload = verifyToken(token);               // verify → payload or throws
 *   const preAuth = signPreAuthToken(identityUid);     // multi-business login step 1
 *   const { identityUid } = verifyPreAuthToken(preAuth); // multi-business login step 2
 */

'use strict';

const jwt      = require('jsonwebtoken');
const ApiError = require('./ApiError');

// ── Guard: fail loudly at startup if secret is missing ────────────
function getSecret() {
  const secret = process.env.JWT_SECRET;
  if (!secret || secret.length < 32) {
    throw new Error(
      '[JWT] JWT_SECRET is not set or is too short (need ≥ 32 chars). ' +
      'Generate one with: node -e "console.log(require(\'crypto\').randomBytes(64).toString(\'hex\'))"'
    );
  }
  return secret;
}

// ── Cookie configuration ──────────────────────────────────────────
const COOKIE_NAME = 'br_token';

const COOKIE_OPTIONS = {
  httpOnly:  true,
  secure:    process.env.NODE_ENV === 'production',
  sameSite:  'lax',
  maxAge:    7 * 24 * 60 * 60 * 1000, // 7 days
  path:      '/',
};

const CLEAR_COOKIE_OPTIONS = {
  ...COOKIE_OPTIONS,
  maxAge:  0,
  expires: new Date(0),
};

// ── signToken ─────────────────────────────────────────────────────
/**
 * Signs a full session JWT.
 * Called on login (single-business case), POST /api/auth/select-business,
 * POST /api/auth/switch-business, GYB signup (step 4), and accept-invite.
 *
 * @param {Object} profile
 * @param {string} profile.identityUid   the real logged-in identity
 * @param {string} profile.businessUid   which business this session is scoped to
 * @param {string} [profile.role]        'owner' | 'member' — defaults 'owner'
 * @param {string[]|null} [profile.permissions]  feature keys, null = all (owner)
 * @returns {string}
 */
function signToken(profile) {
  const secret = getSecret();

  const identityUid = profile.identityUid || profile.uid || '';
  const businessUid = profile.businessUid || profile.uid || '';
  const role        = profile.role        || 'owner';

  const payload = {
    uid:          businessUid,           // current business/data scope
    identityUid,
    businessUid,
    role,
    permissions:  profile.permissions ?? null,
    email:        profile.email        || '',
    fullName:     profile.fullName     || '',
    businessName: profile.businessName || '',
    stage:        profile.stage        || '',
    salesChannel: profile.salesChannel || '',
    revenue:      profile.revenue      || '',
    headache:     profile.headache     || '',
    matchmaking:  profile.matchmaking  || '',
  };

  return jwt.sign(payload, secret, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
    algorithm: 'HS256',
  });
}

// ── verifyToken ───────────────────────────────────────────────────
/**
 * Verifies a full session JWT and returns its payload.
 * Throws ApiError 401 if missing, malformed, expired, or tampered with.
 *
 * @param {string} token
 * @returns {Object} Decoded payload { uid, identityUid, businessUid, role, permissions, ... }
 */
function verifyToken(token) {
  try {
    return jwt.verify(token, getSecret(), { algorithms: ['HS256'] });
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      throw ApiError.unauthorized('Your session has expired. Please log in again.');
    }
    throw ApiError.unauthorized('Invalid session token. Please log in again.');
  }
}

// ── signPreAuthToken / verifyPreAuthToken ─────────────────────────
/**
 * Short-lived (5 min) token used ONLY for the multi-business login
 * handshake. Carries nothing but identityUid and a purpose marker —
 * it cannot be used as a session token (verifyToken's callers all
 * expect businessUid/role/permissions, which this deliberately omits).
 *
 * @param {string} identityUid
 * @returns {string}
 */
function signPreAuthToken(identityUid) {
  const secret = getSecret();
  return jwt.sign(
    { identityUid, purpose: 'select-business' },
    secret,
    { expiresIn: '5m', algorithm: 'HS256' }
  );
}

/**
 * @param {string} token
 * @returns {{ identityUid: string }}
 * @throws {ApiError} 401 if invalid/expired/wrong purpose
 */
function verifyPreAuthToken(token) {
  let payload;
  try {
    payload = jwt.verify(token, getSecret(), { algorithms: ['HS256'] });
  } catch {
    throw ApiError.unauthorized('This login attempt has expired. Please log in again.');
  }
  if (payload.purpose !== 'select-business' || !payload.identityUid) {
    throw ApiError.unauthorized('Invalid login token.');
  }
  return { identityUid: payload.identityUid };
}

module.exports = {
  COOKIE_NAME,
  COOKIE_OPTIONS,
  CLEAR_COOKIE_OPTIONS,
  signToken,
  verifyToken,
  signPreAuthToken,
  verifyPreAuthToken,
};
