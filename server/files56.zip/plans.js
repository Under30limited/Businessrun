/**
 * config/plans.js
 *
 * BusinessRun subscription tiers — defined as code, not stored
 * per-business in the database. br-subscriptions only ever stores
 * WHICH plan a business is on (planId); everything about what that
 * plan actually includes is looked up from here. This means changing
 * what a tier includes later is a one-line edit in this file, not a
 * migration across every existing subscriber.
 *
 * FEATURE KEYS must match the existing FEATURE_KEYS used by the team
 * permission system (middleware/permissions.js, team.controller.js) —
 * 'inventory' | 'sales' | 'daylog' | 'reports' | 'cfo' | 'advisor'.
 *
 * ── WHAT'S GATED HOW ────────────────────────────────────────────────
 * - `features`: a hard on/off gate, enforced by middleware/plan.js's
 *   requirePlan(featureKey) — same shape as requireFeature, but checks
 *   the BUSINESS's plan instead of a member's granted permissions.
 *   'sales' and 'daylog' are included on every tier (including Zero) —
 *   the pricing doc never restricts these, they're core day-to-day
 *   tools, not a tier differentiator.
 *   'advisor' is intentionally NOT gated here — it's always
 *   accessible at every tier; what varies is USAGE (see `limits`
 *   below), not access. Trying to add 'advisor' to a lower tier's
 *   `features` list would be a no-op since nothing checks it there.
 *
 * - `limits`: usage caps, enforced at the point of the specific
 *   action (inventory item creation, advisor question count, team
 *   invite) rather than as a route-level gate. `null` means
 *   unlimited.
 *
 * ── NGN PRICING ─────────────────────────────────────────────────────
 * priceNGN is intentionally NOT a fixed number here — the naira
 * amount shown to a customer is computed at request time from
 * priceUSD via services/fx.service.js (cached, refreshed once daily).
 * Hardcoding a naira figure would drift from the real exchange rate
 * and need a manual edit every time the market moves.
 */

'use strict';

const PLANS = {
  zero: {
    id:       'zero',
    name:     'BusinessRun Zero',
    tagline:  'Free',
    priceUSD: 0,
    features: ['sales', 'daylog', 'inventory'],
    limits: {
      teamMembers:            1,     // admin (owner) only — no team invites at all
      inventoryItems:         25,
      advisorQuestionsPerDay: 5,
      advisorMemoryDays:      0,     // resets when the browser session ends
      languages:              ['English'],
    },
  },

  plus1: {
    id:       'plus1',
    name:     'BusinessRun +1',
    tagline:  'For a small team getting organised',
    priceUSD: 6.50,
    features: ['sales', 'daylog', 'inventory', 'reports', 'cfo'],
    limits: {
      teamMembers:            2,
      inventoryItems:         100,
      advisorQuestionsPerDay: 20,
      advisorMemoryDays:      30,
      languages:              ['English', 'Pidgin', 'Yoruba', 'Igbo', 'Hausa'],
    },
  },

  plus2: {
    id:       'plus2',
    name:     'BusinessRun +2',
    tagline:  'Custom reporting and team roles',
    priceUSD: 16.50,
    features: ['sales', 'daylog', 'inventory', 'reports', 'cfo'],
    limits: {
      teamMembers:            3,
      inventoryItems:         200,
      advisorQuestionsPerDay: null,  // unlimited
      advisorMemoryDays:      null,  // continuous
      languages:              ['English', 'Pidgin', 'Yoruba', 'Igbo', 'Hausa', 'French'],
    },
  },

  plus3: {
    id:       'plus3',
    name:     'BusinessRun +3',
    tagline:  'Everything, for a growing team',
    priceUSD: 26.50,
    features: ['sales', 'daylog', 'inventory', 'reports', 'cfo'],
    limits: {
      teamMembers:            5,
      inventoryItems:         null,  // unlimited
      advisorQuestionsPerDay: null,
      advisorMemoryDays:      null,
      languages:              ['English', 'Pidgin', 'Yoruba', 'Igbo', 'Hausa', 'French'],
    },
  },
};

// Every new business (and every already-live one, per the migration)
// starts here. One rule, no special-casing.
const TRIAL_PLAN_ID     = 'plus1';
const TRIAL_DURATION_MS = 30 * 24 * 60 * 60 * 1000; // 30 days
const FALLBACK_PLAN_ID  = 'zero'; // where a lapsed trial/subscription lands

// Ordered low → high, for "does plan X include at least tier Y" checks
// and for rendering an upgrade path in the UI.
const PLAN_ORDER = ['zero', 'plus1', 'plus2', 'plus3'];

function getPlan(planId) {
  return PLANS[planId] || PLANS[FALLBACK_PLAN_ID];
}

module.exports = { PLANS, PLAN_ORDER, TRIAL_PLAN_ID, TRIAL_DURATION_MS, FALLBACK_PLAN_ID, getPlan };
