/**
 * migrate-subscriptions.js
 *
 * One-time backfill: every business that existed before the
 * subscription system shipped gets a br-subscriptions row, starting
 * a fresh 30-day BusinessRun+1 trial from the moment this script
 * runs — the exact same treatment a brand-new signup gets.
 *
 * This is STEP 1 of the subscription rollout and is completely safe
 * to run against production right now: it only WRITES new rows to a
 * brand-new table (br-subscriptions) that nothing in the live app
 * reads from yet. No existing behavior changes until the enforcement
 * middleware (middleware/plan.js) is deployed in a LATER step — do
 * not deploy that until this script has been run and verified.
 *
 * Idempotent — skips any business that already has a subscription
 * row, so it's safe to run more than once (e.g. if new businesses
 * signed up between runs, a second run picks up just those).
 *
 * Run:
 *   node migrate-subscriptions.js 2>&1 | tee subscription-migration.log
 */

'use strict';

require('dotenv').config();

const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const {
  DynamoDBDocumentClient,
  ScanCommand,
  GetCommand,
} = require('@aws-sdk/lib-dynamodb');

const { TRIAL_PLAN_ID, TRIAL_DURATION_MS } = require('./config/plans');
const db = require('./services/db.service'); // reuses createSubscription so migration and app logic never drift apart

const dynamo = DynamoDBDocumentClient.from(
  new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-1' }),
  { marshallOptions: { removeUndefinedValues: true } }
);

const BUSINESSES_TABLE    = 'br-businesses';
const SUBSCRIPTIONS_TABLE = 'br-subscriptions';

async function scanAll(tableName) {
  const items = [];
  let ExclusiveStartKey;
  do {
    const result = await dynamo.send(new ScanCommand({ TableName: tableName, ExclusiveStartKey }));
    items.push(...(result.Items || []));
    ExclusiveStartKey = result.LastEvaluatedKey;
  } while (ExclusiveStartKey);
  return items;
}

async function hasSubscription(businessUid) {
  const result = await dynamo.send(new GetCommand({
    TableName: SUBSCRIPTIONS_TABLE,
    Key:       { businessUid },
  }));
  return Boolean(result.Item);
}

async function run() {
  console.log('Subscription migration — backfilling every existing business onto a fresh trial');
  console.log('================================================================================');

  const businesses = await scanAll(BUSINESSES_TABLE);
  console.log(`Found ${businesses.length} businesses.\n`);

  const trialEndsAt = new Date(Date.now() + TRIAL_DURATION_MS).toISOString();
  console.log(`Trial plan: ${TRIAL_PLAN_ID}`);
  console.log(`Trial ends: ${trialEndsAt} (30 days from now, for every business — new and existing alike)\n`);

  let created = 0;
  let skipped = 0;

  for (const business of businesses) {
    const { businessUid, businessName } = business;

    if (!businessUid) {
      console.warn(`  ? Skipping a row with no businessUid:`, business);
      continue;
    }

    if (await hasSubscription(businessUid)) {
      skipped++;
      continue;
    }

    await db.createSubscription(businessUid, { trialEndsAt });
    created++;
    console.log(`  ✓ ${businessUid} (${businessName || 'unnamed'}) → trialing ${TRIAL_PLAN_ID} until ${trialEndsAt}`);
  }

  console.log('\n================================================================================');
  console.log(`Created:  ${created}`);
  console.log(`Skipped (already had a subscription row): ${skipped}`);
  console.log('\nVerify the count in br-subscriptions matches br-businesses before deploying middleware/plan.js.');
}

run().catch(err => {
  console.error('\nMigration FAILED:', err);
  process.exit(1);
});
