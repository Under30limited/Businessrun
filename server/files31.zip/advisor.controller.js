/**
 * controllers/advisor.controller.js
 *
 * Handles the Strategic AI Advisor chat.
 * Proxies the request to Gemini via gemini.service.
 *
 * The advisor acts as the business's in-house financial officer:
 * it receives the user's selected language, business profile, and
 * a snapshot of their CFO/Inventory/Sales data so its replies are
 * grounded in the founder's actual numbers.
 *
 * Optionally saves conversation history to Firestore for logged-in users.
 *
 * Route:
 *   POST /api/advisor
 */

'use strict';

const asyncHandler    = require('../utils/asyncHandler');
const ApiError        = require('../utils/ApiError');
const { sanitise, requireFields } = require('../utils/sanitise');
const geminiService   = require('../services/gemini.service');
const firebaseService = require('../services/firebase.service');

// ── POST /api/advisor ─────────────────────────────────────────────
const chat = asyncHandler(async (req, res) => {
  const body = sanitise(req.body, [
    'message', 'history', 'sessionId',
    'language', 'profile', 'cfoEntries', 'inventory', 'sales',
  ]);
  requireFields(body, ['message']);

  if (typeof body.message !== 'string' || !body.message.trim()) {
    throw ApiError.badRequest('Message cannot be empty.');
  }

  // Validate history array if provided
  const history = Array.isArray(body.history) ? body.history : [];

  // Enforce reasonable limits to prevent abuse
  if (body.message.length > 2000) {
    throw ApiError.badRequest('Message is too long. Maximum 2000 characters.');
  }
  if (history.length > 40) {
    // Only keep the last 40 messages to avoid sending huge payloads to Gemini
    body.history = history.slice(-40);
  }

  // ── Language ───────────────────────────────────────────────────
  const VALID_LANGUAGES = ['English', 'Yoruba', 'Hausa', 'Igbo', 'Pidgin', 'French', 'Arabic'];
  const language = VALID_LANGUAGES.includes(body.language) ? body.language : 'English';

  // ── Business profile (optional — keeps replies personal) ────────
  const profile = (body.profile && typeof body.profile === 'object') ? body.profile : {};

  // ── Business data context ────────────────────────────────────────
  // If the client already sent CFO/inventory/sales data (e.g. the
  // dashboard already has it loaded), use that directly to avoid an
  // extra round trip. Otherwise, for logged-in users, fetch it
  // server-side so the advisor still has full context.
  let cfoEntries = (body.cfoEntries && typeof body.cfoEntries === 'object') ? body.cfoEntries : null;
  let inventory  = Array.isArray(body.inventory) ? body.inventory : null;
  let sales      = Array.isArray(body.sales)     ? body.sales     : null;

  if (req.user && (cfoEntries === null || inventory === null || sales === null)) {
    try {
      const uid = req.user.uid;
      const [cfoData, invData, salesData] = await Promise.all([
        cfoEntries === null ? firebaseService.getAllCFOEntries(uid) : Promise.resolve(cfoEntries),
        inventory  === null ? firebaseService.getInventoryItems(uid) : Promise.resolve(inventory),
        sales      === null ? firebaseService.getSales(uid)          : Promise.resolve(sales),
      ]);
      cfoEntries = cfoData;
      inventory  = invData;
      sales      = salesData;
    } catch (err) {
      // Non-fatal — advisor can still respond without business data
      console.error('[Advisor] Failed to load business data context:', err.message);
      cfoEntries = cfoEntries || {};
      inventory  = inventory  || [];
      sales      = sales      || [];
    }
  } else {
    cfoEntries = cfoEntries || {};
    inventory  = inventory  || [];
    sales      = sales      || [];
  }

  let result;
  try {
    result = await geminiService.getAdvisorReply(body.message.trim(), history, {
      language,
      profile,
      cfoEntries,
      inventory,
      sales,
    });
  } catch (err) {
    // AI unavailable — return advisorDown flag so the frontend
    // shows the friendly "unavailable" card rather than an error
    if (err.statusCode === 503) {
      return res.json({ text: null, advisorDown: true });
    }
    throw err;
  }

  // Optionally persist the conversation for logged-in users
  // req.user is set by the optionalAuth middleware on this route
  if (req.user && body.sessionId) {
    const updatedMessages = [
      ...history,
      { role: 'user',      content: body.message.trim() },
      { role: 'assistant', content: result.text          },
    ];

    // Fire and forget — don't await so it doesn't slow down the response
    firebaseService
      .upsertAdvisorSession(body.sessionId, req.user.uid, updatedMessages)
      .catch((err) =>
        console.error('[Advisor] Failed to save session:', err.message)
      );
  }

  res.json({ text: result.text });
});

module.exports = { chat };
