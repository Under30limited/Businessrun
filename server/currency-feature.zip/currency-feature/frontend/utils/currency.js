/**
 * utils/currency.js
 *
 * Client-side currency formatting + conversion for Personal Wealth
 * OS — lets the dashboard convert and re-render every already-loaded
 * amount instantly when the person switches their display currency,
 * with no extra round trip for screens that don't need server-side
 * aggregation (Accounts, Income, Expenses, Assets, Goals, Debts all
 * just re-render client-side; only Net Worth/Cash Flow — which
 * aggregate server-side anyway — re-fetch with ?currency=).
 *
 * ── KEEP THIS IN SYNC WITH THE BACKEND ──────────────────────────────
 * This is a deliberate, direct port of config/currencies.js. If a
 * currency or rate is added/changed on one side, it MUST be changed
 * here too — otherwise a screen showing client-converted totals and
 * the Net Worth tab's server-converted totals will quietly disagree.
 */

export const CURRENCIES = [
  'USD', 'NGN', 'KES', 'GHS', 'ZAR', 'GBP', 'CAD', 'EUR', 'AED', 'RWF', 'UGX', 'AUD', 'INR',
];

export const FX_RATES_TO_USD = {
  USD: 1.0,
  NGN: 1500,
  KES: 130,
  GHS: 15.5,
  ZAR: 18.2,
  GBP: 0.78,
  CAD: 1.38,
  EUR: 0.92,
  AED: 3.67,
  RWF: 1350,
  UGX: 3700,
  AUD: 1.52,
  INR: 83.5,
};

export const CURRENCY_SYMBOLS = {
  USD: '$',
  NGN: '₦',
  KES: 'KSh',
  GHS: 'GH₵',
  ZAR: 'R',
  GBP: '£',
  CAD: 'CA$',
  EUR: '€',
  AED: 'AED',
  RWF: 'RWF',
  UGX: 'UGX',
  AUD: 'A$',
  INR: '₹',
};

// Human-readable labels for the currency picker (signup Step 1 and
// the dashboard's currency switcher) — code + name reads better than
// a bare 3-letter code in a dropdown.
export const CURRENCY_LABELS = {
  USD: 'US Dollar',
  NGN: 'Nigerian Naira',
  KES: 'Kenyan Shilling',
  GHS: 'Ghanaian Cedi',
  ZAR: 'South African Rand',
  GBP: 'British Pound',
  CAD: 'Canadian Dollar',
  EUR: 'Euro',
  AED: 'UAE Dirham',
  RWF: 'Rwandan Franc',
  UGX: 'Ugandan Shilling',
  AUD: 'Australian Dollar',
  INR: 'Indian Rupee',
};

export function getCurrencySymbol(currency) {
  if (!currency) return '₦';
  const code = currency.toUpperCase();
  return CURRENCY_SYMBOLS[code] || code;
}

export function formatCurrency(amount, currency, customSymbol) {
  const isNullOrNan = amount === null || amount === undefined || Number.isNaN(amount);
  const val = isNullOrNan ? 0 : amount;
  const symbol = customSymbol || getCurrencySymbol(currency);
  const code = (currency || 'NGN').toUpperCase();
  const noDecimalCurrencies = ['NGN', 'KES', 'RWF', 'UGX', 'INR'];
  const isNoDecimal = noDecimalCurrencies.includes(code);
  const maxFractionDigits = isNoDecimal ? 0 : 2;
  const minFractionDigits = isNoDecimal ? 0 : Number.isInteger(val) ? 0 : 2;
  const formatted = val.toLocaleString('en-US', {
    minimumFractionDigits: minFractionDigits,
    maximumFractionDigits: maxFractionDigits,
  });
  const needsSpace = symbol.length > 2 || symbol === 'KSh' || symbol === 'GH₵' || symbol === 'CA$' || symbol === 'A$';
  return `${symbol}${needsSpace ? ' ' : ''}${formatted}`;
}

export function convertAmount(amount, from, to) {
  if (!from || !to || from === to) return amount;
  const fromCode = from.toUpperCase();
  const toCode = to.toUpperCase();
  if (fromCode === toCode) return amount;
  const fromRate = FX_RATES_TO_USD[fromCode] || 1.0;
  const toRate = FX_RATES_TO_USD[toCode] || 1.0;
  // Amount in USD = amount / fromRate
  // Amount in target = inUSD * toRate
  const inUSD = amount / fromRate;
  return inUSD * toRate;
}

export function formatUnifiedAmount(amount, streamCurrency, targetDisplayCurrency, customSymbol) {
  if (streamCurrency === targetDisplayCurrency) {
    return formatCurrency(amount, targetDisplayCurrency, customSymbol);
  }
  const converted = convertAmount(amount, streamCurrency, targetDisplayCurrency);
  return formatCurrency(converted, targetDisplayCurrency, customSymbol);
}

export function formatCompactCurrency(amount, currency, customSymbol) {
  const isNullOrNan = amount === null || amount === undefined || Number.isNaN(amount);
  const val = isNullOrNan ? 0 : amount;
  const symbol = customSymbol || getCurrencySymbol(currency);
  const abs = Math.abs(val);
  const needsSpace = symbol.length > 2 || symbol === 'KSh' || symbol === 'GH₵' || symbol === 'CA$' || symbol === 'A$';
  const prefix = `${symbol}${needsSpace ? ' ' : ''}`;
  if (abs >= 1_000_000_000) {
    return `${prefix}${(val / 1_000_000_000).toFixed(1).replace(/\.0$/, '')}B`;
  }
  if (abs >= 1_000_000) {
    return `${prefix}${(val / 1_000_000).toFixed(1).replace(/\.0$/, '')}M`;
  }
  if (abs >= 1_000) {
    return `${prefix}${(val / 1_000).toFixed(1).replace(/\.0$/, '')}K`;
  }
  return formatCurrency(val, currency, customSymbol);
}

export const formatMoney = formatCurrency;
