/**
 * controllers/sales.controller.js
 *
 * Sales Day Book — record sales, auto-deduct inventory, fetch history.
 *
 * All routes protected — valid JWT cookie required.
 *
 * Routes:
 *   GET  /api/sales          — fetch all sales (optional ?from=&to= date filter)
 *   POST /api/sales          — record a sale + deduct inventory stock server-side
 *
 * WHY stock deduction happens here (not in inventory controller):
 *   A sale and its stock deduction are one atomic business event.
 *   Handling both in one endpoint means if the stock update fails,
 *   the sale record is not written either — no orphaned data.
 *   The inventory PATCH endpoint is reused internally (same logic,
 *   no duplicate code) by calling firebaseService.updateInventoryItem.
 */

'use strict';

const asyncHandler    = require('../utils/asyncHandler');
const ApiError        = require('../utils/ApiError');
const { sanitise, requireFields } = require('../utils/sanitise');
const firebaseService = require('../services/firebase.service');

// ── GET /api/sales ────────────────────────────────────────────────
/**
 * Returns all sales for the logged-in user, newest first.
 * Optional query params:
 *   ?from=2024-01-01   ISO date string — start of range
 *   ?to=2024-01-31     ISO date string — end of range
 *
 * Response: { success: true, sales: [...] }
 */
const getSales = asyncHandler(async (req, res) => {
  const uid = req.user.uid;

  let fromDate, toDate;
  if (req.query.from) {
    fromDate = new Date(req.query.from);
    if (isNaN(fromDate)) throw ApiError.badRequest('Invalid "from" date format. Use ISO format: YYYY-MM-DD.');
    fromDate.setHours(0, 0, 0, 0);
  }
  if (req.query.to) {
    toDate = new Date(req.query.to);
    if (isNaN(toDate)) throw ApiError.badRequest('Invalid "to" date format. Use ISO format: YYYY-MM-DD.');
    toDate.setHours(23, 59, 59, 999);
  }

  const sales = await firebaseService.getSales(uid, fromDate, toDate);
  res.json({ success: true, sales });
});

// ── POST /api/sales ───────────────────────────────────────────────
/**
 * Records a sale and atomically deducts stock from the inventory item.
 *
 * Flow:
 *   1. Validate request body
 *   2. Fetch the inventory item to verify it exists and has enough stock
 *   3. Write the sale record to Firestore
 *   4. Deduct the quantity from inventory via updateInventoryItem
 *      (same service function used by PATCH /api/inventory/:id)
 *   5. Return the saved sale + updated inventory quantity
 *
 * Body:
 *   { inventoryItemId, itemName, unitPrice, salePrice, quantity }
 *
 * Response:
 *   { success: true, sale: {...}, updatedQuantity: number }
 */
const logSale = asyncHandler(async (req, res) => {
  const uid  = req.user.uid;
  const body = sanitise(req.body, [
    'inventoryItemId', 'itemName', 'unitPrice', 'salePrice', 'quantity',
  ]);
  requireFields(body, ['inventoryItemId', 'itemName', 'unitPrice', 'salePrice', 'quantity']);

  const quantity   = parseInt(body.quantity, 10);
  const salePrice  = parseFloat(body.salePrice);
  const unitPrice  = parseFloat(body.unitPrice);

  if (isNaN(quantity)  || quantity  <= 0) throw ApiError.badRequest('Quantity must be a positive integer.');
  if (isNaN(salePrice) || salePrice <  0) throw ApiError.badRequest('Sale price must be a positive number.');
  if (isNaN(unitPrice) || unitPrice <  0) throw ApiError.badRequest('Unit price must be a positive number.');

  // ── Step 2: Fetch inventory item — server-side stock validation ──
  // We never trust client-reported stock levels. The item is fetched
  // fresh from Firestore so the check reflects the actual current quantity.
  const items = await firebaseService.getInventoryItems(uid);
  const item  = items.find(i => i.id === body.inventoryItemId);

  if (!item) {
    throw ApiError.badRequest('Inventory item not found. It may have been deleted.');
  }

  if (item.quantity < quantity) {
    throw ApiError.badRequest(
      `Insufficient stock. You have ${item.quantity} unit${item.quantity === 1 ? '' : 's'} available, ` +
      `but tried to sell ${quantity}.`
    );
  }

  const totalAmount = parseFloat((salePrice * quantity).toFixed(2));

  // ── Step 3: Write sale record ─────────────────────────────────────
  const sale = await firebaseService.recordSale(uid, {
    inventoryItemId: body.inventoryItemId,
    itemName:        body.itemName,
    unitPrice,
    salePrice,
    quantity,
    totalAmount,
  });

  // ── Step 4: Deduct stock ──────────────────────────────────────────
  // Use the same firebaseService.updateInventoryItem that PATCH /api/inventory
  // uses — one code path for inventory updates, no divergence.
  const newQuantity = item.quantity - quantity;
  await firebaseService.updateInventoryItem(uid, body.inventoryItemId, {
    quantity: newQuantity,
  });

  // ── Step 5: Return sale + updated quantity ────────────────────────
  res.status(201).json({
    success:         true,
    sale,
    updatedQuantity: newQuantity,
  });
});

module.exports = { getSales, logSale };
