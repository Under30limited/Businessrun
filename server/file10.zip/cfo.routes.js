/**
 * routes/cfo.routes.js
 *
 * All Digital CFO routes are protected — valid JWT cookie required.
 *
 *   GET    /api/cfo/entries         → load all tool entries for the user
 *   POST   /api/cfo/entries         → save a new entry
 *   DELETE /api/cfo/entries/:id     → delete an entry (toolName in query)
 *   POST   /api/cfo/insight         → generate AI insight from entries
 */

'use strict';

const express        = require('express');
const router         = express.Router();
const controller     = require('../controllers/cfo.controller');
const { protect }    = require('../middleware/auth');
const { accountingLimiter, advisorLimiter } = require('../middleware/rateLimiter');

// All CFO routes require a valid session
router.use(protect);

// Entry management
router.get('/entries',         accountingLimiter, controller.getAllEntries);
router.post('/entries',        accountingLimiter, controller.saveEntry);
router.delete('/entries/:id',  accountingLimiter, controller.deleteEntry);

// AI insight generation (uses Gemini — stricter rate limit)
router.post('/insight',        advisorLimiter,    controller.getCFOInsight);

module.exports = router;
