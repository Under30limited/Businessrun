/**
 * scripts/setup-contact-table.js
 *
 * Creates the br-contactSubmissions DynamoDB table used by the
 * contact/feedback feature (services/contact.service.js). Doesn't
 * touch any other table.
 *
 * SAFE TO RE-RUN: checks the table's existence first and skips
 * creation if it's already there; if it exists but is missing the
 * status-index GSI (e.g. this script gains a second GSI down the
 * line), it adds just that — same partial-success-tolerant pattern
 * as scripts/setup-personal-tables.js and scripts/setup-paystack-
 * plans.js.
 *
 * Billing mode: PAY_PER_REQUEST — a feedback form has unpredictable,
 * low-and-bursty traffic, the wrong shape for provisioned capacity.
 *
 * Requires the same AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY already
 * used everywhere else this app talks to DynamoDB.
 *
 * Run:
 *   node scripts/setup-contact-table.js
 */

'use strict';

require('dotenv').config();

const {
  DynamoDBClient,
  CreateTableCommand,
  DescribeTableCommand,
  UpdateTableCommand,
  waitUntilTableExists,
} = require('@aws-sdk/client-dynamodb');

const AWS_REGION = process.env.AWS_REGION || 'us-east-1';

const client = new DynamoDBClient({
  region: AWS_REGION,
  credentials: {
    accessKeyId:     process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});

const TABLE_DEFINITION = {
  name: 'br-contactSubmissions',
  keySchema: [{ AttributeName: 'submissionId', KeyType: 'HASH' }],
  attributeDefinitions: [
    { AttributeName: 'submissionId', AttributeType: 'S' },
    { AttributeName: 'status',       AttributeType: 'S' },
    { AttributeName: 'createdAt',    AttributeType: 'S' },
  ],
  gsi: [{
    IndexName: 'status-index',
    KeySchema: [
      { AttributeName: 'status',    KeyType: 'HASH' },
      { AttributeName: 'createdAt', KeyType: 'RANGE' },
    ],
    Projection: { ProjectionType: 'ALL' },
  }],
};

async function tableExists(name) {
  try {
    const result = await client.send(new DescribeTableCommand({ TableName: name }));
    return result.Table;
  } catch (err) {
    if (err.name === 'ResourceNotFoundException') return null;
    throw err;
  }
}

async function createTable(def) {
  await client.send(new CreateTableCommand({
    TableName:                def.name,
    KeySchema:                def.keySchema,
    AttributeDefinitions:     def.attributeDefinitions,
    BillingMode:               'PAY_PER_REQUEST',
    GlobalSecondaryIndexes:    def.gsi,
  }));
  await waitUntilTableExists({ client, maxWaitTime: 120 }, { TableName: def.name });
}

async function ensureIndexes(def, existingTable) {
  const existingIndexNames = (existingTable.GlobalSecondaryIndexes || []).map(i => i.IndexName);

  for (const gsi of def.gsi) {
    if (existingIndexNames.includes(gsi.IndexName)) continue;

    console.log(`  + Adding missing index "${gsi.IndexName}" to ${def.name}...`);
    await client.send(new UpdateTableCommand({
      TableName:                    def.name,
      AttributeDefinitions:         def.attributeDefinitions,
      GlobalSecondaryIndexUpdates:  [{ Create: gsi }],
    }));
    await waitUntilTableExists({ client, maxWaitTime: 180 }, { TableName: def.name });
    console.log(`  ✓ Index "${gsi.IndexName}" is active on ${def.name}`);
  }
}

async function run() {
  console.log('Setting up the contact/feedback DynamoDB table');
  console.log('================================================================================');

  try {
    const existing = await tableExists(TABLE_DEFINITION.name);

    if (existing) {
      console.log(`✓ ${TABLE_DEFINITION.name} already exists — checking indexes...`);
      await ensureIndexes(TABLE_DEFINITION, existing);
    } else {
      console.log(`+ Creating ${TABLE_DEFINITION.name}...`);
      await createTable(TABLE_DEFINITION);
      console.log(`✓ ${TABLE_DEFINITION.name} created and active.`);
    }
  } catch (err) {
    console.error(`✗ ${TABLE_DEFINITION.name} FAILED: ${err.message}`);
    console.log('\nCheck your AWS credentials/permissions and re-run — this script is safe to run again.');
    process.exit(1);
  }

  console.log('================================================================================');
  console.log('\nThe contact/feedback table is ready.');
}

run().catch(err => {
  console.error('\nSetup FAILED unexpectedly:', err.message);
  process.exit(1);
});
