/**
 * routes/auth.routes.js
 *
 * POST /api/auth/login   → Verify credentials, issue JWT cookie, return profile
 * POST /api/auth/logout  → Clear the JWT cookie (server-side)
 * GET  /api/auth/me      → Validate cookie, return profile (used on app load)
 */

'use strict';

const express    = require('express');
const router     = express.Router();
const controller = require('../controllers/auth.controller');
const { protect }     = require('../middleware/auth');
const { authLimiter } = require('../middleware/rateLimiter');
const validate   = require('../middleware/validate');

const loginSchema = {
  email:    { required: true, type: 'email' },
  password: { required: true, type: 'string', min: 1 },
};

// Login — rate limited to prevent brute force
router.post('/login',
  authLimiter,
  validate(loginSchema),
  controller.login
);

// Logout — no auth required (clearing a missing cookie is harmless)
// Rate limit still applied to prevent log-flooding
router.post('/logout',
  authLimiter,
  controller.logout
);

// Session restore — called on every app load by AuthContext
// protect middleware reads the cookie and verifies the JWT
router.get('/me',
  protect,
  controller.getMe
);

module.exports = router;
