/**
 * controllers/auth.controller.js
 *
 * Handles login and profile retrieval.
 *
 * Login flow:
 *   1. Find user in Firestore by email
 *   2. Compare submitted password against stored bcrypt hash
 *   3. Generate a Firebase ID token via custom token (Admin SDK)
 *   4. Return profile + token to frontend
 *
 * Why bcrypt comparison instead of Firebase Auth signIn?
 *   The browser hashed the password before sending it to us.
 *   Firebase Auth never received the original plain-text password
 *   so it cannot verify it. Our bcrypt hash in Firestore is the
 *   source of truth for login verification.
 */

'use strict';

const asyncHandler    = require('../utils/asyncHandler');
const ApiError        = require('../utils/ApiError');
const { sanitise, requireFields, isValidEmail } = require('../utils/sanitise');
const { auth }        = require('../config/firebase');
const firebaseService = require('../services/firebase.service');
const bcrypt          = require('bcryptjs');

// ── Normalise Firestore profile ───────────────────────────────────
// Handles both flat and nested storage — always returns a consistent shape
function normaliseProfile(doc) {
  return {
    uid:          doc.uid          || doc.id  || '',
    fullName:     doc.fullName                || '',
    businessName: doc.businessName            || '',
    email:        doc.email                   || '',
    stage:        doc.profile?.stage        ?? doc.stage        ?? '',
    salesChannel: doc.profile?.salesChannel ?? doc.salesChannel ?? '',
    revenue:      doc.profile?.revenue      ?? doc.revenue      ?? '',
    headache:     doc.profile?.headache     ?? doc.headache     ?? '',
    matchmaking:  doc.profile?.matchmaking  ?? doc.matchmaking  ?? '',
    onboardingStep: doc.onboardingStep       || 0,
    completed:    doc.completed              || false,
  };
}

// ── POST /api/auth/login ──────────────────────────────────────────
const login = asyncHandler(async (req, res) => {
  const body = sanitise(req.body, ['email', 'password']);
  requireFields(body, ['email', 'password']);

  if (!isValidEmail(body.email)) {
    throw ApiError.badRequest('Invalid email address.');
  }

  // 1. Find user in Firestore by email
  let profileDoc = await firebaseService.getUserByEmail(body.email);

  if (!profileDoc) {
    // Also try by UID via Firebase Auth lookup
    const authUser = await auth.getUserByEmail(body.email).catch(() => null);
    if (authUser) {
      profileDoc = await firebaseService.getUserByUid(authUser.uid);
    }
  }

  if (!profileDoc) {
    // Use same message as wrong password — never reveal which part failed
    throw ApiError.unauthorized('Invalid email or password.');
  }

  // 2. Compare submitted password against stored bcrypt hash
  if (!profileDoc.hashedPassword) {
    console.error(`[Auth] No hashedPassword in Firestore for ${body.email}`);
    throw ApiError.unauthorized('Invalid email or password.');
  }

  const passwordMatch = await bcrypt.compare(body.password, profileDoc.hashedPassword);
  if (!passwordMatch) {
    throw ApiError.unauthorized('Invalid email or password.');
  }

  // 3. Generate a Firebase custom token so the frontend can use Firebase
  //    services if needed. The custom token is exchanged for an ID token
  //    client-side — but for our current use case we just return the
  //    profile directly since the roadmap page only needs the profile data.
  let customToken = null;
  try {
    customToken = await auth.createCustomToken(profileDoc.uid || profileDoc.id);
  } catch (err) {
    // Non-fatal — the profile is still returned
    console.warn('[Auth] Custom token generation failed:', err.message);
  }

  // 4. Return profile + token
  res.json({
    success:     true,
    customToken,             // null if token generation failed — frontend handles gracefully
    profile:     normaliseProfile(profileDoc),
  });
});

// ── GET /api/auth/me ──────────────────────────────────────────────
// Protected — requires Firebase ID token in Authorization header.
const getMe = asyncHandler(async (req, res) => {
  let profileDoc = await firebaseService.getUserByUid(req.user.uid);

  if (!profileDoc) {
    profileDoc = await firebaseService.getUserByEmail(req.user.email);
  }

  if (!profileDoc) {
    throw ApiError.notFound('User profile not found.');
  }

  res.json({ success: true, profile: normaliseProfile(profileDoc) });
});

module.exports = { login, getMe };
