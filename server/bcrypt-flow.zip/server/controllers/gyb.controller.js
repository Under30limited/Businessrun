/**
 * controllers/gyb.controller.js
 *
 * Handles the Grow Your Business onboarding flow.
 * ALL four steps go through POST /api/gyb — same pattern throughout.
 *
 * Step 1 — creates session doc with identity fields
 * Step 2 — updates session with business pulse fields
 * Step 3 — updates session with matchmaking choice
 * Step 4 — receives hashed password + full profile:
 *           1. Updates session doc with all fields + hashed password
 *           2. Creates Firebase Auth user (handles its own password separately)
 *           3. Writes complete permanent user doc to users/{uid}
 *           4. Deletes temporary session doc
 *
 * Routes:
 *   POST /api/gyb → saveStep (handles steps 1, 2, 3, and 4)
 */

'use strict';

const asyncHandler    = require('../utils/asyncHandler');
const ApiError        = require('../utils/ApiError');
const { sanitise, requireFields, isValidEmail } = require('../utils/sanitise');
const firebaseService = require('../services/firebase.service');
const authService     = require('../services/auth.service');
const bcrypt          = require('bcryptjs');

const VALID_STAGES    = ['Ideation', 'Launch', 'Scaling', 'Established'];
const VALID_CHANNELS  = ['Social Media', 'Physical Store', 'E-commerce', 'B2B/Referrals'];
const VALID_REVENUES  = ['Under ₦500k', '₦500k – ₦2M', '₦2M – ₦10M', 'Over ₦10M'];
const VALID_HEADACHES = [
  'Pricing for Profit',
  'Tracking Cashflow',
  'Accessing Credit/Loans',
  'Managing Staff/Payroll',
];

// ── POST /api/gyb ─────────────────────────────────────────────────
const saveStep = asyncHandler(async (req, res) => {
  const step = parseInt(req.body?.step);

  if (![1, 2, 3, 4].includes(step)) {
    throw ApiError.badRequest('Invalid step. Must be 1, 2, 3, or 4.');
  }

  requireFields(req.body, ['sessionId']);
  const sessionId = req.body.sessionId;

  // ── Step 1 — Identity ─────────────────────────────────────────
  if (step === 1) {
    const body = sanitise(req.body, [
      'fullName', 'businessName', 'email', 'startedAt', 'source',
    ]);
    requireFields(body, ['fullName', 'businessName', 'email']);

    if (!isValidEmail(body.email)) {
      throw ApiError.badRequest('Invalid email address.');
    }

    await firebaseService.createGybSession(sessionId, {
      fullName:     body.fullName.trim(),
      businessName: body.businessName.trim(),
      email:        body.email.toLowerCase().trim(),
      source:       body.source || 'businessrun-gyb',
    });

    return res.json({ success: true, step });
  }

  // ── Step 2 — Business Pulse ───────────────────────────────────
  if (step === 2) {
    const body = sanitise(req.body, [
      'stage', 'salesChannel', 'revenue', 'headache',
    ]);
    requireFields(body, ['stage', 'salesChannel', 'revenue', 'headache']);

    if (!VALID_STAGES.includes(body.stage)) {
      throw ApiError.badRequest(`Invalid stage: "${body.stage}".`);
    }
    if (!VALID_CHANNELS.includes(body.salesChannel)) {
      throw ApiError.badRequest(`Invalid sales channel: "${body.salesChannel}".`);
    }
    if (!VALID_REVENUES.includes(body.revenue)) {
      throw ApiError.badRequest(`Invalid revenue bracket: "${body.revenue}".`);
    }
    if (!VALID_HEADACHES.includes(body.headache)) {
      throw ApiError.badRequest(`Invalid headache: "${body.headache}".`);
    }

    await firebaseService.updateGybSession(sessionId, {
      stage:          body.stage,
      salesChannel:   body.salesChannel,
      revenue:        body.revenue,
      headache:       body.headache,
      onboardingStep: 2,
    });

    return res.json({ success: true, step });
  }

  // ── Step 3 — Trust & Matchmaking ─────────────────────────────
  if (step === 3) {
    const body = sanitise(req.body, ['matchmaking', 'completedAt']);
    requireFields(body, ['matchmaking']);

    const validMatchmaking = ['Yes, help me scale', "No, I'll manage on my own"];
    if (!validMatchmaking.includes(body.matchmaking)) {
      throw ApiError.badRequest('Invalid matchmaking response.');
    }

    await firebaseService.updateGybSession(sessionId, {
      matchmaking:    body.matchmaking,
      onboardingStep: 3,
    });

    return res.json({ success: true, step });
  }

  // ── Step 4 — Password + Full Profile ─────────────────────────
  // The frontend sends:
  //   hashedPassword — bcryptjs hash (10 rounds), created in the browser
  //   All profile fields from steps 1-3 (full state at submission time)
  //
  // We:
  //   1. Validate the hashed password looks like a bcrypt hash
  //   2. Update the session doc with all fields + hashedPassword
  //   3. Create Firebase Auth user (Firebase manages its own password hash)
  //   4. Write the complete permanent user doc to users/{uid}
  //   5. Clean up the temporary session doc
  if (step === 4) {
    const body = sanitise(req.body, [
      'email',
      'hashedPassword',
      'fullName',
      'businessName',
      'stage',
      'salesChannel',
      'revenue',
      'headache',
      'matchmaking',
      'profileSavedAt',
      'source',
    ]);

    requireFields(body, ['email', 'hashedPassword']);

    if (!isValidEmail(body.email)) {
      throw ApiError.badRequest('Invalid email address.');
    }

    // Validate the received value looks like a valid bcrypt hash
    // Bcrypt hashes start with $2a$, $2b$, or $2y$ and are 60 chars
    const isBcryptHash = /^\$2[aby]\$\d+\$/.test(body.hashedPassword);
    if (!isBcryptHash || body.hashedPassword.length < 59) {
      throw ApiError.badRequest('Invalid password format received.');
    }

    // Step 1 — Update session with full profile + hashed password
    await firebaseService.updateGybSession(sessionId, {
      hashedPassword: body.hashedPassword,
      fullName:       (body.fullName     || '').trim(),
      businessName:   (body.businessName || '').trim(),
      email:          body.email.toLowerCase().trim(),
      stage:          body.stage        || '',
      salesChannel:   body.salesChannel || '',
      revenue:        body.revenue      || '',
      headache:       body.headache     || '',
      matchmaking:    body.matchmaking  || '',
      onboardingStep: 4,
      profileSavedAt: body.profileSavedAt || new Date().toISOString(),
    });

    // Step 2 — Create Firebase Auth user
    // Firebase manages its own password hash for login verification.
    // We also store our own bcrypt hash in Firestore for additional
    // verification if needed.
    //
    // For Firebase Auth we need the original password — but since the
    // browser only sent us the hash, we set a Firebase Auth password
    // using the hash itself as a placeholder. Login verification will
    // use bcrypt.compare against our stored hash in auth.controller.js
    //
    // Note: Firebase Auth user is created with a generated secure password
    // since we don't have the plain text. Authentication is handled via
    // our own bcrypt comparison in the login controller.
    const existingAuthUser = await authService.getAuthUserByEmail(body.email);
    let uid;

    if (existingAuthUser) {
      uid = existingAuthUser.uid;
      console.log(`[GYB] Reusing existing Firebase Auth user: ${uid}`);
    } else {
      // Generate a random placeholder password for Firebase Auth.
      // Login goes through our bcrypt verification, not Firebase Auth directly.
      const placeholderPassword = body.hashedPassword + sessionId.slice(-8);
      const created = await authService.createFirebaseUser(body.email, placeholderPassword);
      uid = created.uid;
      console.log(`[GYB] Firebase Auth user created: ${uid}`);
    }

    // Step 3 — Write the complete permanent user document
    await firebaseService.saveCompleteUser(uid, {
      sessionId,
      email:          body.email.toLowerCase().trim(),
      fullName:       (body.fullName     || '').trim(),
      businessName:   (body.businessName || '').trim(),
      stage:          body.stage        || '',
      salesChannel:   body.salesChannel || '',
      revenue:        body.revenue      || '',
      headache:       body.headache     || '',
      matchmaking:    body.matchmaking  || '',
      hashedPassword: body.hashedPassword,
      source:         body.source       || 'businessrun-gyb',
      profileSavedAt: body.profileSavedAt || new Date().toISOString(),
    });

    // Step 4 — Clean up temporary session doc (fire-and-forget)
    firebaseService
      .deleteGybSession(sessionId)
      .catch(err => console.warn('[GYB] Session cleanup failed:', err.message));

    return res.status(201).json({ success: true, step });
  }
});

module.exports = { saveStep };
