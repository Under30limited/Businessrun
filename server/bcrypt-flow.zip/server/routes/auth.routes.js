/**
 * routes/auth.routes.js
 *
 * POST /api/auth/login → Login with email + password (bcrypt verification)
 * GET  /api/auth/me    → Get current user profile (protected)
 *
 * Note: Registration is handled by POST /api/gyb (step 4)
 */

'use strict';

const express    = require('express');
const router     = express.Router();
const controller = require('../controllers/auth.controller');
const { protect }     = require('../middleware/auth');
const { authLimiter } = require('../middleware/rateLimiter');
const validate   = require('../middleware/validate');

const loginSchema = {
  email:    { required: true, type: 'email' },
  password: { required: true, type: 'string', min: 1 },
};

router.post('/login',
  authLimiter,
  validate(loginSchema),
  controller.login
);

router.get('/me',
  protect,
  controller.getMe
);

module.exports = router;
