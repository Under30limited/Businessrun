/**
 * migrate.js
 *
 * One-time migration script: Firestore → DynamoDB.
 *
 * Run from your server BEFORE switching to the AWS codebase:
 *   node migrate.js
 *
 * Requires both Firebase and AWS env vars to be present in .env.
 * Safe to run multiple times — DynamoDB PutItem is idempotent (overwrites).
 *
 * Progress is logged to console. Run with:
 *   node migrate.js 2>&1 | tee migration.log
 * so you have a full record.
 */

'use strict';

require('dotenv').config();

const admin = require('firebase-admin');

const { DynamoDBClient }         = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand } = require('@aws-sdk/lib-dynamodb');

// ── Init Firebase ─────────────────────────────────────────────────
if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert({
      projectId:   process.env.FIREBASE_PROJECT_ID,
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
      privateKey:  process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n'),
    }),
  });
}
const db = admin.firestore();

// ── Init DynamoDB ─────────────────────────────────────────────────
const dynamo = DynamoDBDocumentClient.from(
  new DynamoDBClient({
    region: process.env.AWS_REGION || 'us-east-1',
    credentials: {
      accessKeyId:     process.env.AWS_ACCESS_KEY_ID,
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    },
  }),
  { marshallOptions: { removeUndefinedValues: true } }
);

// ── Helpers ───────────────────────────────────────────────────────
function convertTimestamps(obj) {
  if (!obj || typeof obj !== 'object') return obj;
  if (Array.isArray(obj)) return obj.map(convertTimestamps);
  const out = {};
  for (const [k, v] of Object.entries(obj)) {
    if (v && typeof v.toDate === 'function') out[k] = v.toDate().toISOString();
    else if (v && typeof v === 'object' && !Array.isArray(v)) out[k] = convertTimestamps(v);
    else out[k] = v;
  }
  return out;
}

async function putItem(tableName, item) {
  await dynamo.send(new PutCommand({ TableName: tableName, Item: item }));
}

// ── Top-level collection migration ───────────────────────────────
async function migrateTopLevel(collectionName, tableName, keyMapper) {
  const snap = await db.collection(collectionName).get();
  console.log(`\n[${collectionName}] ${snap.docs.length} docs → ${tableName}`);
  let count = 0;
  for (const doc of snap.docs) {
    const item = convertTimestamps({ ...doc.data() });
    await putItem(tableName, { ...item, ...keyMapper(doc) });
    count++;
    if (count % 50 === 0) console.log(`  ${count}/${snap.docs.length}...`);
  }
  console.log(`  ✓ ${count} docs migrated`);
}

// ── Sub-collection migration ──────────────────────────────────────
async function migrateSubCollection(parentCollection, subCollection, tableName, itemMapper) {
  const parents = await db.collection(parentCollection).get();
  console.log(`\n[${parentCollection}/${subCollection}] ${parents.docs.length} parents → ${tableName}`);
  let total = 0;
  for (const parent of parents.docs) {
    const uid  = parent.id;
    const snap = await parent.ref.collection(subCollection).get();
    for (const doc of snap.docs) {
      const item = convertTimestamps(doc.data());
      await putItem(tableName, itemMapper(uid, doc.id, item));
      total++;
    }
  }
  console.log(`  ✓ ${total} docs migrated`);
}

// ── CFO sub-sub-collection ────────────────────────────────────────
async function migrateCFOEntries() {
  const TOOLS = ['General Ledger', 'Income Statement', 'Balance Sheet', 'Cash Flow'];
  const users = await db.collection('cfoEntries').get();
  console.log(`\n[cfoEntries] ${users.docs.length} users → br-cfoEntries`);
  let total = 0;
  for (const user of users.docs) {
    const uid = user.id;
    for (const toolName of TOOLS) {
      const toolDoc = await user.ref.collection('tools').doc(toolName).get();
      if (!toolDoc.exists) continue;
      const data = convertTimestamps(toolDoc.data());
      await putItem('br-cfoEntries', { uid, toolName, ...data });
      total++;
    }
  }
  console.log(`  ✓ ${total} tool docs migrated`);
}

// ── Main ──────────────────────────────────────────────────────────
async function run() {
  console.log('BusinessRun — Firestore → DynamoDB Migration');
  console.log('============================================');

  await migrateTopLevel('users',               'br-users',          d => ({ uid: d.id }));
  await migrateTopLevel('nominations',          'br-nominations',    d => ({ id: d.id }));
  await migrateTopLevel('subscribers',          'br-subscribers',    d => ({ email: d.data().email || d.id, type: d.data().type || 'general' }));
  await migrateTopLevel('under30applications',  'br-under30',        d => ({ id: d.id }));
  await migrateTopLevel('advisorSessions',      'br-advisorSessions',d => ({ sessionId: d.id }));

  await migrateCFOEntries();

  await migrateSubCollection('inventory',    'items',   'br-inventory',    (uid, id, data) => ({ uid, itemId: id, id, ...data }));
  await migrateSubCollection('salesDayBook', 'sales',   'br-salesDayBook', (uid, id, data) => ({ uid, saleId: id, id, ...data }));
  await migrateSubCollection('dayLog',       'entries', 'br-dayLog',       (uid, id, data) => ({ uid, entryId: id, ...data }));
  await migrateSubCollection('reports',      'entries', 'br-reports',      (uid, id, data) => ({ uid, reportId: id, ...data }));

  console.log('\n============================================');
  console.log('Migration complete. Verify counts in AWS Console before switching over.');
}

run().catch(err => {
  console.error('\nMigration FAILED:', err);
  process.exit(1);
});
