/**
 * routes/payments.routes.js
 *
 *   POST /api/payments/initialize      (owner)   — start a checkout for a plan
 *   GET  /api/payments/verify/:reference (owner) — instant post-checkout status
 *   POST /api/payments/webhook         (public)  — Paystack event delivery
 *
 * The webhook route has NO protect/auth middleware — Paystack calls it
 * directly with no session cookie. Its security comes entirely from
 * signature verification inside the controller (req.rawBody +
 * x-paystack-signature), not from anything in this file.
 */

'use strict';

const express       = require('express');
const router        = express.Router();
const controller    = require('../controllers/payments.controller');
const { protect }   = require('../middleware/auth');
const { dataLimiter } = require('../middleware/rateLimiter');

// ── Public — Paystack calls this directly, no session ────────────────
router.post('/webhook', controller.webhook);

// ── Requires a session — owner-only check happens in the controller ──
router.post('/initialize',        protect, dataLimiter, controller.initialize);
router.get('/verify/:reference',  protect, dataLimiter, controller.verify);

module.exports = router;
