/**
 * scripts/setup-paystack-plans.js
 *
 * Creates the actual Paystack Plans for every paid tier, in both USD
 * and NGN, and writes the resulting plan codes (plus the NGN price
 * actually used) to config/paystack-plans.generated.json — which
 * config/plans.js reads at load time.
 *
 * RUN ONCE initially, and RE-RUN periodically to refresh the naira
 * price when the exchange rate has moved enough to matter (there's no
 * automatic re-pricing — Paystack Plans have a fixed amount, see
 * config/plans.js's header comment for why).
 *
 * Re-running this is SAFE for existing subscribers: it creates NEW
 * Paystack plan codes and overwrites the generated JSON file with
 * them, but does nothing to anyone already subscribed on the OLD plan
 * codes — they keep paying their original price until you separately
 * decide to migrate them (Paystack has no built-in way to reprice an
 * existing subscription; migrating means canceling the old
 * subscription and starting a new one on the new plan code).
 *
 * Requires PAYSTACK_SECRET_KEY in .env.
 *
 * Run:
 *   node scripts/setup-paystack-plans.js
 */

'use strict';

require('dotenv').config();

const fs   = require('fs');
const path = require('path');

const { PAID_PLAN_IDS, PLANS } = require('../config/plans');
const { createPlan }            = require('../services/paystack.service');
const { convertUsdToNgn }       = require('../services/fx.service');

const OUTPUT_PATH = path.join(__dirname, '..', 'config', 'paystack-plans.generated.json');

async function run() {
  console.log('Setting up Paystack Plans');
  console.log('================================================================================');

  const result = {};

  for (const planId of PAID_PLAN_IDS) {
    const plan = PLANS[planId];
    const priceNGN = await convertUsdToNgn(plan.priceUSD);

    console.log(`\n${plan.name}: $${plan.priceUSD} / ₦${priceNGN.toLocaleString()}`);

    const usdPlan = await createPlan({
      name:     `${plan.name} (USD)`,
      amount:   Math.round(plan.priceUSD * 100), // cents
      currency: 'USD',
      interval: 'monthly',
    });
    console.log(`  ✓ USD plan created: ${usdPlan.plan_code}`);

    const ngnPlan = await createPlan({
      name:     `${plan.name} (NGN)`,
      amount:   Math.round(priceNGN * 100), // kobo
      currency: 'NGN',
      interval: 'monthly',
    });
    console.log(`  ✓ NGN plan created: ${ngnPlan.plan_code}`);

    result[planId] = {
      usd:           usdPlan.plan_code,
      ngn:           ngnPlan.plan_code,
      priceNGNFixed: priceNGN,
    };
  }

  fs.writeFileSync(OUTPUT_PATH, JSON.stringify(result, null, 2) + '\n');

  console.log('\n================================================================================');
  console.log(`Written to ${OUTPUT_PATH}`);
  console.log('Restart the server (or redeploy) for config/plans.js to pick up the new codes.');
}

run().catch(err => {
  console.error('\nSetup FAILED:', err.message);
  process.exit(1);
});
