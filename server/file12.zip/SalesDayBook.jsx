/**
 * SalesDayBook.jsx
 *
 * Sales logging and history tab for the user dashboard.
 *
 * Features:
 *   - Stat bar: today's revenue, total sales count, units sold today
 *   - Log Sale form: select from inventory, set quantity, edit sale price
 *   - Server-side stock validation — never trusts client state
 *   - Auto-deducts inventory quantity on successful sale
 *   - Full sales history with date range filter
 *   - All records loaded silently on mount from /api/sales
 *
 * Props:
 *   sales           {Object[]}  — all sales records (from parent state)
 *   setSales        {Function}  — parent state setter
 *   inventoryItems  {Object[]}  — current inventory (from parent state)
 *   setInventoryItems {Function} — to update quantity after sale
 */

import React, { useState, useMemo } from 'react';
import {
  ShoppingBag, TrendingUp, Package,
  Loader2, AlertCircle, CheckCircle,
  ChevronDown, Calendar, ArrowRight,
  Receipt,
} from 'lucide-react';

const inputClass = 'w-full bg-black border border-zinc-800 rounded-xl px-4 py-3 text-sm text-zinc-100 placeholder:text-zinc-600 focus:outline-none focus:border-amber-500 transition-colors';

// ── Date helpers ──────────────────────────────────────────────────
function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

function isToday(isoString) {
  if (!isoString) return false;
  return isoString.slice(0, 10) === todayISO();
}

function formatDate(isoString) {
  if (!isoString) return '—';
  return new Date(isoString).toLocaleString('en-NG', {
    day:    '2-digit',
    month:  'short',
    year:   'numeric',
    hour:   '2-digit',
    minute: '2-digit',
  });
}

// ── Empty form ────────────────────────────────────────────────────
const emptyForm = () => ({
  inventoryItemId: '',
  itemName:        '',
  unitPrice:       0,
  salePrice:       '',
  quantity:        '',
});

export default function SalesDayBook({
  sales, setSales, inventoryItems, setInventoryItems,
}) {
  const [form,       setForm]       = useState(emptyForm());
  const [isLogging,  setIsLogging]  = useState(false);
  const [formError,  setFormError]  = useState('');
  const [formSuccess, setFormSuccess] = useState('');

  // Date filter state
  const [filterFrom, setFilterFrom] = useState('');
  const [filterTo,   setFilterTo]   = useState('');

  // ── Stats — today only ────────────────────────────────────────
  const todaysSales   = sales.filter(s => isToday(s.saleDate || s.saleDateISO));
  const todayRevenue  = todaysSales.reduce((s, sale) => s + (sale.totalAmount || 0), 0);
  const todayUnits    = todaysSales.reduce((s, sale) => s + (sale.quantity    || 0), 0);
  const totalRevenue  = sales.reduce((s, sale) => s + (sale.totalAmount || 0), 0);

  // ── Filtered history ──────────────────────────────────────────
  const filteredSales = useMemo(() => {
    return sales.filter(sale => {
      const date = (sale.saleDate || sale.saleDateISO || '').slice(0, 10);
      if (filterFrom && date < filterFrom) return false;
      if (filterTo   && date > filterTo)   return false;
      return true;
    });
  }, [sales, filterFrom, filterTo]);

  // ── Select product from inventory ─────────────────────────────
  function handleProductSelect(e) {
    const itemId = e.target.value;
    if (!itemId) { setForm(emptyForm()); return; }
    const item = inventoryItems.find(i => i.id === itemId);
    if (!item) return;
    setForm({
      inventoryItemId: item.id,
      itemName:        item.name,
      unitPrice:       item.unit_price,
      salePrice:       String(item.unit_price), // pre-filled, user can edit
      quantity:        '',
    });
    setFormError('');
    setFormSuccess('');
  }

  // ── Log a sale ────────────────────────────────────────────────
  async function handleLogSale(e) {
    e.preventDefault();

    if (!form.inventoryItemId)                                    { setFormError('Please select a product.');         return; }
    if (!form.quantity || isNaN(+form.quantity) || +form.quantity <= 0)
                                                                  { setFormError('Enter a valid quantity.');           return; }
    if (form.salePrice === '' || isNaN(+form.salePrice) || +form.salePrice < 0)
                                                                  { setFormError('Enter a valid sale price.');         return; }

    // Client-side stock pre-check (server validates authoritatively)
    const localItem = inventoryItems.find(i => i.id === form.inventoryItemId);
    if (localItem && localItem.quantity < +form.quantity) {
      setFormError(
        `Only ${localItem.quantity} unit${localItem.quantity === 1 ? '' : 's'} in stock.`
      );
      return;
    }

    setFormError('');
    setFormSuccess('');
    setIsLogging(true);

    try {
      const res  = await fetch('/api/sales', {
        method:      'POST',
        credentials: 'include',
        headers:     { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          inventoryItemId: form.inventoryItemId,
          itemName:        form.itemName,
          unitPrice:       parseFloat(form.unitPrice),
          salePrice:       parseFloat(form.salePrice),
          quantity:        parseInt(form.quantity, 10),
        }),
      });

      let data;
      try { data = await res.json(); }
      catch { setFormError("We couldn't complete this sale right now. Please try again."); return; }

      if (!res.ok || !data.success) {
        setFormError(data.message || "Something went wrong. The sale wasn't recorded.");
        return;
      }

      // Prepend new sale to history
      setSales(prev => [data.sale, ...prev]);

      // Update inventory quantity in parent state so the dropdown
      // reflects the new stock level immediately without a refetch
      setInventoryItems(prev =>
        prev.map(item =>
          item.id === form.inventoryItemId
            ? { ...item, quantity: data.updatedQuantity }
            : item
        )
      );

      setFormSuccess(
        `Sale logged! ₦${(parseFloat(form.salePrice) * parseInt(form.quantity, 10)).toLocaleString()} recorded. ` +
        `${data.updatedQuantity} unit${data.updatedQuantity === 1 ? '' : 's'} remaining in stock.`
      );
      setForm(emptyForm());

    } catch {
      setFormError("We couldn't reach the server. Please check your connection and try again.");
    } finally {
      setIsLogging(false);
    }
  }

  // Available items (only items with stock > 0)
  const availableItems = inventoryItems.filter(i => i.quantity > 0);
  const subtotal = form.salePrice && form.quantity
    ? (parseFloat(form.salePrice) * parseInt(form.quantity, 10)) || 0
    : 0;

  return (
    <div className="space-y-8 pb-20">

      {/* ── Header ──────────────────────────────────────────────── */}
      <div className="border-b border-zinc-900 -mx-5 px-5 pb-8">
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-black tracking-tighter italic uppercase mb-2">
              Sales Day Book
            </h1>
            <p className="text-zinc-500 text-sm">
              Log every sale, track daily revenue, and auto-update your inventory.
            </p>
          </div>
          <span className="text-[9px] font-black uppercase tracking-widest text-amber-500 bg-amber-500/10 px-4 py-2 rounded-full border border-amber-500/20 self-start">
            Live Ledger
          </span>
        </div>

        {/* ── Stat bar ──────────────────────────────────────────── */}
        <div className="flex flex-wrap gap-4 mt-6">
          <div className="bg-amber-500 rounded-2xl px-5 py-4 flex items-center gap-3">
            <TrendingUp size={16} className="text-black" />
            <div>
              <p className="text-[9px] font-black uppercase tracking-widest text-black/60">Today's Revenue</p>
              <p className="text-xl font-black text-black">₦{todayRevenue.toLocaleString()}</p>
            </div>
          </div>
          <div className="bg-zinc-950 border border-zinc-800 rounded-2xl px-5 py-4 flex items-center gap-3">
            <ShoppingBag size={16} className="text-zinc-500" />
            <div>
              <p className="text-[9px] font-black uppercase tracking-widest text-zinc-600">Today's Sales</p>
              <p className="text-xl font-black text-white">{todaysSales.length}</p>
            </div>
          </div>
          <div className="bg-zinc-950 border border-zinc-800 rounded-2xl px-5 py-4 flex items-center gap-3">
            <Package size={16} className="text-zinc-500" />
            <div>
              <p className="text-[9px] font-black uppercase tracking-widest text-zinc-600">Units Sold Today</p>
              <p className="text-xl font-black text-white">{todayUnits}</p>
            </div>
          </div>
          <div className="bg-zinc-950 border border-zinc-800 rounded-2xl px-5 py-4 flex items-center gap-3">
            <Receipt size={16} className="text-zinc-500" />
            <div>
              <p className="text-[9px] font-black uppercase tracking-widest text-zinc-600">All-Time Revenue</p>
              <p className="text-xl font-black text-white">₦{totalRevenue.toLocaleString()}</p>
            </div>
          </div>
        </div>
      </div>

      {/* ── Log Sale Form ────────────────────────────────────────── */}
      <div className="bg-zinc-950 border border-zinc-900 rounded-[2rem] overflow-hidden">
        <div className="border-b border-zinc-900 px-8 py-5 flex items-center justify-between">
          <div>
            <h2 className="text-lg font-black italic uppercase">Log a Sale</h2>
            <p className="text-zinc-600 text-xs mt-0.5">
              {availableItems.length === 0
                ? 'No inventory items in stock — add stock in the Inventory tab first.'
                : `${availableItems.length} product${availableItems.length === 1 ? '' : 's'} available to sell`}
            </p>
          </div>
          <div className="w-10 h-10 bg-amber-500/10 rounded-xl flex items-center justify-center text-amber-500 border border-amber-500/20">
            <ShoppingBag size={18} />
          </div>
        </div>

        <form onSubmit={handleLogSale} className="p-8 space-y-5">

          {/* Product selector */}
          <div>
            <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">
              Select Product
            </label>
            <div className="relative">
              <select
                value={form.inventoryItemId}
                onChange={handleProductSelect}
                className={inputClass + ' appearance-none cursor-pointer pr-10'}
                disabled={availableItems.length === 0}
              >
                <option value="">Select product to sell...</option>
                {availableItems.map(item => (
                  <option key={item.id} value={item.id}>
                    {item.name} — {item.quantity} in stock · ₦{Number(item.unit_price).toLocaleString()}
                  </option>
                ))}
              </select>
              <ChevronDown size={14} className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-600 pointer-events-none" />
            </div>
          </div>

          {/* Quantity + Sale Price */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">
                Quantity
              </label>
              <input type="number" min="1" placeholder="e.g. 3"
                value={form.quantity}
                onChange={e => { setFormError(''); setForm(p => ({ ...p, quantity: e.target.value })); }}
                className={inputClass}
                disabled={!form.inventoryItemId}
              />
            </div>
            <div>
              <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">
                Sale Price (₦) <span className="text-zinc-700 normal-case font-normal">— editable</span>
              </label>
              <input type="number" min="0" placeholder="e.g. 25000"
                value={form.salePrice}
                onChange={e => { setFormError(''); setForm(p => ({ ...p, salePrice: e.target.value })); }}
                className={inputClass}
                disabled={!form.inventoryItemId}
              />
            </div>
          </div>

          {/* Listed vs sale price note */}
          {form.inventoryItemId && form.salePrice !== '' && parseFloat(form.salePrice) !== form.unitPrice && (
            <div className="flex items-center gap-2 px-4 py-2 bg-zinc-900 border border-zinc-800 rounded-xl">
              <span className="text-[10px] font-black uppercase tracking-widest text-zinc-500">
                Listed price: ₦{Number(form.unitPrice).toLocaleString()}
                {parseFloat(form.salePrice) < form.unitPrice
                  ? <span className="text-red-400 ml-2">· Selling below listed price</span>
                  : <span className="text-green-400 ml-2">· Selling above listed price</span>}
              </span>
            </div>
          )}

          {/* Subtotal */}
          {subtotal > 0 && (
            <div className="flex items-center justify-between px-5 py-4 bg-amber-500/5 border border-amber-500/20 rounded-xl">
              <span className="text-[10px] font-black uppercase tracking-widest text-amber-500/70">Subtotal</span>
              <span className="text-xl font-black text-amber-500">₦{subtotal.toLocaleString()}</span>
            </div>
          )}

          {formError && (
            <div className="flex items-center gap-2 px-4 py-3 bg-red-500/10 border border-red-500/20 rounded-xl">
              <AlertCircle size={13} className="text-red-400 shrink-0" />
              <p className="text-red-400 text-xs">{formError}</p>
            </div>
          )}

          {formSuccess && (
            <div className="flex items-center gap-2 px-4 py-3 bg-green-500/10 border border-green-500/20 rounded-xl">
              <CheckCircle size={13} className="text-green-400 shrink-0" />
              <p className="text-green-400 text-xs">{formSuccess}</p>
            </div>
          )}

          <button type="submit" disabled={isLogging || availableItems.length === 0}
            className="w-full flex items-center justify-center gap-2 py-4 bg-amber-500 text-black font-black text-xs uppercase tracking-widest rounded-xl hover:bg-amber-400 transition-all disabled:opacity-40">
            {isLogging
              ? <><Loader2 size={15} className="animate-spin" /> Recording Sale...</>
              : <><ArrowRight size={15} /> Log Sale & Deduct Stock</>}
          </button>
        </form>
      </div>

      {/* ── Sales History ────────────────────────────────────────── */}
      <div className="bg-zinc-950 border border-zinc-900 rounded-[2rem] overflow-hidden">
        <div className="border-b border-zinc-900 px-8 py-5 flex items-center justify-between flex-wrap gap-4">
          <div>
            <h2 className="text-lg font-black italic uppercase">Sales History</h2>
            <p className="text-zinc-600 text-xs mt-0.5">
              {filteredSales.length} record{filteredSales.length === 1 ? '' : 's'}
              {(filterFrom || filterTo) ? ' in selected range' : ' total'}
            </p>
          </div>

          {/* Date range filter */}
          <div className="flex items-center gap-2 flex-wrap">
            <Calendar size={13} className="text-zinc-600" />
            <input type="date" value={filterFrom}
              onChange={e => setFilterFrom(e.target.value)}
              className="bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-zinc-300 focus:outline-none focus:border-amber-500 transition" />
            <span className="text-zinc-700 text-xs font-black">→</span>
            <input type="date" value={filterTo}
              onChange={e => setFilterTo(e.target.value)}
              className="bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-zinc-300 focus:outline-none focus:border-amber-500 transition" />
            {(filterFrom || filterTo) && (
              <button onClick={() => { setFilterFrom(''); setFilterTo(''); }}
                className="text-[10px] font-black uppercase tracking-widest text-zinc-600 hover:text-amber-500 transition px-3 py-2 bg-zinc-900 rounded-xl border border-zinc-800">
                Clear
              </button>
            )}
          </div>
        </div>

        {/* Empty state */}
        {filteredSales.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 text-center px-8">
            <div className="w-16 h-16 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center mb-5">
              <Receipt size={24} className="text-zinc-700" />
            </div>
            <h3 className="text-base font-black uppercase tracking-tighter mb-2">No Sales Yet</h3>
            <p className="text-zinc-600 text-sm max-w-xs leading-relaxed">
              {(filterFrom || filterTo)
                ? 'No sales found in the selected date range. Try adjusting the filter.'
                : 'Log your first sale above to start building your ledger.'}
            </p>
          </div>
        )}

        {/* Sales table */}
        {filteredSales.length > 0 && (
          <div>
            {/* Table header */}
            <div className="hidden sm:grid grid-cols-[1.5fr_1fr_0.7fr_0.7fr_1fr_1fr] gap-4 px-8 py-3 bg-zinc-900/60 border-b border-zinc-900">
              {['Product', 'Date', 'Qty', 'Sale Price', 'Listed Price', 'Total'].map(h => (
                <p key={h} className="text-[9px] font-black uppercase tracking-widest text-zinc-600">{h}</p>
              ))}
            </div>

            {/* Rows */}
            <div className="divide-y divide-zinc-900/60">
              {filteredSales.map(sale => {
                const isDiscount = sale.salePrice < sale.unitPrice;
                const isPremium  = sale.salePrice > sale.unitPrice;
                return (
                  <div key={sale.id}
                    className="grid grid-cols-1 sm:grid-cols-[1.5fr_1fr_0.7fr_0.7fr_1fr_1fr] gap-2 sm:gap-4 px-8 py-4 hover:bg-zinc-900/20 transition items-center">

                    {/* Product */}
                    <div>
                      <p className="text-sm font-black text-white">{sale.itemName}</p>
                      <p className="text-[10px] text-zinc-600 sm:hidden">{formatDate(sale.saleDate || sale.saleDateISO)}</p>
                    </div>

                    {/* Date — hidden on mobile (shown inline above) */}
                    <p className="hidden sm:block text-xs text-zinc-500 font-mono">
                      {formatDate(sale.saleDate || sale.saleDateISO)}
                    </p>

                    {/* Qty */}
                    <p className="text-sm font-black text-white">
                      <span className="sm:hidden text-zinc-600 font-normal text-xs">Qty: </span>
                      {sale.quantity}
                    </p>

                    {/* Sale price */}
                    <div>
                      <p className={`text-sm font-black ${isDiscount ? 'text-red-400' : isPremium ? 'text-green-400' : 'text-white'}`}>
                        ₦{Number(sale.salePrice).toLocaleString()}
                      </p>
                      {(isDiscount || isPremium) && (
                        <p className={`text-[9px] font-black uppercase tracking-widest ${isDiscount ? 'text-red-500/60' : 'text-green-500/60'}`}>
                          {isDiscount ? '↓ Discount' : '↑ Premium'}
                        </p>
                      )}
                    </div>

                    {/* Listed price */}
                    <p className="hidden sm:block text-xs text-zinc-600 font-mono">
                      ₦{Number(sale.unitPrice).toLocaleString()}
                    </p>

                    {/* Total */}
                    <p className="text-sm font-black text-amber-500">
                      <span className="sm:hidden text-zinc-600 font-normal text-xs">Total: </span>
                      ₦{Number(sale.totalAmount).toLocaleString()}
                    </p>
                  </div>
                );
              })}
            </div>

            {/* Range totals (shown when filter active) */}
            {(filterFrom || filterTo) && filteredSales.length > 0 && (
              <div className="px-8 py-4 border-t border-zinc-900 bg-zinc-900/40 flex flex-wrap gap-6">
                <div>
                  <p className="text-[9px] font-black uppercase tracking-widest text-zinc-600 mb-1">Range Revenue</p>
                  <p className="text-lg font-black text-amber-500">
                    ₦{filteredSales.reduce((s, sale) => s + sale.totalAmount, 0).toLocaleString()}
                  </p>
                </div>
                <div>
                  <p className="text-[9px] font-black uppercase tracking-widest text-zinc-600 mb-1">Range Units</p>
                  <p className="text-lg font-black text-white">
                    {filteredSales.reduce((s, sale) => s + sale.quantity, 0)}
                  </p>
                </div>
                <div>
                  <p className="text-[9px] font-black uppercase tracking-widest text-zinc-600 mb-1">Transactions</p>
                  <p className="text-lg font-black text-white">{filteredSales.length}</p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
