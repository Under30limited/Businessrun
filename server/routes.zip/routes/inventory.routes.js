/**
 * routes/inventory.routes.js
 *
 *   GET    /api/inventory        → fetch all items (silent on dashboard load)
 *   POST   /api/inventory        → add item + optional image upload
 *   PATCH  /api/inventory/:id    → update quantity / price / name
 *   DELETE /api/inventory/:id    → delete item + Storage image
 *
 * All routes protected by JWT cookie via protect middleware.
 * POST uses multer middleware before the controller to parse multipart/form-data.
 */

'use strict';

const express        = require('express');
const router         = express.Router();
const controller     = require('../controllers/inventory.controller');
const { protect }    = require('../middleware/auth');
const { dataLimiter } = require('../middleware/rateLimiter');

// All inventory routes require a valid session
router.use(protect);

router.get('/',       dataLimiter, controller.getItems);
router.post('/',      dataLimiter, controller.uploadMiddleware, controller.addItem);
router.patch('/:id',  dataLimiter, controller.updateItem);
router.delete('/:id', dataLimiter, controller.deleteItem);

module.exports = router;
