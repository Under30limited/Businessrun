/**
 * routes/sales.routes.js
 *
 *   GET  /api/sales   → fetch all sales (optional ?from=&to= date filter)
 *   POST /api/sales   → record a sale + deduct inventory stock
 *
 * All routes protected by JWT cookie.
 */

'use strict';

const express        = require('express');
const router         = express.Router();
const controller     = require('../controllers/sales.controller');
const { protect }    = require('../middleware/auth');
const { dataLimiter } = require('../middleware/rateLimiter');

router.use(protect);

router.get('/',  dataLimiter, controller.getSales);
router.post('/', dataLimiter, controller.logSale);

module.exports = router;
