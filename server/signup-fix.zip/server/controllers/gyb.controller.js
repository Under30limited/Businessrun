/**
 * controllers/gyb.controller.js
 *
 * Handles the Grow Your Business onboarding flow.
 *
 * IMPORTANT CHANGE:
 * Previously, steps 1-3 wrote partial data to Firestore progressively,
 * and step 4 (password) promoted the session doc.
 *
 * Now: steps 1-3 still save progressively for drop-off tracking,
 * BUT step 4 saves ALL data — the complete profile from all steps —
 * in a single atomic write. This ensures the user collection always
 * has complete data and the password creation + full profile write
 * happen together with no partial state.
 *
 * Routes:
 *   POST /api/gyb          → saveStep (steps 1, 2, 3 — progressive saves)
 *   POST /api/gyb/password → savePassword (step 4 — full atomic save + Auth user)
 */

'use strict';

const asyncHandler    = require('../utils/asyncHandler');
const ApiError        = require('../utils/ApiError');
const { sanitise, requireFields, isValidEmail } = require('../utils/sanitise');
const firebaseService = require('../services/firebase.service');
const authService     = require('../services/auth.service');

const VALID_STAGES    = ['Ideation', 'Launch', 'Scaling', 'Established'];
const VALID_CHANNELS  = ['Social Media', 'Physical Store', 'E-commerce', 'B2B/Referrals'];
const VALID_REVENUES  = ['Under ₦500k', '₦500k – ₦2M', '₦2M – ₦10M', 'Over ₦10M'];
const VALID_HEADACHES = [
  'Pricing for Profit',
  'Tracking Cashflow',
  'Accessing Credit/Loans',
  'Managing Staff/Payroll',
];

// ── POST /api/gyb ─────────────────────────────────────────────────
// Progressive saves for drop-off tracking (steps 1, 2, 3).
// No change to these — they write partial data to the session doc.
const saveStep = asyncHandler(async (req, res) => {
  const step = parseInt(req.body?.step);
  if (![1, 2, 3].includes(step)) {
    throw ApiError.badRequest('Invalid step. Must be 1, 2, or 3.');
  }

  requireFields(req.body, ['sessionId']);
  const sessionId = req.body.sessionId;

  // ── Step 1 — Identity ────────────────────────────────────────
  if (step === 1) {
    const body = sanitise(req.body, [
      'fullName', 'businessName', 'email', 'startedAt', 'source',
    ]);
    requireFields(body, ['fullName', 'businessName', 'email']);
    if (!isValidEmail(body.email)) {
      throw ApiError.badRequest('Invalid email address.');
    }
    await firebaseService.createGybSession(sessionId, {
      fullName:     body.fullName.trim(),
      businessName: body.businessName.trim(),
      email:        body.email.toLowerCase().trim(),
      source:       body.source || 'businessrun-gyb',
    });
  }

  // ── Step 2 — Business Pulse ───────────────────────────────────
  if (step === 2) {
    const body = sanitise(req.body, [
      'stage', 'salesChannel', 'revenue', 'headache',
    ]);
    requireFields(body, ['stage', 'salesChannel', 'revenue', 'headache']);

    if (!VALID_STAGES.includes(body.stage)) {
      throw ApiError.badRequest(`Invalid stage: "${body.stage}".`);
    }
    if (!VALID_CHANNELS.includes(body.salesChannel)) {
      throw ApiError.badRequest(`Invalid sales channel: "${body.salesChannel}".`);
    }
    if (!VALID_REVENUES.includes(body.revenue)) {
      throw ApiError.badRequest(`Invalid revenue bracket: "${body.revenue}".`);
    }
    if (!VALID_HEADACHES.includes(body.headache)) {
      throw ApiError.badRequest(`Invalid headache: "${body.headache}".`);
    }

    await firebaseService.updateGybSession(sessionId, {
      stage:          body.stage,
      salesChannel:   body.salesChannel,
      revenue:        body.revenue,
      headache:       body.headache,
      onboardingStep: 2,
    });
  }

  // ── Step 3 — Trust & Matchmaking ─────────────────────────────
  if (step === 3) {
    const body = sanitise(req.body, ['matchmaking', 'completedAt']);
    requireFields(body, ['matchmaking']);

    const validMatchmaking = ['Yes, help me scale', "No, I'll manage on my own"];
    if (!validMatchmaking.includes(body.matchmaking)) {
      throw ApiError.badRequest('Invalid matchmaking response.');
    }

    await firebaseService.updateGybSession(sessionId, {
      matchmaking:    body.matchmaking,
      onboardingStep: 3,
    });
  }

  res.json({ success: true, step });
});

// ── POST /api/gyb/password ────────────────────────────────────────
// Step 4 — receives ALL form data from the frontend and saves
// everything in one atomic operation:
//   1. Create Firebase Auth user (handles password hashing)
//   2. Write the COMPLETE user document to Firestore keyed by UID
//      (not a promotion — a fresh complete write with all fields)
//   3. Delete the temporary session doc
const savePassword = asyncHandler(async (req, res) => {
  const body = sanitise(req.body, [
    'sessionId',
    'email',
    'password',
    // All profile fields — frontend sends full state at step 4
    'fullName',
    'businessName',
    'stage',
    'salesChannel',
    'revenue',
    'headache',
    'matchmaking',
    'profileSavedAt',
    'source',
  ]);

  requireFields(body, ['sessionId', 'email', 'password']);

  if (!isValidEmail(body.email)) {
    throw ApiError.badRequest('Invalid email address.');
  }
  if (typeof body.password !== 'string' || body.password.length < 6) {
    throw ApiError.badRequest('Password must be at least 6 characters.');
  }

  // ── Check for duplicate submission ───────────────────────────
  // If the user refreshes and resubmits step 4, Firebase Auth
  // already has their account — use the existing UID.
  const existingAuthUser = await authService.getAuthUserByEmail(body.email);

  let uid;
  if (existingAuthUser) {
    uid = existingAuthUser.uid;
    console.log(`[GYB] Duplicate step 4 — reusing existing UID: ${uid}`);
  } else {
    // Create Firebase Auth user — this is the source of truth for the password.
    // Firebase hashes it internally; we never store the plain-text password.
    const created = await authService.createFirebaseUser(body.email, body.password);
    uid = created.uid;
    console.log(`[GYB] Firebase Auth user created: ${uid}`);
  }

  // ── Write the complete user document to Firestore ─────────────
  // Keyed by Firebase Auth UID — this is the permanent user record.
  // We write ALL fields here regardless of what was saved in steps 1-3,
  // so the final document is always complete and self-contained.
  await firebaseService.saveCompleteUser(uid, {
    sessionId:    body.sessionId,
    fullName:     (body.fullName     || '').trim(),
    businessName: (body.businessName || '').trim(),
    email:        body.email.toLowerCase().trim(),
    stage:        body.stage        || '',
    salesChannel: body.salesChannel || '',
    revenue:      body.revenue      || '',
    headache:     body.headache     || '',
    matchmaking:  body.matchmaking  || '',
    source:       body.source       || 'businessrun-gyb',
    profileSavedAt: body.profileSavedAt || new Date().toISOString(),
  });

  // ── Clean up the temporary session doc ───────────────────────
  // Fire-and-forget — don't let a cleanup failure block the response
  firebaseService
    .deleteGybSession(body.sessionId)
    .catch(err => console.warn('[GYB] Session cleanup failed:', err.message));

  res.status(201).json({ success: true });
});

module.exports = { saveStep, savePassword };
