/**
 * utils/otp.js
 *
 * OTP generation, storage, and verification for password reset.
 *
 * FLOW:
 *   1. POST /api/auth/otp/request  → generate code, store in Firestore, send email
 *   2. POST /api/auth/otp/verify   → check code, mark verified
 *   3. POST /api/auth/otp/reset    → verify token from step 2, update password
 *
 * FIRESTORE PATH:
 *   otpCodes/{email} — one document per email, overwritten on each new request.
 *   This means a new OTP request automatically invalidates the previous one.
 *
 * DOCUMENT SHAPE:
 *   {
 *     email:      string,     // normalised lowercase
 *     code:       string,     // 6-digit string (stored as string, not number)
 *     expiresAt:  Timestamp,  // 15 minutes from creation
 *     attempts:   number,     // wrong guesses so far (max 5)
 *     verified:   boolean,    // true after correct code entered
 *     resetToken: string,     // random token issued after verification
 *     createdAt:  Timestamp,
 *   }
 *
 * SECURITY DECISIONS:
 *   - Code stored as a string, not hashed — 6 digits with max 5 attempts
 *     and 15-minute expiry provides sufficient security without the
 *     complexity of hashing short codes (which would offer little benefit
 *     since Firestore access requires server-side auth anyway).
 *   - resetToken is a 32-byte hex string — long enough to be unguessable,
 *     short-lived (used once to set password, then document deleted).
 *   - Attempts capped at 5 — brute forcing 1,000,000 codes in 5 tries
 *     is computationally impossible.
 */

'use strict';

const crypto = require('crypto');
const { db, admin } = require('../config/firebase');

const OTP_COLLECTION  = 'otpCodes';
const OTP_EXPIRY_MS   = 15 * 60 * 1000;  // 15 minutes
const MAX_ATTEMPTS    = 5;

// ── Generate a 6-digit OTP ────────────────────────────────────────
function generateCode() {
  // crypto.randomInt is cryptographically secure
  return String(crypto.randomInt(100000, 999999));
}

// ── Generate a secure reset token ────────────────────────────────
function generateResetToken() {
  return crypto.randomBytes(32).toString('hex');
}

// ── Store OTP in Firestore ────────────────────────────────────────
/**
 * Creates or overwrites the OTP document for an email.
 * Overwrites invalidate any previous unused code automatically.
 *
 * @param {string} email  Normalised email
 * @returns {string}      The generated code (to be emailed)
 */
async function storeOTP(email) {
  const code      = generateCode();
  const expiresAt = new Date(Date.now() + OTP_EXPIRY_MS);

  await db.collection(OTP_COLLECTION).doc(email).set({
    email,
    code,
    expiresAt:  admin.firestore.Timestamp.fromDate(expiresAt),
    attempts:   0,
    verified:   false,
    resetToken: null,
    createdAt:  admin.firestore.FieldValue.serverTimestamp(),
  });

  return code;
}

// ── Verify OTP ────────────────────────────────────────────────────
/**
 * Checks the submitted code against the stored one.
 *
 * Returns one of:
 *   { success: true,  resetToken: string }   — code correct
 *   { success: false, reason: 'expired' }    — past 15 min
 *   { success: false, reason: 'max_attempts' }
 *   { success: false, reason: 'invalid',
 *     attemptsLeft: number }                 — wrong code
 *   { success: false, reason: 'not_found' }  — no OTP requested
 *
 * @param {string} email
 * @param {string} code   6-digit string submitted by the user
 */
async function verifyOTP(email, code) {
  const ref  = db.collection(OTP_COLLECTION).doc(email);
  const snap = await ref.get();

  if (!snap.exists) {
    return { success: false, reason: 'not_found' };
  }

  const data = snap.data();

  // Check expiry
  const expiresAt = data.expiresAt.toDate();
  if (new Date() > expiresAt) {
    await ref.delete();
    return { success: false, reason: 'expired' };
  }

  // Check attempt cap
  if (data.attempts >= MAX_ATTEMPTS) {
    await ref.delete();
    return { success: false, reason: 'max_attempts' };
  }

  // Wrong code — increment attempts
  if (data.code !== String(code).trim()) {
    await ref.update({ attempts: admin.firestore.FieldValue.increment(1) });
    const attemptsLeft = MAX_ATTEMPTS - (data.attempts + 1);
    return { success: false, reason: 'invalid', attemptsLeft };
  }

  // Correct — issue a one-time reset token and mark verified
  const resetToken = generateResetToken();
  await ref.update({ verified: true, resetToken });

  return { success: true, resetToken };
}

// ── Validate reset token ──────────────────────────────────────────
/**
 * Called by the password reset step to confirm the token is valid
 * before updating the password. Deletes the OTP doc after validation
 * so the token can only be used once.
 *
 * @param {string} email
 * @param {string} resetToken
 * @returns {boolean}
 */
async function validateResetToken(email, resetToken) {
  const ref  = db.collection(OTP_COLLECTION).doc(email);
  const snap = await ref.get();

  if (!snap.exists) return false;

  const data = snap.data();

  // Must be verified and token must match and not expired
  if (!data.verified)                      return false;
  if (data.resetToken !== resetToken)      return false;
  if (new Date() > data.expiresAt.toDate()) { await ref.delete(); return false; }

  // Delete the document — token is single-use
  await ref.delete();
  return true;
}

module.exports = { storeOTP, verifyOTP, validateResetToken };
